/******************************************************************************
* File: MatrixUtils.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "MatrixUtils.h"

#include <R.h>

#include <math.h>
#include <stdlib.h>


///  Recursive definition of determinate using expansion by minors.
double Determinant(double **a,int n)
{
   int i,j,j1,j2;
   double det = 0;
   double **m = NULL;

/*         m = malloc((n-1)*sizeof(double *));
         for (i=0;i<n-1;i++)
            m[i] = malloc((n-1)*sizeof(double)); */

   if (n < 1) { 
			Rprintf("\n Major error in c program's determinant function");
			exit(1);
   } else if (n == 1) { /* Shouldn't get used */
      det = a[0][0];
   } else if (n == 2) {
      det = a[0][0] * a[1][1] - a[1][0] * a[0][1];
   } else {
      det = 0;
      for (j1=0;j1<n;j1++) {
         m = malloc((n-1)*sizeof(double *));
         for (i=0;i<n-1;i++)
            m[i] = malloc((n-1)*sizeof(double));
         for(i=0;i<n-1;i++)
            

         for (i=1;i<n;i++) {
            j2 = 0;
            for (j=0;j<n;j++) {
               if (j == j1)
                  continue;
               m[i-1][j2] = a[i][j];
               j2++;
            }
         }
         det = det + pow(-1.0,1.0+j1+1.0) * a[0][j1] * Determinant(m,n-1);
         for (i=0;i<n-1;i++)
            free(m[i]);
         free(m);
      }
   }
   return(det);
}


///  Find the cofactor matrix of a square matrix copied to b.
void CoFactor(double **a,int n,double **b)
{
   int i,j,ii,jj,i1,j1;
   double det;
   double **c;

   c = malloc((n-1)*sizeof(double *));
   for (i=0;i<n-1;i++)
     c[i] = malloc((n-1)*sizeof(double));

   for (j=0;j<n;j++) {
      for (i=0;i<n;i++) {

         /* Form the adjoint a_ij */
         i1 = 0;
         for (ii=0;ii<n;ii++) {
            if (ii == i)
               continue;
            j1 = 0;
            for (jj=0;jj<n;jj++) {
               if (jj == j)
                  continue;
               c[i1][j1] = a[ii][jj];
               j1++;
            }
            i1++;
         }

         /* Calculate the determinate */
         det = Determinant(c,n-1);

         /* Fill in the elements of the cofactor */
         b[i][j] = pow(-1.0,i+j+2.0) * det;
      }
   }
   for (i=0;i<n-1;i++)
      free(c[i]);
   free(c);
}


///  Transpose of a square matrix, do it in place
void Transpose(double **a,int n)
{
   int i,j;
   double tmp;

   for (i=1;i<n;i++) {
      for (j=0;j<i;j++) {
         tmp = a[i][j];
         a[i][j] = a[j][i];
         a[j][i] = tmp;
      }
   }
}


/// Inverse of a matrix copied to b
void INVERSE(double **a, int n, double **b)
{
	int i,j;
	double det;
	det=Determinant(a,n);
	CoFactor(a,n,b);
	Transpose(b,n);
	for(i=0;i<n;i++)
	 for(j=0;j<n;j++)
		 b[i][j]=b[i][j]/det;

	return;
}


/// Copy Matrix "a" to "b" and store it there with an option to add
void MatrixCopy(double **a,double **b,int row,int col,int add)
{
	int i,j;
	if(add==0)
	{
		for(i=0;i<row;i++)
			for(j=0;j<col;j++)
					b[i][j]=a[i][j];
	}
	else if(add==1)
	{ 
		for(i=0;i<row;i++)
		for(j=0;j<col;j++)
			b[i][j]=b[i][j]+a[i][j];
	}     
}


/// Matrix substraction a-b 
void XminusY(double **a, double **b, int row, int col, double **target)
{
	int i,j;
	for(i=0;i<row;i++)
		for(j=0;j<col;j++)
			target[i][j]=a[i][j]-b[i][j];
}


/// Multiply a'a where a is m x n and a'a = n x n (for m > n) for m < n AA'
void XprimeX(double **a, int row, int col, double **target)
{
	int i,j,j1;
	double sum=0;
	if(row >= col){
		for(j=0;j<col;j++){
			for(j1=0;j1<col;j1++){
				sum=0;
				for(i=0;i<row;i++) sum = sum + a[i][j]*a[i][j1];          
				target[j][j1]=sum;   
			}
		}
	}
	else{
		i=row;
		row=col;
		col=i;
		for(j=0;j<col;j++){
			for(j1=0;j1<col;j1++){
					sum=0;
					for(i=0;i<row;i++) sum = sum + a[j][i]*a[j1][i];          
					target[j][j1]=sum;   
			}
		}
	}
} 


/// Multiply AB where a is m x n and b = n x p target has to be of the dimension xrow,ycol
void XprimeY(double **x, double **y, int xrow, int xcol, int ycol, double **target)
{
	int i,j,j1;
	double sum=0;
	for(j=0;j<xrow;j++){
		for(j1=0;j1<ycol;j1++){
			sum=0;
			for(i=0;i<xcol;i++)  sum = sum + x[j][i]*y[j1][i];          
			target[j][j1]=sum;   
		}
  }
} 

/// Multiply AB where a is m x n and b = n x p target has to be of the dimension xrow,ycol
void XprimeVec(double **x, double *y, int xrow, int xcol,double *target)
{
	int i,j;
	double sum=0;
	for(j=0;j<xrow;j++){
		sum=0;
		for(i=0;i<xcol;i++)  
			sum += x[j][i]*y[i];          
		target[j]=sum;   
  }
} 


/// Computes the trace of a square matrix
double Trace(double **a,int n)
{
	double trace=0;
	int i;
	for(i=0;i<n;i++)
		trace = trace + a[i][i];
	return(trace);      
}


/// Computes the Cholesky factor for a positive definite symm square matrix
void Cholesky(double **q,int n,double **lower)
{
	double linsum=0,crosssum=0;
	int i,j,k;
  for(i=0;i<n;i++)
      for(j=0;j<n;j++)
            lower[i][j]=0;               
  for(i=0;i<n;i++)
  {  
		linsum=0;
    for(j=0;j<=i;j++)
    {
       if(j==i) lower[i][j] = sqrt(q[i][j]-linsum);
       else {
        for(k=0;k<j;k++) crosssum = crosssum + lower[i][k]*lower[j][k];
        lower[i][j] = (q[j][i] - crosssum)/lower[j][j];
        }
       linsum = linsum + lower[i][j]*lower[i][j];
       crosssum=0;
    }
  }
}

/* FIND THE INNER PRODUCT OF TWO VECTORS.  Each vector is of length n, and
   is stored in memory in successive locations that are at a given distance
   apart.  For an ordinary vector, a distance of 1 is used, but other
   distances can come about from looking at columns of a matrix. */
double inner_product
( double *v1,		/* First vector */
  int d1,				/* Distance between elements of first vector */
  double *v2,		/* Second vector */
  int d2,				/* Distance between elements of second vector */
  int n					/* Number of elements in the vectors */
)
{
  double s;
  int i;

  s = 0;

  for (i = n; i>0; i--)
  { s += *v1 * *v2;
    v1 += d1;
    v2 += d2;
  }

  return s;
}


/* FIND THE PRODUCT OF TWO MATRICES.  The matrix elements are stored in
   contiguous locations in row-major order. */
void matrix_product
( double *m1,		/* Left operand */
  double *m2,		/* Right operand */
  double *r,		/* Place to store result */
  int n,				/* Number of rows in result (and left operand) */
  int m,				/* Number of columns in result (and right operand) */
  int k					/* Number of columns in left operand & rows in right */
)
{
  int i, j;

  for (i = 0; i<n; i++)
  { for (j = 0; j<m; j++)
    { *r++ = inner_product(m1,1,m2+j,m,k);
    }
    m1 += k;
  }
}


/* FIND TRANSPOSE OF A MATRIX.  The matrix elements are stored in
   contiguous locations in row-major order. */

void matrix_transpose
( double *m,		/* Matrix */
  double *r,		/* Place to store result */
	int n_row,		/* Number of rows in Matrix */
	int n_col			/* Number of columns in Matrix */
)
{
  int i, j;

	for (i=0; i<n_col; i++){ 
		for (j=0; j<n_row; j++){
			r[n_row*i+j] = m[n_col*j+i];
		}
  }
}


/* FIND X'X.  The matrix elements are stored in
   contiguous locations in row-major order. */

void matrix_xtx
( double *m,		/* Matrix */
  double *r,		/* Place to store result */
	int n_row,		/* Number of rows in Matrix */
	int n_col			/* Number of columns in Matrix */
)
{
	double *mt;
	mt = (double*) malloc(n_row*n_col*sizeof(double));

	matrix_transpose(m, mt, n_row, n_col);
	matrix_product(mt, m, r, n_col, n_col, n_row);

	free(mt);
}
