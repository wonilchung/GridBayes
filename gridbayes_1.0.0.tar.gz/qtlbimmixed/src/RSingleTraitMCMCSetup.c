/******************************************************************************
* File: RSingleTraitMCMCSetup.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "GlobalVars.h"
#include "GlobalVars_SingleTrait.h"
#include "RInterfaces.h"
#include "SingleTraitMCMC.h"

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/Utils.h>

#include <stdio.h>
#include <time.h>
#include <math.h>

//***************************************************************************
void RSingleTraitMCMCSetup(int *nind, int *nchr, int *ngen, int *nloci, double *loci, double *prob,
					  double *yvalue, int *traittype, int *ncategory,
					  int *iter, int *thin, int *burnin, int *genoupdate,
            int *epis, int *emainqtl, int *eqtl, int *mnqtl,
					  double *interval, int *chrnqtl,
					  int *envi, int *qtl_envi, int *nrancov, int *nfixcov, int *intcov, double *rancoef, double *fixcoef, int *nran,
						int *kin, double *kinmatrix, double *ome_mean, double *ome_var, /*for kinship matrix*/
						int *longi,double *timecoef,int *subidcoef,int *subnum,int *gridnum, /*for longitudinal data*/
						double *del_mean, double *del_var, double *p_mean, double *p_var, double *sigma2,  /*for longitudinal data*/
					  int *depen, double *prop, int *contrast, double *censor_lo, double *censor_hi,
					  int *seed, int *verbose)
{
	int l, i, j, k; 

// **************************************************************************
// parameter values passed from r function qb.mcmc
 
  // set parameters
  ns=*nind;  // number of individuals
	ns1=*nind; // number of individuals
	nlg=*nchr; // number of chromosomes
	ng=*ngen;  // number of genotypes
	if(ng==3) cross=2;
	else cross=1;

	ngrid=(int *)S_alloc(nlg, sizeof(int));
  ngrid=nloci;     // numbers of loci on chromosomes
  tngrid=0;        // total number of grids
	for(i=0;i<nlg;i++) tngrid=tngrid+ngrid[i];
	chl=ngrid[0];    // max number of grids 
  for(i=1;i<nlg;i++)
	if(ngrid[i]>chl) chl=ngrid[i];

	grid=(double **)S_alloc(nlg, sizeof(double *));
	for(i=0;i<nlg;i++) grid[i]=(double *)S_alloc(chl, sizeof(double));
  int pos=0;
	for(i=0;i<nlg;i++)
		for(j=0;j<ngrid[i];j++)
		{
			grid[i][j]=loci[pos];
			pos=pos+1;
		}

  
	// genotype probabilities for each individual at each grid
  qprob = (double ****)S_alloc(nlg, sizeof(double ***));
  for(i=0; i<nlg; i++)
	{
		qprob[i] = (double ***)S_alloc(ns, sizeof(double**));
    for(j=0; j<ns; j++)
		{
			qprob[i][j] = (double **)S_alloc(chl, sizeof(double *));
			for(k=0; k<chl; k++)
			{
				qprob[i][j][k] = (double *)S_alloc(ng, sizeof(double));
			}
		}
	}
	pos=0;
	for(l=0;l<nlg;l++)
		for(k=0;k<ng;k++)
			for(j=0;j<ngrid[l];j++)
				for(i=0;i<ns1;i++)
				{
					qprob[l][i][j][k]=prob[pos];
					pos=pos+1;
				}


	y=(double *)S_alloc(ns1, sizeof(double)); // phenotypic data
	y=yvalue;

	censor_lo1=(double *)S_alloc(ns1, sizeof(double));
	censor_lo1=censor_lo;
  censor_hi1=(double *)S_alloc(ns1, sizeof(double));
	censor_hi1=censor_hi;

	category=*traittype;
	cn=*ncategory;

	niter=*iter;
	nthin=*thin;
	nburnin=*burnin;
	verbose1=*verbose;

  updategeno=*genoupdate;

	epistasis=*epis;
	e_nqtl_main=*emainqtl;
	e_nqtl=*eqtl;
	nqtl=*mnqtl;

	dqq=(double *)S_alloc(nlg, sizeof(double));
	dqq=interval;

	chr_nqtl=(int *)S_alloc(nlg, sizeof(int));
	chr_nqtl=chrnqtl;


	env_factor=*envi;
	gbye=*qtl_envi;

	nrancova=*nrancov;    // set number of random effects
	nfixcova=*nfixcov;    // set number of fixed effects  

	gbye_fix_index=(int *)S_alloc(nfixcova, sizeof(int));
	gbye_fix_index=intcov;

	coef_ran = (double **)S_alloc(ns1, sizeof(double *));  // set actual values of random covariates
	for(i=0; i<ns1; i++) coef_ran[i] = (double *)S_alloc(nrancova, sizeof(double));
	for(i=0; i<ns1; i++) coef_ran[i]=rancoef+i*(*nrancov);

	nran1=(int *)S_alloc(nrancova,sizeof(int));  // number of random effect
	nran1=nran;

	coef_fix = (double **)S_alloc(ns1, sizeof(double *));  // actual values of fixed covariates
	for(i=0; i<ns1; i++) coef_fix[i] = (double *)S_alloc(nfixcova, sizeof(double));
	for(i=0; i<ns1; i++) coef_fix[i] = fixcoef+i*(*nfixcov);

	// for kinship matrix ///////////////////////////////////////////////////
	kin_factor = *kin;
	
	if (kin_factor == 1){
		coef_subid = (int *)S_alloc(ns1, sizeof(int));  // subject
		for(i=0; i<ns1; i++) coef_subid[i] = subidcoef[i];
		
		num_subject = *subnum;

		kinmat = (double **)S_alloc(ns1, sizeof(double *));  // actual values of kinship matrix
		for (i=0; i<ns1; i++) kinmat[i] = (double *)S_alloc(ns1, sizeof(double));

		for (i=0; i<ns1; i++)
			for (j=0; j<ns1; j++)
				kinmat[i][j] = kinmatrix[i*ns1+j];

		omega_mean = *ome_mean;
		omega_var = *ome_var;
	}
	/////////////////////////////////////////////////////////////////////////

	// for longitudinal data ////////////////////////////////////////////////
	longi_factor = *longi;

	if (longi_factor == 1){
		coef_time = (double *)S_alloc(ns1, sizeof(double));  // actual values of time covariates
		for(i=0; i<ns1; i++) coef_time[i] = timecoef[i];

		coef_subid = (int *)S_alloc(ns1, sizeof(int));  // subject
		for(i=0; i<ns1; i++) coef_subid[i] = subidcoef[i];

		//for(i=0; i<ns1; i++) Rprintf("coef_time[%d]=%f\n",i,coef_time[i]);
		//for(i=0; i<ns1; i++) Rprintf("coef_subid[%d]=%d\n",i,coef_subid[i]);

		num_subject = *subnum;
		num_grid = *gridnum;

		delta_mean = *del_mean;
		delta_var = *del_var;

		int z = num_grid*(num_grid-1)/2;

		psi_mean = (double *)S_alloc(z, sizeof(double));  // mean of prior for psi
		//for(i=0; i<z; i++) Rprintf("p_mean[%d]=%f\n",i,p_mean[i]);
		for(i=0; i<z; i++) psi_mean[i] = p_mean[i];

		psi_var = (double *)S_alloc(z*z, sizeof(double));  // variance of prior for psi
		for(i=0; i<z*z; i++) psi_var[i] = p_var[i];
		//for(i=0; i<z*z; i++) Rprintf("psi_var[%d]=%f\n",i,psi_var[i]);

		sigma2_fixed = *sigma2;
	}
  //////////////////////////////////////////////////////////////////////////

	dependence=*depen;
	c=prop;
  
	// set seed number
	seed1=*seed;

//***************************************************************************
// set group and nc

	group=1-*contrast; // 0: Cockerham model, 1: estimate genotypic values
	                   // 1: groupedly update all main effects or epistatic effects
	nc=(group==0)*(ng-1)+(group==1)*ng; // the number of main effects at one QTL

//**************************************************************************
// for binary and ordinal traits

	w=(int *)S_alloc(ns1, sizeof(int));
	cutpoint=(double *)S_alloc((cn+1), sizeof(double));

//**************************************************************************
// parameters used in prior specification

	// Calculate the priors of main and epistatic effect indicators
	int nc0=(group==0)*nc+(group==1)*1;

	w_main=0;      // prior for main effect indicator
	if(nqtl!=0) w_main=1-pow(1-e_nqtl_main*1.0/(nqtl*1.0),1.0/nc0);

	w_epistasis=0; // prior for epistatic effect indicator
	if(epistasis==1&&nqtl!=0) w_epistasis=1-pow( (1-e_nqtl*1.0/(nqtl*1.0))/pow(1-w_main,nc0),1.0/(nc0*nc0*(nqtl-1.0)) );

	w_gbye=0;      // prior for g by e indicator
	if(nqtl!=0) w_gbye=(1.0*e_nqtl_main)/nqtl;

	vmain = (double **)S_alloc(nqtl, sizeof(double *));             // prior variance of main effects
	for(i=0; i<nqtl; i++) vmain[i] = (double *)S_alloc(ng, sizeof(double));

	vepistasis = (double ****)S_alloc(nqtl, sizeof(double ***));    // prior variance of epistatic effects
	for(i=0; i<nqtl; i++)
	{
		vepistasis[i] = (double ***)S_alloc(nqtl, sizeof(double**));
		for(j=0; j<nqtl; j++)
		{
			vepistasis[i][j] = (double **)S_alloc(ng, sizeof(double *));
			for(k=0; k<ng; k++) vepistasis[i][j][k] = (double *)S_alloc(ng, sizeof(double));
		}
  }

	v_gbye_fix = (double ***)S_alloc(nfixcova, sizeof(double **));  // prior variance of g-by-e effects
	for(i=0; i<nfixcova; i++)
	{
		v_gbye_fix[i] = (double **)S_alloc(nqtl, sizeof(double *));
		for(j=0;j<nqtl;j++) v_gbye_fix[i][j]=(double *)S_alloc(ng, sizeof(double));
	}

	vmain1=(double *)S_alloc(nqtl, sizeof(double));                 // prior variance of main effects

	vepistasis1 = (double **)S_alloc(nqtl, sizeof(double *));       // prior variance of epistatic effects
	for(i=0; i<nqtl; i++) vepistasis1[i] = (double *)S_alloc(nqtl, sizeof(double));

	v_gbye_fix1 = (double **)S_alloc(nfixcova, sizeof(double *));   // prior variance of g-by-e effects
	for(i=0; i<nfixcova; i++) v_gbye_fix1[i] = (double *)S_alloc(nqtl, sizeof(double));

//*********************************************************************************
// genetic model parameters

	main1 = (double **)S_alloc(nqtl, sizeof(double *));             // main effects
	for(i=0; i<nqtl; i++) main1[i] = (double *)S_alloc(ng, sizeof(double));

	epistatic = (double ****)S_alloc(nqtl, sizeof(double ***));     // epistatic effects
	for(i=0; i<nqtl; i++)
	{
		epistatic[i] = (double ***)S_alloc(nqtl, sizeof(double**));
		for(j=0; j<nqtl; j++)
		{
			epistatic[i][j] = (double **)S_alloc(ng, sizeof(double *));
			for(k=0; k<ng; k++) epistatic[i][j][k] = (double *)S_alloc(ng, sizeof(double));
		}
 }

	gvalue=(double *)S_alloc(ns1, sizeof(double));                  // genotypic values

	geno = (int **)S_alloc(ns1, sizeof(int *));                     // QTL genotypes
	for(i=0; i<ns1; i++) geno[i] = (int *)S_alloc(nqtl, sizeof(int));

	coef = (double ***)S_alloc(ns1, sizeof(double **));             // coefficients of QTL main effects
	for(i=0; i<ns1; i++)
	{
		coef[i] = (double **)S_alloc(nqtl, sizeof(double *));
		for(j=0;j<nqtl;j++) coef[i][j]=(double *)S_alloc(ng, sizeof(double));
	}

//*********************************************************************************
// QTL positions, genetic effects indicators

	qloc=(int *)S_alloc(nqtl, sizeof(int));           // QTL position indicators, position is grid[qchr[l]][qloc[l]]
	qchr=(int *)S_alloc(nqtl, sizeof(int));           // chromosomes that QTL locate
	chrqtl=(int *)S_alloc(nlg, sizeof(int));          // QTL number at each chromosome

	gamma1=(int *)S_alloc(nqtl, sizeof(int));         // QTL indicators
	gamma_main=(int *)S_alloc(nqtl, sizeof(int));     // main effects indicators

	gamma_epistasis = (int **)S_alloc(nqtl, sizeof(int *));  // epistatic effects indicators
	for(i=0; i<nqtl; i++) gamma_epistasis[i] = (int *)S_alloc(nqtl, sizeof(int));


	for(i=0;i<nqtl;i++)
	{
		qloc[i]=0;
		qchr[i]=0;
		gamma1[i]=0;
		gamma_main[i]=0;
		for(j=0;j<nqtl;j++) gamma_epistasis[i][j]=0;
	}
	for(i=0;i<nlg;i++) chrqtl[i]=0;

//**********************************************************************************
// environmental covariate parameters

	fix=(double *)S_alloc(nfixcova, sizeof(double));                 // effects of fixed covariates
 
	ran = (double **)S_alloc(nrancova, sizeof(double *));            // effects of random covariates
	for(i=0; i<nrancova; i++) ran[i] = (double *)S_alloc(ns1, sizeof(double));

	vran=(double *)S_alloc(nrancova, sizeof(double));                // variances of random covariates

	gbye_fix = (double ***)S_alloc(nfixcova, sizeof(double **));     // interactions of QTL main effects and fixed covariates
	for(i=0; i<nfixcova; i++)
	{
		gbye_fix[i] = (double **)S_alloc(nqtl, sizeof(double *));
		for(j=0;j<nqtl;j++) gbye_fix[i][j]=(double *)S_alloc(ng, sizeof(double));
	}

	gamma_gbye = (double **)S_alloc(nfixcova, sizeof(double *));     // g-by-e indicators
	for(i=0; i<nfixcova; i++) gamma_gbye[i] = (double *)S_alloc(nqtl, sizeof(double));

//*********************************************************************************

	pd1=(double *)S_alloc(nqtl, sizeof(double));
	pd2=(double *)S_alloc(nqtl, sizeof(double));

	x=(double *)S_alloc(ng, sizeof(double));

	ve=(double *)S_alloc(ns1, sizeof(double));

//**********************************************************************************

	// Assign the binary or ordinal phenotypes

	//int i,j,k 
	int nl;

	for(i=0;i<ns1;i++)
		if(category!=1) w[i]=(int)y[i];


	// REMOVE THE INDIVIDUALS WITH MISSING PHENOTYPIC AND COVARIATE VALUES

	int ii=-1;
	for(i=0;i<ns1;i++)
	{
		int miss=0;
		for(j=0;j<nfixcova;j++) miss=miss+(coef_fix[i][j]==999);
		for(j=0;j<nrancova;j++) miss=miss+(coef_ran[i][j]==999);

		if(y[i]!=999&&miss==0)
		{
			ii=ii+1;
			y[ii]=y[i], w[ii]=w[i];
			for(nl=0;nl<nlg;nl++)
				for(j=0;j<ngrid[nl];j++)
					for(k=0;k<ng;k++) qprob[nl][ii][j][k]=qprob[nl][i][j][k];

			for(j=0;j<nfixcova;j++) coef_fix[ii][j]=coef_fix[i][j];
			for(j=0;j<nrancova;j++) coef_ran[ii][j]=coef_ran[i][j];

			censor_lo1[ii]=censor_lo1[i], censor_hi1[ii]=censor_hi1[i];
		}
	}
	ns=ii+1;

//**********************************************************************************
// For kinship matrix
	if (kin_factor == 1) {
		
		latent_c = (double *)S_alloc(ns1, sizeof(double));
		for(i=0; i<ns1; i++) latent_c[i] = 0;

		kin_omega = (double *)S_alloc(1, sizeof(double));
		kin_omega[0] = 0;

	}

	qcvalue = (double *)S_alloc(ns1, sizeof(double));
	for(i=0; i<ns1; i++) qcvalue[i] = 0;

//**********************************************************************************
// For longitudinal data
	
	if (longi_factor == 1) {

		latent_b = (double *)S_alloc(num_subject*num_grid, sizeof(double));
		for(i=0; i<num_subject*num_grid; i++) latent_b[i] = 0;
		
		ran_delta = (double *)S_alloc(num_grid, sizeof(double));
		for(i=0; i<num_grid; i++) ran_delta[i] = 0;
		
		ran_psi = (double *)S_alloc((int)(0.5*num_grid*(num_grid-1)), sizeof(double));
		for(i=0; i<0.5*num_grid*(num_grid-1); i++) ran_psi[i] = 0;

	}

	vbvalue = (double *)S_alloc(ns1, sizeof(double));
	for(i=0; i<ns1; i++) vbvalue[i] = 0;
	
//**********************************************************************************
// call mcmc algorithm

	/////////////////////////////////////////////////
	//log_file =fopen("c:\\log.txt","w");
  /////////////////////////////////////////////////

	singleTraitMCMC();

	/////////////////////////////////////////////////
	//fclose(log_file);
	/////////////////////////////////////////////////

}
