/******************************************************************************
* File: SingleTraitMCMC.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description: QTL Bayesian Interval Mapping with Mixed Model
*   Functions relevant to MCMC Model Selection for single trait analyses
******************************************************************************/


#ifndef SINGLE_TRAIT_MCMC_H
#define SINGLE_TRAIT_MCMC_H

void singleTraitMCMC();

#endif // SINGLE_TRAIT_MCMC_H
