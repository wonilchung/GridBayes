/******************************************************************************
* File: StatUtil.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "GlobalVars.h"
#include "GlobalVars_SingleTrait.h"
#include "StatUtils.h"

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/Utils.h>
#include <math.h>


//*******************************************************
double RANDOM()
{
	double u=rand()/(RAND_MAX+1.0);
	if(u>=1.0) u=1.0-(1e-10); if(u<=0.0) u=1e-10;
	return(u);
}

//*******************************************************
void ANORMAL(double  *r1, double  *r2)
{
	double u1=RANDOM();
  double u2=RANDOM();
  *r1=sqrt(-2.*log(u1))*cos(6.2830*u2);
  *r2=sqrt(-2.*log(u1))*sin(6.2830*u2);
	return;
}
//********************************************************
void MULTINORMAL(double * prior1)
{
	double sum1[ng];int i,j;

  for(i=0;i<ng;i++)
	{
    sum1[i]=0.0;
    for(j=0;j<=i;j++) sum1[i]=sum1[i]+prior1[j];
	}

  double r=RANDOM();
  if(r<=sum1[0]) ibd=0;
  else
  for(i=0;i<ng-1;i++)
	  if((r>sum1[i])&&(r<=sum1[i+1])) ibd=i+1;
  return;
}

//****************************************************************************************
///Calculate the normal function value
double NormalFunction(double x)
{
	double t,z,ANS;

	z=fabs(x)/sqrt(2.0);
	t=1.0/(1.0+0.5*z);
	ANS=t*exp(-z*z-1.26551223+t*(1.00002368+t*(0.37409196+t*(0.09678418+
		t*(-0.18628806+t*(0.27886807+t*(-1.13520398+t*(1.48851587+
		t*(-0.82215223+t*0.17087277)))))))));
	return x>=0.0 ? 0.5*(2-ANS) : 1-0.5*(2-ANS);
}

//*****************************************************************************************
///Sample from a double-truncated normal density N(b,v) truncated to the range (t1,t2)
double TrunNormal(double t1, double t2, double b, double v)
{
	double u,p1,p2,p,alpha=0,y=0,yy=0;
	double c0=2.515517,c1=0.802853,c2=0.010328,d1=1.432788,d2=0.189269,d3=0.001308;
	//double t1=cutpoint[WW],t2=cutpoint[WW+1];

	u = rand()/(RAND_MAX+1.0);

	p1 = NormalFunction((t1-b)/sqrt(v));
	p2 = NormalFunction((t2-b)/sqrt(v));

	p = p1 + u*(p2-p1);
	if(p==0.0) p=1e-10;
	if(p==1.0) p=1-(1e-10);

	if(p>0.0&&p<0.5)
	{
		alpha=p;
		y=sqrt(-2*log(alpha));
	  yy=y-(c0+c1*y+c2*y*y)/(d1*y+d2*y*y+d3*y*y*y+1);
		yy=-yy;
	}
	if(p>0.5&&p<1.0)
	{
		alpha=1-p;
		y=sqrt(-2*log(alpha));
	  yy=y-(c0+c1*y+c2*y*y)/(d1*y+d2*y*y+d3*y*y*y+1);
	}
	if(p==0.5) yy=0;

	return(b+sqrt(v)*yy);
}

///Sample from a left-truncated normal density N(b,v) truncated to the range (t1,Inf)
double LeftTrunNormal(double t1, double b, double v)
{
	double u,p1,p,alpha=0,y=0,yy=0;
	double c0=2.515517,c1=0.802853,c2=0.010328,d1=1.432788,d2=0.189269,d3=0.001308;
	//double t1=cutpoint[WW],t2=cutpoint[WW+1];

	u = rand()/(RAND_MAX+1.0);

	p1 = NormalFunction((t1-b)/sqrt(v));

	p = (1-u)*p1;
	if(p==0.0) p=1e-10;
	if(p==1.0) p=1-(1e-10);

	if(p>0.0&&p<0.5)
	{
		alpha=p;
		y=sqrt(-2*log(alpha));
	  yy=y-(c0+c1*y+c2*y*y)/(d1*y+d2*y*y+d3*y*y*y+1);
		yy=-yy;
	}
	if(p>0.5&&p<1.0)
	{
		alpha=1-p;
		y=sqrt(-2*log(alpha));
	  yy=y-(c0+c1*y+c2*y*y)/(d1*y+d2*y*y+d3*y*y*y+1);
	}
	if(p==0.5) yy=0;

	return(b+sqrt(v)*yy);
}

/// Random generation from a m-dim multivariate normal N(mu,Sigma)
void Multivariate_RNORM(double **sigma_cholesky,double *mu,int m,double *sample)
{
	int i,j;
	double sum,*z,u,u0;
	z=malloc(m*sizeof(double));
  for(i=0;i<m;i++)
  {    
		ANORMAL(&u,&u0);
    z[i] = u;
  }     
  
	for(i=0;i<m;i++)
	{    
		sum=0;     
    for(j=0;j<m;j++) sum = sum + sigma_cholesky[i][j]*z[j];
    sample[i] = mu[i] + sum;
  }
  free(z);
	return;
}


// floor_p
double floor_p(double number, double pos) 
{ 
	return floor(number*pow(10,pos))/pow(10,pos); 
}
