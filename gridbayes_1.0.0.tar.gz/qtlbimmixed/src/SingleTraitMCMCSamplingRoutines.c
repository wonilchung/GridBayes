/******************************************************************************
* File: SingleTraitMCMCSamplingRoutines.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:  QTLBIMMIXED - QTL Bayesian Interval Mapping with Mixed Model
*   Functions relevant to single trait analyses
******************************************************************************/

#include "GlobalVars.h"
#include "GlobalVars_SingleTrait.h"
#include "StatUtils.h"
#include "SingleTraitMCMCSamplingRoutines.h"
#include "MatrixUtils.h"

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/Utils.h>

#include <stdio.h>
#include <math.h>


#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))


/// Calculate the likelihood for categorical trait
double Likelihood(double *p,double *g)
{
	double cc[cn+1], al=0.0; int i,j;

    for(i=0;i<ns;i++)
	{
		for(j=0;j<=cn;j++) cc[j]=NormalFunction((p[j]-amu-g[i])/sqrt(ve[i]));
		double t=0.0;
		for(j=1;j<=cn;j++) t=t+(w[i]==(j-1))*(cc[j]-cc[j-1]);
		al=al+log(t+1e-20);
	}

	return(al);
}



// global variables - Cross,x.
// Transfering genotypes to regression coefficients
void Coefficient(int genotype)          //updategeno=1
{
	int k;

	if(group==1)
	{
		for(k=0;k<ng;k++) x[k]=(genotype==k)*1.0;
	}

	if(group==0)
	{
		if(cross==2)                 //Cockerham model
		{
			x[0]=genotype-1.0,
			x[1]=genotype*(2.0-genotype)-0.5;
		}
		else x[0]=genotype-0.5;
	}

	return;
}

// global variables - Cross,x.
// Transfering genotypes to regression coefficients
void Coefficient0(int i,int l,int ql)     //updategeno=0
{
	int k;

	if(group==1)
	{
		for(k=0;k<ng;k++) x[k]=qprob[qchr[l]][i][ql][k];
	}

	if(group==0)
	{
		if(cross==2)                //Cockerham model
		{
			x[0]=qprob[qchr[l]][i][ql][2]-qprob[qchr[l]][i][ql][0],
			x[1]=0.5*(qprob[qchr[l]][i][ql][1]-qprob[qchr[l]][i][ql][0]-qprob[qchr[l]][i][ql][2]);
		}
		else x[0]=0.5*(qprob[qchr[l]][i][ql][1]-qprob[qchr[l]][i][ql][0]);
	}

	return;
}



//global variables - gamma1 *
///Deleting QTL with all 0 effects
void ZeroEffect1(int l)
{
	int l0;

	gamma1[l]=(gamma_main[l]!=0);

	if(epistasis==1)
	{
		for(l0=0;l0<=l-1;l0++) gamma1[l]=gamma1[l]+(gamma_epistasis[l0][l]!=0);
		for(l0=l+1;l0<nqtl;l0++) gamma1[l]=gamma1[l]+(gamma_epistasis[l][l0]!=0);
	}

	if(gbye==1)
	{
		for(l0=0;l0<nfixcova;l0++)
			if(gbye_fix_index[l0]==1) gamma1[l]=gamma1[l]+(gamma_gbye[l0][l]!=0);
	}

	return;
}


// global variables - gamma1 *
void ZeroEffect2(int l1, int l2)
{
	int l0;

	gamma1[l1]=(gamma_main[l1]!=0);
	gamma1[l2]=(gamma_main[l2]!=0);

	if(epistasis==1)
	{
		for(l0=0;l0<=l1-1;l0++) gamma1[l1]=gamma1[l1]+(gamma_epistasis[l0][l1]!=0);
		for(l0=l1+1;l0<nqtl;l0++) gamma1[l1]=gamma1[l1]+(gamma_epistasis[l1][l0]!=0);

		for(l0=0;l0<=l2-1;l0++) gamma1[l2]=gamma1[l2]+(gamma_epistasis[l0][l2]!=0);
		for(l0=l2+1;l0<nqtl;l0++) gamma1[l2]=gamma1[l2]+(gamma_epistasis[l2][l0]!=0);
	}

	if(gbye==1)
	{
		for(l0=0;l0<nfixcova;l0++)
			if(gbye_fix_index[l0]==1)
			{
				gamma1[l1]=gamma1[l1]+(gamma_gbye[l0][l1]!=0);
				gamma1[l2]=gamma1[l2]+(gamma_gbye[l0][l2]!=0);
			}
	}

	return;
}


/// Used for updating QTL genotypes and locations.
double GenotypeSampling(int i,int l,int ii,int ql)   //if updategeno==1(0), dosenot need ql(ii)
{
  
	int l1,k,k1,k2; double g;

	if(updategeno==1) Coefficient(ii);
	if(updategeno==0) Coefficient0(i,l,ql);
	g=gvalue[i];
	for(k=0;k<nc;k++) g=g-coef[i][l][k]*main1[l][k]+x[k]*main1[l][k];

	if(epistasis==1)
		for(l1=0;l1<nqtl;l1++)
		{
			if(l1<l&&gamma1[l1]!=0&&gamma_epistasis[l1][l]!=0)
				for(k1=0;k1<nc;k1++)
					for(k2=0;k2<nc;k2++)
						g=g-coef[i][l1][k1]*coef[i][l][k2]*epistatic[l1][l][k1][k2]+coef[i][l1][k1]*x[k2]*epistatic[l1][l][k1][k2];

      if(l1>l&&gamma1[l1]!=0&&gamma_epistasis[l][l1]!=0)
				for(k1=0;k1<nc;k1++)
					for(k2=0;k2<nc;k2++)
						g=g-coef[i][l][k1]*coef[i][l1][k2]*epistatic[l][l1][k1][k2]+x[k1]*coef[i][l1][k2]*epistatic[l][l1][k1][k2];
		}

	if(gbye==1)
		for(l1=0;l1<nfixcova;l1++)
			if(gbye_fix_index[l1]==1&&gamma_gbye[l1][l]!=0)
				for(k=0;k<nc;k++)
					g=g-coef_fix[i][l1]*coef[i][l][k]*gbye_fix[l1][l][k]+coef_fix[i][l1]*x[k]*gbye_fix[l1][l][k];

	return(g);
}



// Update the overall mean 
// prior for amu is N(y_bar,vp)
void Mean(double y_bar,double vp)
{
	int i; double t1=0.0,t2=0.0,t3,u,u0;

  for(i=0;i<ns;i++) 
	{
		//t1=t1+(y[i]-gvalue[i])/ve[i];
		t1=t1+(y[i]-gvalue[i]-vbvalue[i]-qcvalue[i])/ve[i];
		t2=t2+1.0/ve[i];
	}
	t3=t2+1/vp;

	ANORMAL(&u,&u0);
	amu=(t1+y_bar/vp)/t3+u/sqrt(t3);
	
	return;
}



// Update the residual variance 
// prior for ve is uniform
void ResidualVariance(double vp)  
{
	int i; double t1=0.0,t2=0.0,u,u0,temp;

	for(i=0;i<ns;i++){
    //t1=t1+pow(y[i]-amu-gvalue[i],2);
		t1=t1+pow(y[i]-amu-gvalue[i]-vbvalue[i]-qcvalue[i],2);
    ANORMAL(&u,&u0);
    t2=t2+u*u;
	}
  
	// modified by wonil
  temp = t1/t2;
	if (sigma2_fixed != -1)
		temp = sigma2_fixed;
	for(i=0;i<ns;i++) ve[i]=temp;

	return;
}


// Update the residual variance 
// prior for residual is Inv-chisq(nu,tau),E(vmain)=nu*tau/(nu-2)
// posterior is Inv-chisq(nu+N,(N*sigmahat+nu*tau)/(nu+N))
void ResidualVariance1(int nu,double tau)
{
	int i; double t1=0.0,t2=0.0,u,u0;

	for(i=0;i<ns;i++){
		//t1=t1+pow(y[i]-amu-gvalue[i],2);
		t1=t1+pow(y[i]-amu-gvalue[i]-vbvalue[i]-qcvalue[i],2);
	}

	for(i=0;i<nu+ns;i++){
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}

	for(i=0;i<ns;i++) ve[i]=(t1+nu*tau)/t2;

	/*t1=pow(main1[l][k],2);
	t2=0;
	for(j=0;j<1+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	vmain[l][k]=(t1+nu*tau)/t2; */

	return;
}



// Update the main effects
void MainEffect(int l,int k)
{
	int i; double g[ns1],t1,t2,t3,u,u0;

	t1=0,t2=0;
	for(i=0;i<ns;i++)
	{
		double z=coef[i][l][k];
		g[i]=gvalue[i]-z*main1[l][k];
		//t1=t1+z*(y[i]-amu-g[i])/ve[i];
		t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
		t2=t2+pow(z,2)/ve[i];
	}
	double v=vmain[l][k];
	if(group==1) v=vmain1[l];
	t3=1/v+t2;

	ANORMAL(&u,&u0);
	main1[l][k]=t1/t3+u/sqrt(t3);

	for(i=0;i<ns;i++) 
		gvalue[i]=g[i]+coef[i][l][k]*main1[l][k];

	return;
}



// Update the epistatic effects
void EpistaticEffect(int l1,int l2,int k1,int k2)
{
	int i; double g[ns1],t1,t2,t3,u,u0;

	t1=0,t2=0;
	for(i=0;i<ns;i++)
	{
		double z=coef[i][l1][k1]*coef[i][l2][k2];
		g[i]=gvalue[i]-z*epistatic[l1][l2][k1][k2];
		//t1=t1+z*(y[i]-amu-g[i])/ve[i];
		t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
		t2=t2+pow(z,2)/ve[i];
	}
	double v=vepistasis[l1][l2][k1][k2];
	if(group==1) v=vepistasis1[l1][l2];
	t3=1/v+t2;

	ANORMAL(&u,&u0);
	epistatic[l1][l2][k1][k2]=t1/t3+u/sqrt(t3);

	for(i=0;i<ns;i++) gvalue[i]=g[i]+coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];

	return;
}


// Update g by e fixed effects
void GBYE_FixedCovariate(int l1,int l2,int k)
{
	int i; double g[ns1],t1,t2,t3,u,u0;

	t1=0,t2=0;
	for(i=0;i<ns;i++)
	{
		double z=coef_fix[i][l1]*coef[i][l2][k];
		g[i]=gvalue[i]-z*gbye_fix[l1][l2][k];
		//t1=t1+z*(y[i]-amu-g[i])/ve[i];
		t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
		t2=t2+pow(z,2)/ve[i];
	}
	double v=v_gbye_fix[l1][l2][k];
	if(group==1) v=v_gbye_fix1[l1][l2];
	t3=1/v+t2;

	ANORMAL(&u,&u0);
	gbye_fix[l1][l2][k]=t1/t3+u/sqrt(t3);

	for(i=0;i<ns;i++) 
		gvalue[i]=g[i]+coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];

	return;
}


// Update genetic variances of the marginal effects
// prior for residual is Inv-chisq(nu,tau),E(vmain)=nu*tau/(nu-2)
// posterior is Inv-chisq(nu+1,(main1^2+nu*tau)/(nu+1))
void MainVariance(int l,int k,int nu,double tau)    
{
	int j; double t1,t2,u,u0;

	t1=pow(main1[l][k],2);
	t2=0;
	for(j=0;j<1+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	vmain[l][k]=(t1+nu*tau)/t2;

	return;
}


// Update genetic variances of the marginal effects
// prior for vmain is Inv-chisq(nu,(nu-2)/nu*tau),E(vmain)=tau
void MainVariance1(int l,int nu,double tau)
{
	int k,j; double t1,t2,u,u0;

	t1=0,t2=0;
	for(k=0;k<nc;k++) t1=t1+pow(main1[l][k],2);
	int n_main=nc;
	for(j=0;j<n_main+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}

	vmain1[l]=(t1+nu*tau)/t2;

	return;
}


// Update genetic variances of the epistatic effects
// prior for vepistasis is Inv-chisq(nu,(nu-2)/nu*tau),E(vepistasis)=tau
void EpistaticVariance(int l1,int l2,int k1,int k2,int nu,double tau)    
{
	int j;double t1,t2,u,u0;

	t1=pow(epistatic[l1][l2][k1][k2],2);
	t2=0;
	for(j=0;j<1+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	vepistasis[l1][l2][k1][k2]=(t1+nu*tau)/t2;

	return;
}


// Update genetic variances of the epistatic effects
// prior for vepistasis is Inv-chisq(nu,(nu-2)/nu*tau),E(vepistasis)=tau
void EpistaticVariance1(int l1,int l2,int nu,double tau)    
{
	int k1,k2,j;double t1,t2,u,u0;

	t1=0,t2=0;
	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++) t1=t1+pow(epistatic[l1][l2][k1][k2],2);

	int n_epis=nc*nc;
	for(j=0;j<n_epis+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	vepistasis1[l1][l2]=(t1+nu*tau)/t2;

	return;
}


// Update genetic variances of g by e fixed effects
// prior for V_GBYE is Inv-chisq(nu,(nu-2)/nu*tau),E(V_GBYE)=tau
void GBYE_FixedCovariate_Variance(int l1,int l2,int k,int nu,double tau)  
{
	int j; double t1,t2,u,u0;

	t1=pow(gbye_fix[l1][l2][k],2);
	t2=0;
	for(j=0;j<1+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	v_gbye_fix[l1][l2][k]=(t1+nu*tau)/t2;
	
	return;
}


// Update genetic variances of g by e fixed effects
// prior for V_GBYE is Inv-chisq(nu,(nu-2)/nu*tau),E(V_GBYE)=tau
void GBYE_FixedCovariate_Variance1(int l1,int l2,int nu,double tau)  
{
	int k,j; double t1,t2,u,u0;

	t1=0,t2=0;
	for(k=0;k<nc;k++) t1=t1+pow(gbye_fix[l1][l2][k],2);

	int n_gbye=nc;
	for(j=0;j<n_gbye+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	v_gbye_fix1[l1][l2]=(t1+nu*tau)/t2;

	return;
}



// Update nongenetic effects (fixed covariates)
void FixedCovariate(int l)
{
	int i; double g[ns1],z,t1=0.0,t2=0.0,t3,u,u0;

  for(i=0;i<ns;i++)
  {
		z=coef_fix[i][l];
		g[i]=gvalue[i]-z*fix[l];
		//t1=t1+z*(y[i]-amu-g[i])/ve[i];
		t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
    t2=t2+z*z/ve[i];
  }
	t3=t2;	               // prior is uniform

	ANORMAL(&u,&u0);
	fix[l]=t1/t3+u/sqrt(t3);

	for(i=0;i<ns;i++) 
		gvalue[i]=g[i]+coef_fix[i][l]*fix[l];

	return;
}



// Update nongenetic effects (random covariates)
void RandomCovariate(int l)
{
	int i,k; double g[ns1],t1,t2,t3,u,u0;

	for(i=0;i<ns;i++) 
		g[i]=gvalue[i]-ran[l][(int)coef_ran[i][l]];

	for(k=0;k<nran1[l];k++)
	{
		t1=0,t2=0;
		for(i=0;i<ns;i++)
			if(coef_ran[i][l]==k)
			{
				//t1=t1+(y[i]-amu-g[i])/ve[i];
				t1=t1+(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
				t2=t2+1.0/ve[i];
			}
		t3=1/vran[l]+t2;

		ANORMAL(&u,&u0);
		ran[l][k]=t1/t3+u/sqrt(t3);
	}
	for(i=0;i<ns;i++) 
		gvalue[i]=g[i]+ran[l][(int)coef_ran[i][l]];

	return;
}



// Update variance of nongenetic effects (random covariates)
// prior is uniform
void RanVariance(int l)         
{
	int k; double t1=0,t2=0,u,u0;

	for(k=0;k<nran1[l];k++) t1=t1+pow(ran[l][k],2);
	for(k=0;k<nran1[l]-1;k++)
	{
    ANORMAL(&u,&u0);
    t2=t2+u*u;
	}

	vran[l]=t1/t2;      // see Gelman P301

	return;
}



/// Update QTL genotypes : generate ibd
void QTLgenotype(int l,int nl,int ql,int i)
{
	int k; double summ[ng];

	for(k=0;k<ng;k++) summ[k]=GenotypeSampling(i,l,k,ql);

  double sum1=0.0;
  for(k=0;k<ng;k++)
  {
		summ[k]=exp(-0.5*pow(y[i]-(amu+summ[k]),2)/ve[i])*qprob[nl][i][ql][k];
		sum1=sum1+summ[k];
  }
	for(k=0;k<ng;k++) summ[k]=summ[k]/sum1;

  MULTINORMAL(summ);

	pdd1=0.0,pdd2=0.0;
  for(k=0;k<ng;k++)
  {
		pdd1=pdd1+qprob[nl][i][ql][k]*(ibd==k);
    pdd2=pdd2+summ[k]*(ibd==k);
  }
	return;
}



/// Update the positions of the QTLs
void QTLPOSITION(int l,int qlnew)
{
	int i,geno1[ns1],k; double g[ns1];

  double prob0=0.0,prob1=0.0,pd10=0.0,pd20=0.0;
  for(i=0;i<ns;i++)
	{
		g[i]=gvalue[i];
		if(updategeno==1)
		{
			int kk=0;
			for(k=0;k<ng;k++)
				if(qprob[qchr[l]][i][qlnew][k]>0.99)
				{
					geno1[i]=k;
					kk=1;
				}
			if(kk==0)
			{
				QTLgenotype(l,qchr[l],qlnew,i);

				pd10=pd10+log(pdd1+1e-20);
				pd20=pd20+log(pdd2+1e-20);

				geno1[i]=ibd;
			}
			if(geno[i][l]!=geno1[i])
			{
				int ii=geno1[i];
				g[i]=GenotypeSampling(i,l,ii,qlnew);  //qlnew is not used
			}
		}

		if(updategeno==0) g[i]=GenotypeSampling(i,l,0,qlnew);  //0 is not used

		if(g[i]!=gvalue[i])
		{
			//prob0=prob0-0.5*pow(y[i]-amu-gvalue[i],2)/ve[i];
			//prob1=prob1-0.5*pow(y[i]-amu-g[i],2)/ve[i];
			prob0=prob0-0.5*pow(y[i]-amu-gvalue[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
			prob1=prob1-0.5*pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
		}
	}

  double s1=(prob1-prob0)+(pd10-pd1[l])+(pd2[l]-pd20);

  if(s1>log(RANDOM()))
	{
		qloc[l]=qlnew;

    for(i=0;i<ns;i++)
		{
			gvalue[i]=g[i];
			if(updategeno==1)
			{
				geno[i][l]=geno1[i];
				Coefficient(geno1[i]);
			}
      if(updategeno==0) Coefficient0(i,l,qloc[l]);
			for(k=0;k<nc;k++) coef[i][l][k]=x[k];
		}

		pd1[l]=pd10,pd2[l]=pd20;
	}

	return;
}



// Sampling a position
int SamplingOnePosition(int l)
{
	int nl,i,k,chr0[nlg],t,tt,ttt,grid00[tngrid]; double r,grid0[tngrid];

	for(i=0;i<nlg;i++)
	{
		chrqtl[i]=0;
		for(k=0;k<nqtl;k++) chrqtl[i]=chrqtl[i]+(qchr[k]==i&&gamma1[k]!=0);
	}

	t=0;
  for(i=0;i<nlg;i++)
	{
		if(grid[i][ngrid[i]-1]!=0&&dqq[i]!=0)
			chr0[i]=ngrid[i]-(int)(2*dqq[i]*chrqtl[i]*ngrid[i]/grid[i][ngrid[i]-1]);
		if(dqq[i]==0) chr0[i]=ngrid[i]-chrqtl[i];
		if(grid[i][ngrid[i]-1]==0) chr0[i]=0;
		if(chrqtl[i]>=chr_nqtl[i]||chr0[i]<=0) chr0[i]=0;
		t=t+chr0[i];
	}

	if(t!=0)
	{
		r=t*RANDOM();
		tt=0;
    for(i=0;i<nlg;i++)
		{
			if(r>=tt&&r<(tt+chr0[i])) qchr[l]=i;
			tt=tt+chr0[i];
		}
		nl=qchr[l];
		if(chrqtl[nl]+1>chr_nqtl[nl]||chr0[nl]==0) t=0;
	}

	if(t!=0)
	{
		if(chrqtl[nl]==0) qloc[l]=(int)(RANDOM()*ngrid[nl]);
		if(chrqtl[nl]>0)
		{
			tt=0;
			for(k=0;k<nqtl;k++)
				if(qchr[k]==nl&&gamma1[k]!=0)
				{
					grid0[tt]=grid[nl][qloc[k]];
					tt=tt+1;
				}

			qloc[l]=(int)(RANDOM()*ngrid[nl]);
			tt=0;
			for(k=0;k<chrqtl[nl];k++)
				if(fabs(grid[nl][qloc[l]]-grid0[k])<=dqq[nl]) tt=tt+1;

			if(tt!=0)
			{
				ttt=0;
				for(i=0;i<ngrid[nl];i++)
				{
					grid00[i]=1;
					for(k=0;k<chrqtl[nl];k++)
						if(fabs(grid[nl][i]-grid0[k])<=dqq[nl]) grid00[i]=0;
					ttt=ttt+grid00[i];
				}
				if(ttt!=0)
				{
					r=RANDOM()*ttt;
					tt=0;
					for(i=0;i<ngrid[nl];i++)
					{
						if(r>=tt&&r<(tt+grid00[i])) qloc[l]=i;
						tt=tt+grid00[i];
					}
				}
				if(ttt==0) t=0;
			}

			for(k=0;k<chrqtl[nl];k++)
				if(fabs(grid[nl][qloc[l]]-grid0[k])<=dqq[nl]) t=0;
		}
	}

	if(t!=0)
	{
		for(i=0;i<ns;i++)
		{
			if(updategeno==1)
			{
				double prr[ng];
				for(k=0;k<ng;k++) prr[k]=qprob[nl][i][qloc[l]][k];
				MULTINORMAL(prr);
				geno[i][l]=ibd;
				Coefficient(ibd);
			}
			if(updategeno==0) Coefficient0(i,l,qloc[l]);
			for(k=0;k<nc;k++) coef[i][l][k]=x[k];
		}
	}

	return(t);
}



// Update main effect indicators for group 0
void MainEffectIndicator_GROUP0(int l,int k)
{
	int i,k1;
	double g[ns1],bf_10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1=0,t2=0,t3,f1=0,f2=0;

	for(i=0;i<ns;i++)
	{
		double z=coef[i][l][k];
		g[i]=gvalue[i]-z*main1[l][k];
		//t1=t1+z*(y[i]-amu-g[i])/ve[i];
		t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
		t2=t2+z*z/ve[i];
	}
	t3=1/vmain[l][k]+t2;

	for(i=0;i<ns;i++)
	{
		double z=coef[i][l][k];
		//f1=f1+pow(y[i]-amu-g[i],2)/ve[i];
		//f2=f2+pow(y[i]-amu-g[i]-z*t1/t3,2)/ve[i];
		f1=f1+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
		f2=f2+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i]-z*t1/t3,2)/ve[i];
	}

	bf_10=-0.5*log(vmain[l][k])-0.5*pow(t1/t3,2)/vmain[l][k]-0.5*log(t3);
	bf_10=-0.5*f2+0.5*f1+bf_10;

	if(main1[l][k]==0) gamma_1=bf_10;
	if(main1[l][k]!=0) gamma_0=-bf_10;

	double r=log(RANDOM());
	if(main1[l][k]==0&&r<gamma_1)
	{
		double u,u0;
		ANORMAL(&u,&u0);
		main1[l][k]=t1/t3+u/sqrt(t3);
		gamma_main[l]=1;
		gamma1[l]=1;
		for(i=0;i<ns;i++) gvalue[i]=g[i]+coef[i][l][k]*main1[l][k];
	}
	if(main1[l][k]!=0&&r<gamma_0)
	{
		main1[l][k]=0;
		double sum1=0;
		for(k1=0;k1<nc;k1++) sum1=sum1+fabs(main1[l][k1]);
		if(sum1==0)
		{
			gamma_main[l]=0;
			ZeroEffect1(l);
		}
		for(i=0;i<ns;i++) gvalue[i]=g[i];
	}

	return;
}



// Update main effect indicators for group 1
void MainEffectIndicator_GROUP1(int l)
{
	int i,k;
	double g[ns1],bf_10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1[ng],t2[ng],t3[ng],f1=0,f2=0;

	for(i=0;i<ng;i++)
	{
		t1[i]=0, t2[i]=0, t3[i]=0;
	}

	for(i=0;i<ns;i++)
	{
		g[i]=gvalue[i];
		for(k=0;k<nc;k++) g[i]=g[i]-coef[i][l][k]*main1[l][k];
	}

	for(k=0;k<nc;k++)
	{
		for(i=0;i<ns;i++)
		{
			double z=coef[i][l][k];
			//t1[k]=t1[k]+z*(y[i]-amu-g[i])/ve[i];
			t1[k]=t1[k]+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
			t2[k]=t2[k]+z*z/ve[i];
		}
		t3[k]=1/vmain1[l]+t2[k];
	}

	for(i=0;i<ns;i++)
	{
		//f1=f1+pow(y[i]-amu-g[i],2)/ve[i];
		f1=f1+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
		double f3=0;
		for(k=0;k<nc;k++) f3=f3+coef[i][l][k]*t1[k]/t3[k];
		//f2=f2+pow(y[i]-amu-g[i]-f3,2)/ve[i];
		f2=f2+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i]-f3,2)/ve[i];
	}

	bf_10=0;
	for(k=0;k<nc;k++) bf_10=bf_10-0.5*log(vmain1[l])-0.5*pow(t1[k]/t3[k],2)/vmain1[l]-0.5*log(t3[k]);
	bf_10=-0.5*f2+0.5*f1+bf_10;

	if(gamma_main[l]==0) gamma_1=bf_10;
	if(gamma_main[l]!=0) gamma_0=-bf_10;

	double r=log(RANDOM());
	if(gamma_main[l]==0&&r<gamma_1)
	{
		for(k=0;k<nc;k++)
		{
			double u,u0;
			ANORMAL(&u,&u0);
			main1[l][k]=t1[k]/t3[k]+u/sqrt(t3[k]);
		}
		gamma_main[l]=1;
		gamma1[l]=1;
		for(i=0;i<ns;i++)
		{
			gvalue[i]=g[i];
			for(k=0;k<nc;k++) gvalue[i]=gvalue[i]+coef[i][l][k]*main1[l][k];
		}
	}
	if(gamma_main[l]!=0&&r<gamma_0)
	{
		for(k=0;k<nc;k++) main1[l][k]=0;
		gamma_main[l]=0;
		for(i=0;i<ns;i++) gvalue[i]=g[i];
		ZeroEffect1(l);
	}

	return;
}



// Update epistatic effect indicators for group 0
void EpistasisIndicator_GROUP0(int l1,int l2,int k1,int k2)
{
	int i,k01,k02;
	double g[ns1],bf_10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1=0,t2=0,t3,f1=0,f2=0;

	if(w_epistasis!=0)
	{
		for(i=0;i<ns;i++)
		{
			double z=coef[i][l1][k1]*coef[i][l2][k2];
			g[i]=gvalue[i]-z*epistatic[l1][l2][k1][k2];
			//t1=t1+z*(y[i]-amu-g[i])/ve[i];
			t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
			t2=t2+z*z/ve[i];
		}
		t3=1/vepistasis[l1][l2][k1][k2]+t2;

		for(i=0;i<ns;i++)
		{
			double z=coef[i][l1][k1]*coef[i][l2][k2];
			//f1=f1+pow(y[i]-amu-g[i],2)/ve[i];
			//f2=f2+pow(y[i]-amu-g[i]-z*t1/t3,2)/ve[i];
			f1=f1+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
			f2=f2+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i]-z*t1/t3,2)/ve[i];
		}

		bf_10=-0.5*log(vepistasis[l1][l2][k1][k2])-0.5*pow(t1/t3,2)/vepistasis[l1][l2][k1][k2]-0.5*log(t3);
		bf_10=-0.5*f2+0.5*f1+bf_10;

		if(epistatic[l1][l2][k1][k2]==0) gamma_1=bf_10;
		if(epistatic[l1][l2][k1][k2]!=0) gamma_0=-bf_10;

		double r=log(RANDOM());
		if(epistatic[l1][l2][k1][k2]==0&&r<gamma_1)
		{
			double u,u0;
			ANORMAL(&u,&u0);
			epistatic[l1][l2][k1][k2]=t1/t3+u/sqrt(t3);
			gamma_epistasis[l1][l2]=1;
			gamma1[l1]=1,gamma1[l2]=1;
			for(i=0;i<ns;i++) gvalue[i]=g[i]+coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
		}
		if(epistatic[l1][l2][k1][k2]!=0&&r<gamma_0)
		{
			epistatic[l1][l2][k1][k2]=0;
			double sum1=0;
			for(k01=0;k01<nc;k01++)
				for(k02=0;k02<nc;k02++) sum1=sum1+fabs(epistatic[l1][l2][k01][k02]);
			if(sum1==0)
			{
				gamma_epistasis[l1][l2]=0;
				ZeroEffect2(l1,l2);
			}
			for(i=0;i<ns;i++) gvalue[i]=g[i];
		}

	}

	if(w_epistasis==0&&epistatic[l1][l2][k1][k2]!=0)
	{
		for(i=0;i<ns;i++) gvalue[i]=gvalue[i]-coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
		epistatic[l1][l2][k1][k2]=0;
		double sum1=0;
		for(k01=0;k01<nc;k01++)
			for(k02=0;k02<nc;k02++) sum1=sum1+fabs(epistatic[l1][l2][k01][k02]);
		if(sum1==0)
		{
			gamma_epistasis[l1][l2]=0;
			ZeroEffect2(l1,l2);
		}
	}


	return;
}



// Update epistatic effect indicators for group 1
void EpistasisIndicator_GROUP1(int l1,int l2)
{
	int i,k1,k2;
	double g[ns1],bf_10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1[ng][ng],t2[ng][ng],t3[ng][ng],f1=0,f2=0;

	if(w_epistasis!=0)
	{

	for(k1=0;k1<ng;k1++)
	   for(k2=0;k2<ng;k2++)
	   {
           t1[k1][k2]=0, t2[k1][k2]=0, t3[k1][k2]=0;
	   }

	for(i=0;i<ns;i++)
	{
		g[i]=gvalue[i];
		for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++) g[i]=g[i]-coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
	}

	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++)
		{
			for(i=0;i<ns;i++)
			{
				double z=coef[i][l1][k1]*coef[i][l2][k2];
				//t1[k1][k2]=t1[k1][k2]+z*(y[i]-amu-g[i])/ve[i];
				t1[k1][k2]=t1[k1][k2]+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
				t2[k1][k2]=t2[k1][k2]+z*z/ve[i];
			}
			t3[k1][k2]=1/vepistasis1[l1][l2]+t2[k1][k2];
		}

	for(i=0;i<ns;i++)
	{
		//f1=f1+pow(y[i]-amu-g[i],2)/ve[i];
		f1=f1+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
		double f3=0;
		for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++) f3=f3+coef[i][l1][k1]*coef[i][l2][k2]*t1[k1][k2]/t3[k1][k2];
		//f2=f2+pow(y[i]-amu-g[i]-f3,2)/ve[i];
		f2=f2+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i]-f3,2)/ve[i];
	}

	bf_10=0;
	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++)
			bf_10=bf_10-0.5*log(vepistasis1[l1][l2])-0.5*pow(t1[k1][k2]/t3[k1][k2],2)/vepistasis1[l1][l2]-0.5*log(t3[k1][k2]);
	bf_10=-0.5*f2+0.5*f1+bf_10;

	if(gamma_epistasis[l1][l2]==0) gamma_1=bf_10;
	if(gamma_epistasis[l1][l2]!=0) gamma_0=-bf_10;

	double r=log(RANDOM());
	if(gamma_epistasis[l1][l2]==0&&r<gamma_1)
	{
		for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++)
			{
				double u,u0;
				ANORMAL(&u,&u0);
				epistatic[l1][l2][k1][k2]=t1[k1][k2]/t3[k1][k2]+u/sqrt(t3[k1][k2]);
			}
		gamma_epistasis[l1][l2]=1;
		gamma1[l1]=1,gamma1[l2]=1;
		for(i=0;i<ns;i++)
		{
			gvalue[i]=g[i];
			for(k1=0;k1<nc;k1++)
				for(k2=0;k2<nc;k2++) gvalue[i]=gvalue[i]+coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
		}
	}
	if(gamma_epistasis[l1][l2]!=0&&r<gamma_0)
	{
		for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++) epistatic[l1][l2][k1][k2]=0;
		gamma_epistasis[l1][l2]=0;
		for(i=0;i<ns;i++) gvalue[i]=g[i];
		ZeroEffect2(l1,l2);
	}

	}

	if(w_epistasis==0&&gamma_epistasis[l1][l2]!=0)
	{
		for(i=0;i<ns;i++)
			for(k1=0;k1<nc;k1++)
				for(k2=0;k2<nc;k2++) gvalue[i]=gvalue[i]-coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
		for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++) epistatic[l1][l2][k1][k2]=0;
		gamma_epistasis[l1][l2]=0;
		ZeroEffect2(l1,l2);
	}

	return;
}



// Update g by e fixed effect indicators for group 0
void GBYE_FIX_Indicator_GROUP0(int l1,int l2,int k)  //use the constraint model
{
	int i,k1;
	double g[ns1],bf_10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1=0,t2=0,t3,f1=0,f2=0;


	for(i=0;i<ns;i++)
	{
		double z=coef_fix[i][l1]*coef[i][l2][k];
		g[i]=gvalue[i]-z*gbye_fix[l1][l2][k];
		//t1=t1+z*(y[i]-amu-g[i])/ve[i];
		t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
		t2=t2+z*z/ve[i];
	}
	t3=1/v_gbye_fix[l1][l2][k]+t2;

	for(i=0;i<ns;i++)
	{
		double z=coef_fix[i][l1]*coef[i][l2][k];
		//f1=f1+pow(y[i]-amu-g[i],2)/ve[i];
		//f2=f2+pow(y[i]-amu-g[i]-z*t1/t3,2)/ve[i];
		f1=f1+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
		f2=f2+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i]-z*t1/t3,2)/ve[i];

	}

	bf_10=-0.5*log(v_gbye_fix[l1][l2][k])-0.5*pow(t1/t3,2)/v_gbye_fix[l1][l2][k]-0.5*log(t3);
	bf_10=-0.5*f2+0.5*f1+bf_10;

	if(gbye_fix[l1][l2][k]==0) gamma_1=bf_10;
	if(gbye_fix[l1][l2][k]!=0) gamma_0=-bf_10;

	double r=log(RANDOM());
	if(gbye_fix[l1][l2][k]==0&&r<gamma_1)
	{
		double u,u0;
		ANORMAL(&u,&u0);
		gbye_fix[l1][l2][k]=t1/t3+u/sqrt(t3);
		gamma_gbye[l1][l2]=1;
		gamma1[l2]=1;
		for(i=0;i<ns;i++) gvalue[i]=g[i]+coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];
	}
	if(gbye_fix[l1][l2][k]!=0&&r<gamma_0)
	{
		gbye_fix[l1][l2][k]=0;
		double sum1=0;
		for(k1=0;k1<nc;k1++) sum1=sum1+fabs(gbye_fix[l1][l2][k1]);
		if(sum1==0)
		{
			gamma_gbye[l1][l2]=0;
			ZeroEffect1(l2);
		}
		for(i=0;i<ns;i++) gvalue[i]=g[i];
	}

	return;
}



// Update g by e fixed effect indicators for group 1
void GBYE_FIX_Indicator_GROUP1(int l1,int l2)
{
	int i,k;
	double g[ns1],bf_10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1[ng],t2[ng],t3[ng],f1=0,f2=0;

	for(i=0;i<ng;i++)
	{
		t1[i]=0, t2[i]=0, t3[i]=0;
	}

	for(i=0;i<ns;i++)
	{
		g[i]=gvalue[i];
		for(k=0;k<nc;k++)
			g[i]=g[i]-coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];
	}

	for(k=0;k<nc;k++)
	{
		for(i=0;i<ns;i++)
		{
			double z=coef_fix[i][l1]*coef[i][l2][k];
			//t1[k]=t1[k]+z*(y[i]-amu-g[i])/ve[i];
			t1[k]=t1[k]+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
			t2[k]=t2[k]+z*z/ve[i];
		}
		t3[k]=1/v_gbye_fix1[l1][l2]+t2[k];
	}

	for(i=0;i<ns;i++)
	{
		//f1=f1+pow(y[i]-amu-g[i],2)/ve[i];
		f1=f1+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
		double f3=0;
    for(k=0;k<nc;k++) f3=f3+coef_fix[i][l1]*coef[i][l2][k]*t1[k]/t3[k];
		//f2=f2+pow(y[i]-amu-g[i]-f3,2)/ve[i];
		f2=f2+pow(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i]-f3,2)/ve[i];
	}

	bf_10=0;
	for(k=0;k<nc;k++) bf_10=bf_10-0.5*log(v_gbye_fix1[l1][l2])-0.5*pow(t1[k]/t3[k],2)/v_gbye_fix1[l1][l2]-0.5*log(t3[k]);
	bf_10=-0.5*f2+0.5*f1+bf_10;

	if(gamma_gbye[l1][l2]==0) gamma_1=bf_10;
	if(gamma_gbye[l1][l2]!=0) gamma_0=-bf_10;

	double r=log(RANDOM());
	if(gamma_gbye[l1][l2]==0&&r<gamma_1)
	{
		for(k=0;k<nc;k++)
		{
			double u,u0;
			ANORMAL(&u,&u0);
			gbye_fix[l1][l2][k]=t1[k]/t3[k]+u/sqrt(t3[k]);
		}
		gamma_gbye[l1][l2]=1;
		gamma1[l2]=1;
		for(i=0;i<ns;i++)
		{
			gvalue[i]=g[i];
			for(k=0;k<nc;k++) gvalue[i]=gvalue[i]+coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];
		}
	}
	if(gamma_gbye[l1][l2]!=0&&r<gamma_0)
	{
		for(k=0;k<nc;k++) gbye_fix[l1][l2][k]=0;
		gamma_gbye[l1][l2]=0;
		for(i=0;i<ns;i++) gvalue[i]=g[i];
		ZeroEffect1(l2);
	}

	return;
}



// Update main effects
void MainEffect1(int l)
{
	int i,k; double g[ns1],t1,t2,t3,u,u0;

	for(k=0;k<nc;k++)
	{
		t1=0,t2=0;
		for(i=0;i<ns;i++)
		{
			double z=coef[i][l][k];
			g[i]=gvalue[i]-z*main1[l][k];
			//t1=t1+z*(y[i]-amu-g[i])/ve[i];
			t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
			t2=t2+pow(z,2)/ve[i];
		}
		double v=vmain1[l];
		t3=1/v+t2;

		ANORMAL(&u,&u0);
		main1[l][k]=t1/t3+u/sqrt(t3);

		for(i=0;i<ns;i++) gvalue[i]=g[i]+coef[i][l][k]*main1[l][k];
	}

	return;
}


// Update epistatic effects
void EpistaticEffect1(int l1,int l2)
{
	int i,k1,k2; double g[ns1],t1,t2,t3,u,u0;

	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++)
		{
			t1=0,t2=0;
			for(i=0;i<ns;i++)
			{
				double z=coef[i][l1][k1]*coef[i][l2][k2];
				g[i]=gvalue[i]-z*epistatic[l1][l2][k1][k2];
				//t1=t1+z*(y[i]-amu-g[i])/ve[i];
				t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
				t2=t2+pow(z,2)/ve[i];
			}
			double v=vepistasis1[l1][l2];
			t3=1/v+t2;

			ANORMAL(&u,&u0);
			epistatic[l1][l2][k1][k2]=t1/t3+u/sqrt(t3);

			for(i=0;i<ns;i++) gvalue[i]=g[i]+coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
		}

	return;
}

// Update g by e fixed effects
void GBYE_FixedCovariate1(int l1,int l2)
{
	int i,k; double g[ns1],t1,t2,t3,u,u0;

	for(k=0;k<nc;k++)
	{
		t1=0,t2=0;
		for(i=0;i<ns;i++)
		{
			double z=coef_fix[i][l1]*coef[i][l2][k];
			g[i]=gvalue[i]-z*gbye_fix[l1][l2][k];
			//t1=t1+z*(y[i]-amu-g[i])/ve[i];
			t1=t1+z*(y[i]-amu-g[i]-vbvalue[i]-qcvalue[i])/ve[i];
			t2=t2+pow(z,2)/ve[i];
		}
		double v=v_gbye_fix1[l1][l2];
		t3=1/v+t2;

		ANORMAL(&u,&u0);
		gbye_fix[l1][l2][k]=t1/t3+u/sqrt(t3);

		for(i=0;i<ns;i++) gvalue[i]=g[i]+coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];
	}

	return;
}


void RandomOmega()
{
	double *mc, *gval;
	double sigma_ome, mean_ome, mcmc, mcgval;
	int i;
	
	// Compute matrix mc
	mc = (double*) malloc(ns1*sizeof(double));
	
	XprimeVec(kin_m, latent_c, ns1, ns1, mc);
 
	//for (i=0;i<ns1;i++) fprintf(log_file,"%f\n",mc[i]);
	
	// Compute matrix gval
	gval =  (double*) malloc(ns1*sizeof(double));

	for (i=0; i<ns1; i++) gval[i] = (y[i]-amu-gvalue[i]);
	//for (i=0; i<ns1; i++) fprintf(log_file,"%f\n",gval[i]);

	// Compute sigma_ome and mean_ome
	mcmc = 0;
	for (i=0; i<ns1; i++) mcmc += mc[i]*mc[i];

	mcgval = 0;
	for (i=0; i<ns1; i++) mcgval += mc[i]*gval[i];

	sigma_ome = 1.0/(mcmc/ve[0]+1.0/omega_var);
	mean_ome = sigma_ome*(mcgval/ve[0]+omega_mean/omega_var);
	
	/*Rprintf("mcmc=%f\n",mcmc); Rprintf("mcgval=%f\n",mcgval);
	Rprintf("ve[0]=%f\n",ve[0]);
	Rprintf("omega_mean=%f\n",omega_mean); Rprintf("omega_var=%f\n",omega_var);
	Rprintf("mean_ome=%f\n",mean_ome); Rprintf("sigma_ome=%f\n",sigma_ome);*/
	
	kin_omega[0] = TrunNormal(0, R_PosInf, mean_ome, sigma_ome);
	
	/*Rprintf("%f\n",kin_omega[0]);
	for (i=0; i<1000; i++){
		kin_omega[0] = TrunNormal(0, R_PosInf, mean_ome, sigma_ome);
		fprintf(log_file,"%f\n",kin_omega[0]);
	}*/

	free(gval);	
	free(mc);
}


void LatentC()
{
	double **inv, **chol, **sigma_c, **tmp, **tmp_inv, **tmp_chol;
	double **q, **qt, **qtq, *gval, *qgval, *mean_c;
	int i, j, k, s, *t, sum_r;

	s = num_subject; t = num_timepts;
	
	// compute qtq
	q = (double**) malloc(ns1*sizeof(double*));
	qt = (double**) malloc(ns1*sizeof(double*));
	qtq = (double**) malloc(ns1*sizeof(double*));

	for (i=0; i<ns1; i++) {
		q[i] = (double*) malloc(ns1*sizeof(double));
		qt[i] = (double*) malloc(ns1*sizeof(double));
		qtq[i] = (double*) malloc(ns1*sizeof(double));
	}

	for (i=0; i<ns1; i++) 
		for (j=0; j<ns1; j++) {
			q[i][j] = kin_omega[0]*kin_m[i][j];
			qt[j][i] = q[i][j];
			qtq[i][j] = kin_omega[0]*kin_omega[0]*mtm[i][j];
		}

	/*for (i=0; i<ns1; i++) {
		for (j=0; j<ns1; j++) fprintf(log_file,"%f,",qtq[i][j]);
		fprintf(log_file,"\n");
	}*/

	// compute sigma_c
	inv = (double**) malloc(ns1*sizeof(double*));
	chol = (double**) malloc(ns1*sizeof(double*));
	sigma_c = (double**) malloc(ns1*sizeof(double*));
	
	for (i=0; i<ns1; i++) {
		inv[i] = (double*) malloc(ns1*sizeof(double));
		chol[i] = (double*) malloc(ns1*sizeof(double));
		sigma_c[i] = (double*) malloc(ns1*sizeof(double));
	}

	// allocate tmp matrix
  tmp = (double**) malloc(max_num_timept*sizeof(double*));
	tmp_inv = (double**) malloc(max_num_timept*sizeof(double*));
	tmp_chol = (double**) malloc(max_num_timept*sizeof(double*));
  for (i=0; i<max_num_timept; i++) {
		tmp[i] = (double*) malloc(max_num_timept*sizeof(double));
		tmp_inv[i] = (double*) malloc(max_num_timept*sizeof(double));
		tmp_chol[i] = (double*) malloc(max_num_timept*sizeof(double));
	}

	for (i=0; i<ns1; i++){
		for (j=0; j<ns1; j++){
			inv[i][j] = qtq[i][j]/ve[0];
			if (i == j) inv[i][j] += 1;
		}
	}

	//Rprintf("ve[0]=%f\n",ve[0]);
	
	/*for (i=0; i<ns1; i++) {
		for (j=0; j<ns1; j++) fprintf(log_file,"%f,",inv[i][j]);
		fprintf(log_file,"\n");
	}*/
	
	//INVERSE(inv, ns1, sigma_c);
	//Cholesky(sigma_c, ns1, chol);
	
	// Inverse and Cholesky decomposition
	for (i=0; i<ns1; i++)
		for (j=0; j<ns1; j++) {
			sigma_c[i][j] = 0;
			chol[i][j] = 0;
		}
	
	sum_r = 0;
	for (k=0; k<s; k++) {

		for (i=0; i<t[k]; i++) 
			for (j=0; j<t[k]; j++) tmp[i][j] = inv[sum_r+i][sum_r+j];
	
		if (t[k]==1) tmp_inv[0][0] = 1.0/tmp[0][0];
		else INVERSE(tmp, t[k], tmp_inv);

		Cholesky(tmp_inv, t[k], tmp_chol);
		
		for (i=0; i<t[k]; i++) 
			for (j=0; j<t[k]; j++) sigma_c[sum_r+i][sum_r+j] = tmp_inv[i][j];

		for (i=0; i<t[k]; i++) 
			for (j=0; j<t[k]; j++) chol[sum_r+i][sum_r+j] = tmp_chol[i][j];

		sum_r += t[k]; 
	}

	/*for (i=0; i<ns1; i++) {
		for (j=0; j<ns1; j++) fprintf(log_file,"%f,",sigma_c[i][j]);
		fprintf(log_file,"\n");
	}
	for (i=0; i<ns1; i++) {
		for (j=0; j<ns1; j++) fprintf(log_file,"%f,",chol[i][j]);
		fprintf(log_file,"\n");
	}*/

  // Compute mean_c 
	mean_c = (double*) malloc(ns1*sizeof(double));
	gval =  (double*) malloc(ns1*sizeof(double));
	qgval =  (double*) malloc(ns1*sizeof(double));

	for(i=0; i<ns1; i++) gval[i] = (y[i]-amu-gvalue[i])/ve[i];
	//for (i=0; i<ns1; i++) fprintf(log_file,"%f\n",gval[i]);	
	
	XprimeVec(qt, gval, ns1, ns1, qgval);
	//for (i=0; i<ns1; i++) fprintf(log_file,"%f\n",qgval[i]);

	XprimeVec(sigma_c, qgval, ns1, ns1, mean_c);
	//for (i=0; i<ns1; i++) fprintf(log_file,"%f\n",mean_c[i]);	

	// Sample latent variable b
	Multivariate_RNORM(chol, mean_c, ns1, latent_c);
	
	/*for (i=0; i<ns1; i++) fprintf(log_file,"%f\n",latent_c[i]);	
	for (j=0; j<5000; j++){
		Multivariate_RNORM(chol, mean_c, ns1, latent_c);
		for (i=0; i<ns1; i++) fprintf(log_file,"%f,",latent_c[i]);
		fprintf(log_file,"\n");
	}*/ 
	
	// Set qcvalue
	XprimeVec(q, latent_c, ns1, ns1, qcvalue);
	//for (i=0; i<ns1; i++) fprintf(log_file,"%f,\n",qcvalue[i]);

	// deallocate memory
	free(mean_c);
	free(gval);
	free(qgval);

	for (i=0; i<max_num_timept; i++) {
		free(tmp[i]); 
		free(tmp_inv[i]);
		free(tmp_chol[i]);
	}
  free(tmp); 
	free(tmp_inv);
	free(tmp_chol);

	for (i=0; i<ns1; i++) {
		free(inv[i]);
		free(chol[i]); 
		free(sigma_c[i]);
	}

	free(inv); 
	free(chol);
	free(sigma_c);
	
	for (i=0; i<ns1; i++) {
		free(q[i]);
		free(qt[i]); 
		free(qtq[i]);
	}

	free(q);
	free(qt);
	free(qtq);

}


// Set Incidence Matrix grid_p for grid-based model 
void IncidenceMatrix()
{
	int i, j, near_idx=0;
	double *time, *intv_pts;
	double min_time = DBL_MAX, max_time = DBL_MIN, intv;

	max_num_timept = INT_MIN;
	for (i=0; i<num_subject; i++) max_num_timept = MAX(max_num_timept, num_timepts[i]);

  //Rprintf("max_num_timept=%d\n",max_num_timept);

	/* time should range from 0 to 1 */
	time = (double*) malloc(ns1*sizeof(double));
	for (i=0; i<ns1 ;i++){
		time[i] = coef_time[i];
		min_time = MIN(min_time, time[i]);
		max_time = MAX(max_time, time[i]);
	}
	for (i=0; i<ns1 ;i++)	time[i] = (time[i]-min_time) / (max_time-min_time);

  //for (i=0; i<num_subject; i++) Rprintf("time[%d]=%f\n",i,time[i]);

	/* set grid_p matrix */
	intv_pts = (double*) malloc(num_grid*sizeof(double));
	intv = (double) 1/ (double)(num_grid-1);
	intv_pts[0] = (double)0; intv_pts[num_grid-1] = 1.0;
	for (i=1; i<num_grid-1; i++) intv_pts[i] = intv*i;
	for (i=0; i<ns1 ;i++){
		for (j=0; j<num_grid; j++) {
			if (floor_p(fabs(intv_pts[j] - time[i]),6)<=floor_p(intv,6)) {
				near_idx = j;
				break;
			}
		}

		grid_p[num_grid*i+near_idx] = (double) fabs(intv_pts[near_idx+1] - time[i])/ intv;
		grid_p[num_grid*i+near_idx+1] = (double) fabs(intv_pts[near_idx] - time[i])/ intv;
	}

	free(intv_pts);
	free(time);

}


// Update Delta Matrix for Random effect 
void RandomDelta()
{
	double **w, **xi;
	double *sigma_del, *mean_del, *p, *b, *gval, bpsi, wdel, wtw, wtxi;
	int i, j, k, l, r, s, *t, idx;//, idx1;
	r = num_grid; s = num_subject; t = num_timepts;
	p = grid_p; b = latent_b;
	
	// Compute matrix w
	w = (double**) malloc(r*sizeof(double*));
	xi = (double**) malloc(r*sizeof(double*));
	for (i=0; i<r; i++){
		w[i] = (double*) malloc(ns1*sizeof(double));
		xi[i] = (double*) malloc(ns1*sizeof(double));
	}

	idx = 0;
	for (i=0; i<s; i++){
		for (j=0; j<t[i]; j++){
			//idx1 = 0;
			for (l=0; l<r; l++){
				bpsi = 0;
				/*for (k=0; k<l; k++) bpsi += b[i*r+k]*ran_psi[idx1+k];  // wrong!
				if (l!=0) idx1 += l;*/
				for (k=0; k<l; k++) bpsi += b[i*r+k]*ran_psi[k*r-k*(k+1)/2+(l-k-1)];
				w[l][idx] = p[idx*r+l]*(b[i*r+l]+bpsi);
			}
			idx++;
		}
	}
 
	/*
	for (i=0;i<s*r;i++) fprintf(log_file,"b[%d]=%f\n",i,b[i]);
	for (i=0;i<r*(r-1)/2;i++) fprintf(log_file,"ran_psi[%d]=%f\n",i,ran_psi[i]);
	for (i=0;i<ns1*r;i++) fprintf(log_file,"p[%d]=%f\n",i,p[i]);
	for (i=0; i<ns1; i++)	{
		for (j=0; j<r; j++){
			fprintf(log_file,"%f,",w[j][i]);
		}
		fprintf(log_file,"\n");
	}
	fprintf(log_file,"\n");*/

	//for (i=0;i<r;i++) fprintf(log_file,"ran_delta[%d]=%f\n",i,ran_delta[i]);
	
	// Compute matrix xi
	gval =  (double*) malloc(ns1*sizeof(double));

	//for (i=0; i<ns1; i++) gval[i] = (y[i]-amu-gvalue[i]);
	//for (i=0; i<ns1; i++) fprintf(log_file,"gval1[%d]=%f,\n",i,gval[i]);

	for(i=0; i<ns1; i++) {
		wdel = 0;
		for (j=0; j<r; j++) wdel += w[j][i]*ran_delta[j];
		gval[i] = (y[i]-amu-gvalue[i]-wdel);
	}

	//for (i=0; i<ns1; i++) fprintf(log_file,"gval2[%d]=%f,\n",i,gval[i]);

	for (i=0; i<ns1; i++)
		for (j=0; j<r; j++) xi[j][i] = gval[i] + w[j][i]*ran_delta[j];
	

	/*for (i=0; i<ns1; i++)	{
		for (j=0; j<r; j++){
			fprintf(log_file,"%f,",xi[j][i]);
		}
		fprintf(log_file,"\n");
	}*/

	
	// Compute sigma_del and mean_del
	sigma_del =  (double*) malloc(r*sizeof(double));
	mean_del =  (double*) malloc(r*sizeof(double));

	for (i=0; i<r; i++){
		wtw=0; wtxi=0;
		for (j=0; j<ns1; j++) {
			wtw += w[i][j]*w[i][j]; 
			wtxi += w[i][j]*xi[i][j];
		}
		//fprintf(log_file,"wtw[%d]=%f\t",i,wtw);
		//fprintf(log_file,"wtxi[%d]=%f\t ve[0]=%f\n",i,wtxi,ve[1]);
		sigma_del[i] = 1.0/(wtw/ve[0]+1.0/delta_var);
		mean_del[i] = sigma_del[i]*(wtxi/ve[0]+delta_mean/delta_var);
	}
	
	//Rprintf("ve[0]=%f, delta_var=%f, delta_mean=%f\n",ve[0],delta_var,delta_mean);

//	for (i=0; i<r; i++) fprintf(log_file,"mean_del[%d]=%f\n",i,mean_del[i]);
//	for (i=0; i<r; i++) fprintf(log_file,"sigma_del[%d]=%f\n",i,sigma_del[i]);
	
	for (i=0; i<r; i++){
		ran_delta[i] = TrunNormal(0, R_PosInf, mean_del[i], sigma_del[i]);
	}

//	for (i=0; i<r; i++) fprintf(log_file,"ran_delta[%d]=%f\n",i,ran_delta[i]);

	/*
	double a = 0;
	for (i=0; i<5000; i++){
		if (i%100==0&&i!=0) fprintf(log_file,"\n");
		a = TrunNormal(0, R_PosInf, 2, 5);
		fprintf(log_file,"%f,",a);
	}*/


	free(sigma_del);
	free(mean_del);
	free(gval);

	for (i=0; i<r; i++) {
		free(w[i]);
		free(xi[i]); 
	}
	
	free(w);
	free(xi);

}


// Update Psi Matrix for Random effect 
void RandomPsi()
{
	double **sigma_psi, **inv, **chol, **r0, **r0_inv;
	double *p, *b, *u, *utu, *gval, *ugval, *ugval1, *ut, *mean_psi, *bdelp;
	double u0, u1, temp;
	int i, j, k, l, r, s, *t, idx, idx1, z;
	r = num_grid; s = num_subject; t = num_timepts; z = (int)r*(r-1)/2;
	p = grid_p; b = latent_b;

	// Compute matrix u and uvu
	u = (double*) malloc(ns1*z*sizeof(double));
	utu = (double*) malloc(z*z*sizeof(double));

	for (i=0; i<ns1*z; i++) u[i] = 0;

	idx = 0;
	for (i=0; i<s; i++){
		for (j=0; j<t[i]; j++){
			idx1 = 0;
			for (k=0; k<r-1; k++){
				for (l=k+1; l<r ;l++){
					u[idx*z+idx1] = b[i*r+k]*ran_delta[l]*p[idx*r+l];
					idx1++;
				}
			}
			idx++;
		}
	}
  
	/*for (i=0;i<s*r;i++) fprintf(log_file,"b[%d]=%f\n",i,b[i]);
	for (i=0;i<r;i++) fprintf(log_file,"ran_delta[%d]=%f\n",i,ran_delta[i]);
	for (i=0;i<ns1*r;i++) fprintf(log_file,"p[%d]=%f\n",i,p[i]);
	for (i=0; i<ns1*z; i++)	{
		if (i%3==0&&i!=0) fprintf(log_file,"\n");
		fprintf(log_file,"%f,",u[i]);
	}*/

	matrix_xtx(u, utu, ns1, z);

	// compute sigma_psi
	sigma_psi = (double**) malloc(z*sizeof(double*));
	chol = (double**) malloc(z*sizeof(double*));
	inv = (double**) malloc(z*sizeof(double*));
	r0 = (double**) malloc(z*sizeof(double*));
	r0_inv = (double**) malloc(z*sizeof(double*));
	for (i=0; i<z; i++) {
		sigma_psi[i] = (double*) malloc(z*sizeof(double));
		chol[i] = (double*) malloc(z*sizeof(double));
		inv[i] = (double*) malloc(z*sizeof(double));
		r0[i] = (double*) malloc(z*sizeof(double));
		r0_inv[i] = (double*) malloc(z*sizeof(double));
	}

	for (i=0; i<z; i++)
		for (j=0; j<z; j++) r0[i][j] = psi_var[i*z+j];

	if (z==1) r0_inv[0][0] = 1.0/r0[0][0];
	else INVERSE(r0,z,r0_inv);

	//for (i=0; i<z; i++) 
	//	for (j=0; j<z; j++) fprintf(log_file,"r0_inv[%d][%d]=%f\n",i,j,r0_inv[i][j]);

	//fprintf(log_file,"ve[0]=%f\n",ve[0]);

	for (i=0; i<z; i++)
		for (j=0; j<z; j++) inv[i][j] = utu[i*z+j]/ve[0] + r0_inv[i][j];
	
	//for (i=0; i<z; i++) 
	//	for (j=0; j<z; j++) fprintf(log_file,"inv[%d][%d]=%f\n",i,j,inv[i][j]);
	
	if (z==1) sigma_psi[0][0] = 1.0/inv[0][0];
	else INVERSE(inv,z,sigma_psi);

//	for (i=0; i<z; i++) 
//		for (j=0; j<z; j++) fprintf(log_file,"sigma_psi[%d][%d]=%f\n",i,j,sigma_psi[i][j]);

	// Compute mean_psi
	mean_psi = (double*) malloc(z*sizeof(double));
	gval =  (double*) malloc(ns1*sizeof(double));
	ugval =  (double*) malloc(z*sizeof(double));
	ugval1 =  (double*) malloc(z*sizeof(double));
	ut = (double*) malloc(ns1*z*sizeof(double));
	bdelp =  (double*) malloc(ns1*sizeof(double));

	idx = 0;
	for (i=0; i<s; i++){
		for (j=0; j<t[i]; j++){
			temp = 0;
			for (k=0; k<r; k++) temp += b[i*r+k]*ran_delta[k]*p[idx*r+k];
			bdelp[idx] = temp;
			idx++;
		}
	}

	//for (i=0; i<ns1; i++) fprintf(log_file,"%f\n",bdelp[i]);
	//fprintf(log_file,"\n");

	for(i=0; i<ns1; i++) gval[i] = (y[i]-amu-gvalue[i]-bdelp[i])/ve[i];

	//for (i=0; i<ns1; i++) fprintf(log_file,"%f\n",gval[i]);

	matrix_transpose(u, ut, ns1, z);
	matrix_product(ut, gval, ugval, z, 1, ns1);
	XprimeVec(r0_inv, psi_mean, z, z, ugval1);

	//for (i=0; i<z; i++) fprintf(log_file,"ugval[%d]=%f\n",i,ugval[i]);
	//for (i=0; i<z; i++) fprintf(log_file,"ugval1[%d]=%f\n",i,ugval1[i]);

	for (i=0; i<z; i++) ugval[i] += ugval1[i];

	//for (i=0; i<z; i++) fprintf(log_file,"ugval[%d]=%f\n",i,ugval[i]);

	XprimeVec(sigma_psi, ugval, z, z, mean_psi);

//	for (i=0; i<z; i++) fprintf(log_file,"mean_psi[%d]=%f\n",i,mean_psi[i]);

	// Sample latent variable b
	if (z==1) {
		ANORMAL(&u0,&u1);
		ran_psi[0] = mean_psi[0]+u0*sigma_psi[0][0];
	} else {
		Cholesky(sigma_psi, z, chol);
		Multivariate_RNORM(chol, mean_psi, z, ran_psi);
	}

//	for (i=0; i<z; i++) fprintf(log_file,"ran_psi[%d]=%f\n",i,ran_psi[i]);

	//for (i=0; i<z; i++) 
	//	for (j=0; j<z; j++)
	//		Rprintf("chol[%d][%d]=%f\n",i,j,chol[i][j]);

	/*
	for (j=0; j<1000; j++){
		Multivariate_RNORM(chol, mean_psi, z, ran_psi);
		for (i=0; i<z; i++) {
			fprintf(log_file,"%f,",ran_psi[i]);
		}
		fprintf(log_file,"\n");
	}*/

	// deallocate memory
	free(bdelp);
	free(ut);
	free(ugval);
	free(ugval1);
	free(gval);
	free(mean_psi);

	for (i=0; i<z; i++) {
		free(sigma_psi[i]);
		free(chol[i]); 
		free(inv[i]);
		free(r0[i]);
		free(r0_inv[i]);
	}

	free(sigma_psi);
	free(chol);
	free(inv); 
	free(r0);
	free(r0_inv);

	free(utu);
	free(u);

}


// Compute random matrix vb 
void RandomV()
{
	double *p, *del, *psi, *delpsi, *v;
	int i, j, r, idx;
	r = num_grid;
	p = grid_p; v = grid_v;

	/* allocate memory */
	del = (double*) malloc(r*r*sizeof(double));
	psi = (double*) malloc(r*r*sizeof(double));
	delpsi = (double*) malloc(r*r*sizeof(double));

	/* v matrix */
	for (i=0; i<r*r; i++) {
			del[i] = 0; psi[i] = 0;
	}

	for (i=0; i<r; i++){
		del[i*(r+1)] = ran_delta[i];
		psi[i*(r+1)] = 1;
	}

	idx=0;
	for (i=0; i<r; i++) {
		for (j=(i+1); j<r; j++) {
			 psi[j*r+i] = ran_psi[idx];
			 idx++;
		}
	}
	
	/*idx=0;
	for (i=0; i<r; i++) {
		for (j=0; j<i; j++) {
			 psi[i*r+j] = ran_psi[idx];
			 idx++;
		}
	}*/

	matrix_product(del,psi,delpsi,r,r,r);
	matrix_product(p,delpsi,v,ns1,r,r);

	//for (i=0; i<r*r; i++) fprintf(log_file,"delpsi[%d]=%f\n",i,delpsi[i]);
	//for (i=0; i<ns1*r; i++) fprintf(log_file,"grid_v[%d]=%f\n",i,grid_v[i]);

	//for (i=0; i<r*r; i++) fprintf(log_file,"%f,",delpsi[i]);
	//for (i=0; i<ns1; i++) fprintf(log_file,"ve[%d]=%f,",i,ve[i]);
	//fprintf(log_file,"\n");

	free(delpsi);
	free(psi);
	free(del);
}

// Update Latent Normal Variable b for Random effect 
void LatentB()
{
	double **inv, **inv1, **chol_vec, **chol, **sigma_b;
	double *v, *vtv, *gval, *vgval, *vt, *mean_b, sum_vb;
	int i, j, k, rt, r, s, *t, prev_t, sum_r, idx;
	r = num_grid; s = num_subject; t = num_timepts;
	
	// compute vtv
	v = grid_v;
	vtv = (double*) malloc(s*r*r*sizeof(double));

	prev_t = 0;
	for (i=0; i<s; i++){
		matrix_xtx(v+r*prev_t, vtv+i*r*r, t[i], r);
		prev_t += t[i];
	}

	//for (i=0; i<s*r*r; i++) fprintf(log_file,"vtv[%d]=%f\n",i,vtv[i]);

	// compute sigma_b
	inv = (double**) malloc(s*r*sizeof(double*));
	inv1 = (double**) malloc(s*r*sizeof(double*));
	chol_vec = (double**) malloc(s*r*sizeof(double*));
	chol = (double**) malloc(s*r*sizeof(double*));
	sigma_b = (double**) malloc(s*r*sizeof(double*));
	
	for (i=0; i<s*r; i++) {
		inv[i] = (double*) malloc(r*sizeof(double));
		inv1[i] = (double*) malloc(r*sizeof(double));
		chol_vec[i] = (double*) malloc(r*sizeof(double));
		chol[i] = (double*) malloc(s*r*sizeof(double));
		sigma_b[i] = (double*) malloc(s*r*sizeof(double));
	}

	for (i=0; i<s*r; i++){
		for (j=0; j<r; j++){
			inv[i][j] = vtv[i*r+j]/ve[0];
			if (j == (i%r)) inv[i][j] += 1;
		}
	}

	//fprintf(log_file,"ve[0]=%f\n",ve[0]);
	
	//for (i=0; i<s*r; i++) 
	//	for (j=0; j<r; j++) fprintf(log_file,"inv[%d][%d]=%f\n",i,j,inv[i][j]);


	for (i=0; i<s; i++) INVERSE(inv+i*r,r,inv1+i*r);

	//for (i=0; i<s*r; i++) 
	//	for (j=0; j<r; j++) fprintf(log_file,"inv1[%d][%d]=%f\n",i,j,inv1[i][j]);

	for (i=0; i<s; i++) Cholesky(inv1+i*r,r,chol_vec+i*r);

	//for (i=0; i<s*r; i++) 
	//	for (j=0; j<r; j++) fprintf(log_file,"chol_vec[%d][%d]=%f\n",i,j,chol_vec[i][j]);

	for (i=0; i<s*r; i++) 
		for (j=0; j<s*r; j++) chol[i][j]=0;

	rt = r; sum_r = 0;
	for (i=0; i<s*r; i++){
		if (rt == 0) {rt = r; sum_r += r;}
		for (j = 0; j < r; j++) {
			chol[i][sum_r+j] = chol_vec[i][j];
		}
		rt--;
	}

	//for (i=0; i<4; i++) 
	//	for (j=0; j<s*r; j++) fprintf(log_file,"chol[%d][%d]=%f\n",i,j,chol[i][j]);

	for (i=0; i<s*r; i++) 
		for (j=0; j<s*r; j++) sigma_b[i][j]=0;

	rt = r; sum_r = 0;
	for (i=0; i<s*r; i++){
		if (rt == 0) {rt = r; sum_r += r;}
		for (j = 0; j < r; j++) {
			sigma_b[i][sum_r+j] = inv1[i][j];
		}
		rt--;
	}

	//for (i=0; i<4; i++) 
	//	for (j=0; j<s*r; j++) fprintf(log_file,"sigma_b[%d][%d]=%f\n",i,j,sigma_b[i][j]);

  // Compute mean_b
	mean_b = (double*) malloc(s*r*sizeof(double));
	gval =  (double*) malloc(ns1*sizeof(double));
	vgval =  (double*) malloc(s*r*sizeof(double));
	vt = (double*) malloc(max_num_timept*r*sizeof(double));

	for(i=0; i<ns1; i++) gval[i] = (y[i]-amu-gvalue[i])/ve[i];

	//for (i=0; i<ns1; i++) fprintf(log_file,"gval[%d]=%f\n",i,gval[i]);	
	
	prev_t = 0;
	for (i=0; i<s; i++){
		matrix_transpose(v+r*prev_t, vt, t[i], r);
		matrix_product(vt, gval+prev_t, vgval+r*i, r, 1, t[i]);
		prev_t += t[i];
	}

	//for (i=0; i<s*r; i++) fprintf(log_file,"vgval[%d]=%f\n",i,vgval[i]);

	XprimeVec(sigma_b, vgval, s*r, s*r, mean_b);

	//for (i=0; i<s*r; i++) fprintf(log_file,"mean_b[%d]=%f\n",i,mean_b[i]);	

	// Sample latent variable b
	Multivariate_RNORM(chol, mean_b, s*r, latent_b);
	

/*	///////////////
	for (i=0; i<s*r; i++) {
		if (i%r==0&&i!=0) fprintf(log_file,"\n");
		fprintf(log_file,"%f,",latent_b[i]);
	}
	fprintf(log_file,"\n");
	fprintf(log_file,"\n");

	for (i=0; i<ns1*r; i++) {
		if (i%r==0&&i!=0) fprintf(log_file,"\n");
		fprintf(log_file,"%f,",grid_v[i]);
	}

	fprintf(log_file,"\n");
	fprintf(log_file,"\n");

	for (j=0; j<5000; j++){
		Multivariate_RNORM(chol, mean_b, s*r, latent_b);
		for (i=0; i<s*r; i++) {
			fprintf(log_file,"%f,",latent_b[i]);
		}
		fprintf(log_file,"\n");
	}
	////////////////*/
	
	// Set vbvalue
	idx = 0; 
	for (i=0; i<s; i++)
		for (j=0; j<t[i]; j++){
			sum_vb = 0;
			for (k=0; k<r; k++) sum_vb += grid_v[idx*r+k] * latent_b[i*r+k];
			vbvalue[idx] = sum_vb;
			idx++;
		}
	
	//for (i=0; i<ns1; i++) fprintf(log_file,"%f,\n",vbvalue[i]);

	// deallocate memory
	free(vt);
	free(vgval);
	free(gval);
	free(mean_b);

	for (i=0; i<s*r; i++) {
		free(inv[i]);
		free(inv1[i]);
		free(chol_vec[i]);
		free(chol[i]); 
		free(sigma_b[i]);
	}

	free(inv); 
	free(inv1);
	free(chol);
	free(chol_vec);
	free(sigma_b);

	free(vtv);	
}


