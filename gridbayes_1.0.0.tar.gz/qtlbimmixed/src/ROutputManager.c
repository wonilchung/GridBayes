/******************************************************************************
* File: ROutputManager.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "GlobalVars.h"
#include "GlobalVars_SingleTrait.h"
#include "RInterfaces.h"

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/Utils.h>

#include <stdio.h>

//***************************************************************************
void ROutputManager(char **iterFile, char **covFile, char **mainFile, char **pairFile, char **gbyeFile, char **devFile, char **sigmaFile,
										char **mixedFile, char **testFile)
{
   strcpy(covfile,covFile[0]);
   strcpy(mainfile,mainFile[0]);
   strcpy(pairfile,pairFile[0]);
   strcpy(gbyefile,gbyeFile[0]);
   strcpy(iterfile,iterFile[0]);
   strcpy(devfile,devFile[0]);
   strcpy(sigmafile,sigmaFile[0]);
	 strcpy(mixedfile,mixedFile[0]);
	 strcpy(testfile,testFile[0]);
}
