/******************************************************************************
* File: SingleTraitMCMC.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "GlobalVars.h"
#include "GlobalVars_SingleTrait.h"
#include "StatUtils.h"
#include "SingleTraitMCMCSamplingRoutines.h"
#include "SingleTraitMCMC.h"
#include "MatrixUtils.h"

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/Utils.h>

#include <math.h>
#include <time.h>

#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

void singleTraitMCMC()
{

	int i,j,l,k,k1,k2,l0,l1,l2;

	if(seed1==0)	srand(time(NULL));
	else srand(seed1);
	//double r=rand( );
	rand( );

	//*************************************************************************
	// calculating phenotypic mean and variance, and assign initial values
	
	double y_bar=0,y2_bar=0,vp=1;
	if(category==1) // 1: normal data; 
	{
  	y_bar=0.0,y2_bar=0.0;
		for(i=0;i<ns;i++)
		{
  		y_bar=y_bar+y[i];
  		y2_bar=y2_bar+y[i]*y[i];
		}
		y_bar=y_bar/ns;  // mean
  	vp=(1.0/(ns-1))*(y2_bar-ns*pow(y_bar,2)); //  variance
	
		amu=y_bar;		   // overall mean
		for(i=0;i<ns;i++) ve[i]=vp;          //initial values for amu and ve
		for(i=0;i<nrancova;i++) vran[i]=vp;  //initial values for vran[i]
	}
	
	if(category!=1) // 2: binary data; 3:ordinal data
	{
		amu=0; 
  	for(i=0;i<ns;i++) ve[i]=1.0;             //initial values for amu and ve
  	for(i=0;i<nrancova;i++) vran[i]=1.0;     //initial values for vran[i]
	}
	
	//******************************************************************************
	//For specify the prior variances of QTL effects and g by e interactions
	
	double cc[ng];
  if(cross==2)
	{
  	cc[0]=1.0/2, cc[1]=1.0/4;   // f2
	}
	else cc[0]=1.0/4;             // BC
  
	double v_fix[20];             // 20 = the maximum number of fixed effects
	for(l=0;l<nfixcova;l++)
		if(gbye_fix_index[l]==1)
		{
			double y_bar1=0.0,y_bar2=0.0;
			for(i=0;i<ns;i++) 
			{
				y_bar1=y_bar1+coef_fix[i][l];
  			y_bar2=y_bar2+pow(coef_fix[i][l],2);
			}
			y_bar1=y_bar1/ns;
  		v_fix[l]=(1.0/(ns-1))*(y_bar2-ns*pow(y_bar1,2));
  	}
	
	//******************************************************************************
  //Give initial threshold values for ordinal traits
	
	if(category==2)
	{
		cutpoint[0]=-1e+10,cutpoint[1]=0,cutpoint[2]=1e+10;
	}
	
	if(category==3)
	{
		cutpoint[0]=-1e+10, cutpoint[1]=0;
  	for(j=2;j<cn-1;j++) cutpoint[j]=(j-1)*1.0/(cn-2);
  	cutpoint[cn-1]=1, cutpoint[cn]=1e+10;
	}
	
	//******************************************************************************
	// for censored data
	
	int censor=0;
  if(category==1)
		for(i=0;i<ns;i++)
  	{
			w[i]=0;
			if(censor_lo1[i]!=-10000000||censor_hi1[i]!=10000000)
  		{
				w[i]=1;
				censor=1;
			}
		}
	
	//**********************************************************************************
	// for kinship matrix
	
	if (kin_factor == 1) {
		
		kin_m = (double **)S_alloc(ns1, sizeof(double *));
		for(i=0; i<ns1; i++) kin_m[i] = (double *)S_alloc(ns1, sizeof(double));

		mtm = (double **)S_alloc(ns1, sizeof(double *));
		for(i=0; i<ns1; i++) mtm[i] = (double *)S_alloc(ns1, sizeof(double));

		Cholesky(kinmat, ns1, kin_m);

		XprimeX(kin_m, ns1, ns1, mtm);
		
		/*for (i=0; i<ns1; i++) {
			for (j=0; j<ns1; j++) fprintf(log_file,"%f,",mtm[i][j]);
			fprintf(log_file,"\n");
		}*/

		/* set number of time points for each subject */
		num_timepts = (int*) S_alloc(num_subject, sizeof(int));
		for (i=0; i<num_subject; i++) num_timepts[i] = 0;
		for (i=0; i<ns1; i++) num_timepts[(int)coef_subid[i]-1]++;

		max_num_timept = INT_MIN;
		for (i=0; i<num_subject; i++) max_num_timept = MAX(max_num_timept, num_timepts[i]);

		/*RandomOmega();
		LatentC();*/
	}

	//**********************************************************************************
	// for longitudinal data
	
	if (longi_factor == 1) {

		//Rprintf("ns1*num_grid=%d\n",ns1*num_grid);
		//Rprintf("num_subject=%d\n",num_subject);

		grid_p = (double*)S_alloc(ns1*num_grid, sizeof(double));
		for (i=0; i<ns1*num_grid ;i++) grid_p[i] = 0;

		grid_v = (double*)S_alloc(ns1*num_grid, sizeof(double));
		for (i=0; i<ns1*num_grid ;i++) grid_v[i] = 0;

		/* set number of time points for each subject */
		num_timepts = (int*) S_alloc(num_subject, sizeof(int));
		for (i=0; i<num_subject; i++) num_timepts[i] = 0;
		for (i=0; i<ns1; i++) num_timepts[(int)coef_subid[i]-1]++;

		IncidenceMatrix();
	
		/*RandomDelta();
		RandomPsi();
		RandomV();
		LatentB();*/
		
		//for (i=0; i<num_subject; i++) fprintf(log_file,"num_timepts[%d]=%d\n",i,num_timepts[i]);
		//for (i=0; i<ns1*num_grid; i++) fprintf(log_file,"grid_p[%d]=%f,\n",i,grid_p[i]);

	}
	
	//**********************************************************************************
	// initialize deviance measures
  
	double amubar,gvaluebar[ns],vebar,cutpointbar[cn+1];
	
  amubar=0.0;
  for (i=0; i<ns; i++) gvaluebar[i]=0.0;
	vebar=0.0;
	if (category!=1) for (l=0; l<=cn; l++) cutpointbar[l]=0.0;
	
	// for longitudinal data
	double ran_deltabar[num_grid],ran_psibar[(int)0.5*num_grid*(num_grid-1)];
	for (i=0; i<num_grid; i++) ran_deltabar[i] = 0.0;
	for (i=0; i<0.5*num_grid*(num_grid-1); i++) ran_psibar[i] = 0.0;

  //**********************************************************************************
	
	FILE *file1;
	file1=fopen(iterfile,"w");
	
	FILE *file2;
	file2=fopen(covfile,"w");
	
	FILE *file3;
	file3=fopen(mainfile,"w");
  
  FILE *file4;
	file4=fopen(pairfile,"w");
	
	FILE *file5;
	file5=fopen(gbyefile,"w");
	
	FILE *file6;
  file6=fopen(devfile,"w");

	FILE *file7;
	file7=fopen(mixedfile,"w"); /*save values for longitudinal analysis*/

	FILE *file8;
	file8=fopen(testfile,"w"); /*save values for longitudinal analysis*/
	
  // **********************************************************
	// ITERATION STARTS HERE
	// **********************************************************
	
	//***********************************************************
  int iter,iter1;
	for(iter=0;iter<niter+(int)(1.0*nburnin/nthin);iter++) // iter starts
	{ 
	//***********************************************************
	
	//***********************************************************
	for(iter1=0;iter1<nthin;iter1++)                       // iter1 starts
	{
	//***********************************************************
	
	//***********************************************************
	// UPDATING THE VALUES OF THE LIABILITY
	if(category!=1)
  	for(i=0;i<ns;i++) y[i]=TrunNormal(cutpoint[w[i]],cutpoint[w[i]+1],amu+gvalue[i],ve[i]);
	
	// UPDATING THE CENSORED VALUES
  if(censor==1 && category==1)
		for(i=0;i<ns;i++)
			if(w[i]==1)
  		{
				y[i]=TrunNormal(censor_lo1[i],censor_hi1[i],amu+gvalue[i],ve[i]);
			}
	
	// CALCULATE VARIANCE OF LIABILITY OR CENSORED DATA
	if(category!=1 || censor==1)
	{
		y_bar=0.0,y2_bar=0.0;
		for(i=0;i<ns;i++)
  	{
  		y_bar=y_bar+y[i];
			y2_bar=y2_bar+y[i]*y[i];
		}
		y_bar=y_bar/ns;
		vp=(1.0/(ns-1))*(y2_bar-ns*pow(y_bar,2));
	}
	
  //*********************************************************************************
	// (1) UPDATE PARAMETERS
  
	Mean(y_bar,vp);
	
  if(category!=2)    // 1: normal data; 2: binary data; 3:ordinal data
		ResidualVariance1(6,0.5);
		//ResidualVariance(vp);
		//ResidualVariance1(6,0.5);
		
	
	if(env_factor==1)  // 1:include environmental factors
	{
		for(l=0;l<nrancova;l++)
		{
			RandomCovariate(l);
			RanVariance(l);
  	}
		for(l=0;l<nfixcova;l++) 
			FixedCovariate(l);
	}
	
	// for kinship matrix ///
	if (kin_factor == 1){
		RandomOmega();
		LatentC();
	}
	/////////////////////////
  
	// for longitudinal data ///
	if (longi_factor == 1) {
		RandomDelta();
		RandomPsi();
		RandomV();
		LatentB();
	}
	//////////////////////////

	int nu=6; double h=0.1, s=2, tau; // nu=degrees of freedom, h=heritability, tau=scale
	
  if(group==0) // Cockerham model
	{
		for(l=0;l<nqtl;l++)
			if(gamma_main[l]!=0.0)
				for(k=0;k<nc;k++)
					if(main1[l][k]!=0)
					{
						MainEffect(l,k);
						tau=(nu-2)*h*vp/(nu*cc[k]);	
						MainVariance(l,k,nu,tau);
  				}
  
		if(epistasis==1) // 1: epistatic model
		{
			for(l1=0;l1<nqtl-1;l1++)
				for(l2=l1+1;l2<nqtl;l2++)
					if(gamma_epistasis[l1][l2]!=0.0) 
						for(k1=0;k1<nc;k1++)
  						for(k2=0;k2<nc;k2++) 
								if(epistatic[l1][l2][k1][k2]!=0)
  							{
									EpistaticEffect(l1,l2,k1,k2);
									tau=(nu-2)*h*vp/(nu*cc[k1]*cc[k2]);
  								EpistaticVariance(l1,l2,k1,k2,nu,tau);
								}
		}
	
		if(gbye==1)  // 1: include g by e interactions
		{
			for(l1=0;l1<nfixcova;l1++)
				if(gbye_fix_index[l1]==1)
					for(l2=0;l2<nqtl;l2++)
  					if(gamma1[l2]!=0.0&&gamma_gbye[l1][l2]!=0.0)
							for(k=0;k<nc;k++) 
								if(gbye_fix[l1][l2][k]!=0)
  							{
  								GBYE_FixedCovariate(l1,l2,k);
									tau=(nu-2)*h*vp/(nu*v_fix[l1]*cc[k]);
							    GBYE_FixedCovariate_Variance(l1,l2,k,nu,tau);
  							}
		}
	}
	
	
	if(group==1) // groupedly update all main effects or epistatic effects
	{
		for(l=0;l<nqtl;l++)
			if(gamma_main[l]!=0.0) 
			{
  			for(k=0;k<nc;k++) MainEffect(l,k);
  			tau=s*vp;
				MainVariance1(l,nu,tau);
			}
	
		if(epistasis==1)  // 1: epistatic model
		{
			for(l1=0;l1<nqtl-1;l1++)
  			for(l2=l1+1;l2<nqtl;l2++)
					if(gamma_epistasis[l1][l2]!=0.0) 
  				{
						for(k1=0;k1<nc;k1++)
							for(k2=0;k2<nc;k2++) 
  							EpistaticEffect(l1,l2,k1,k2);
						tau=s*vp;
						EpistaticVariance1(l1,l2,nu,tau);
					}
		}
	
		if(gbye==1)  // 1: include g by e interactions
		{
			for(l1=0;l1<nfixcova;l1++)
  			if(gbye_fix_index[l1]==1)
					for(l2=0;l2<nqtl;l2++)
						if(gamma1[l2]!=0.0&&gamma_gbye[l1][l2]!=0.0) 
  					{
  						for(k=0;k<nc;k++) 
								GBYE_FixedCovariate(l1,l2,k);
							tau=s*vp;
  						GBYE_FixedCovariate_Variance1(l1,l2,nu,tau);
						}
		}
	}
	
	
	//************************************************************************************
	// (2) UPDATE THE QTL INHERITANCE OF NON-FOUNDERS AND THE GENOTYPIC VALUES
	
	if(updategeno==1) // 1: update QTL genotypes
  {
  	for(l=0;l<nqtl;l++)
		if(gamma1[l]!=0)
		{
			pd1[l]=0.0,pd2[l]=0.0;
			for(i=0;i<ns;i++)
			{
				int k,kk=0;
  			for(k=0;k<ng;k++)
				   if(qprob[qchr[l]][i][qloc[l]][k]>0.99)
  			   {
					   ibd=k;
					   kk=1;
  			   }
				if(kk==0)
				{
					QTLgenotype(l,qchr[l],qloc[l],i);
					pd1[l]=pd1[l]+log(pdd1+1e-20);
					pd2[l]=pd2[l]+log(pdd2+1e-20);
				}
	
				if(ibd!=geno[i][l])
  			{
					gvalue[i]=GenotypeSampling(i,l,ibd,0);
					geno[i][l]=ibd;
  				Coefficient(ibd);
  				for(k=0;k<nc;k++) coef[i][l][k]=x[k];
				}
			}
  	}
	}
	
	//**********************************************************************************
	// (3) UPDATING QTL POSITIONS
	
	for(l=0;l<nqtl;l++)
		if(gamma1[l]!=0)
		{
			int cat[4],qlnew,test=0;
  
  		double r=RANDOM();
			cat[0]=(r>=0&&r<0.25),cat[1]=(r>=0.25&&r<0.5),cat[2]=(r>=0.5&&r<0.75),cat[3]=(r>=0.75&&r<=1.0);
			qlnew=cat[0]*(qloc[l]-2)+cat[1]*(qloc[l]-1)+cat[2]*(qloc[l]+1)+cat[3]*(qloc[l]+2);
			if(qlnew<0) qlnew=0;
			if(qlnew>=ngrid[qchr[l]]-1) qlnew=ngrid[qchr[l]]-1;
	
			if(qlnew!=qloc[l])
  		{
				for(l0=0;l0<nqtl;l0++)
  				if( qchr[l0]==qchr[l]&&l0!=l )
						test=test+(fabs(grid[qchr[l]][qlnew]-grid[qchr[l0]][qloc[l0]])<=dqq[qchr[l]]);
	
  			if(test==0) QTLPOSITION(l,qlnew);
			}
		}
	
	//**********************************************************
	// (4) UPDATE MAIN EFFECT INDICATORS
	
	for(l=0;l<nqtl;l++)
	{
  	int t;
	
		if(group==0) // Cockerham model
  	{
  		for(k=0;k<nc;k++)
			{
				t=1;
  			double r=RANDOM();
				if( (main1[l][k]==0&&r<=w_main)||(main1[l][k]!=0&&r>w_main) )
				{
					if(gamma1[l]==0) t=SamplingOnePosition(l);
					if(t!=0) 
					{
						if(main1[l][k]==0&&r<=w_main)
						{
							double t0=0,u,u0;
							for(j=0;j<nu;j++)
  						{
  							ANORMAL(&u,&u0);
								t0=t0+u*u;
							}
							tau=(nu-2)*h*vp/(nu*cc[k]);
							vmain[l][k]=nu*tau/t0;
						}
						MainEffectIndicator_GROUP0(l,k);
  				}
				}
  		}
		}
	
  	if(group==1) // groupedly update all main effects or epistatic effects
		{
			t=1;
			double r=RANDOM();
			if( (gamma_main[l]==0&&r<=w_main)||(gamma_main[l]!=0&&r>w_main) )
			{
				if(gamma1[l]==0) t=SamplingOnePosition(l);
				if(t!=0) 
				{
  				if(gamma_main[l]==0&&r<=w_main)
					{
						double t0=0,u,u0;
  					for(j=0;j<nu;j++)
  					{
							ANORMAL(&u,&u0);
							t0=t0+u*u;
  					}
						tau=s*vp;
						vmain1[l]=nu*tau/t0;
					}
					MainEffectIndicator_GROUP1(l);
				}
			}
		}
	
	}
  
  //**********************************************************
	// (5) UPDATE TWO ORDER epistatic EFFECT INDICATORS
	
	if(epistasis==1)  // 1: epistatic model
	{
		int t;
	
  	for(l1=0;l1<nqtl-1;l1++)
			for(l2=l1+1;l2<nqtl;l2++)
  		{
				if(group==0)
				{
  				for(k1=0;k1<nc;k1++)
						for(k2=0;k2<nc;k2++)
						{
							if(dependence==1)
							{
								if(main1[l1][k1]!=0&&main1[l2][k2]!=0) w_epistasis=c[0];
								if( (main1[l1][k1]!=0&&main1[l2][k2]==0)||(main1[l1][k1]==0&&main1[l2][k2]!=0) ) w_epistasis=c[1];
								if(main1[l1][k1]==0&&main1[l2][k2]==0) w_epistasis=c[2];
							}
  
							t=1;
							double r=RANDOM();
  						if( (epistatic[l1][l2][k1][k2]==0&&r<=w_epistasis)||(epistatic[l1][l2][k1][k2]!=0&&r>w_epistasis) )
  						{
								if(w_epistasis!=0)
								{
  								if(gamma1[l1]==0&&gamma1[l2]!=0) t=SamplingOnePosition(l1);
									if(gamma1[l1]!=0&&gamma1[l2]==0) t=SamplingOnePosition(l2);
									if(gamma1[l1]==0&&gamma1[l2]==0)
									{
										t=SamplingOnePosition(l1);
										if(t!=0) t=SamplingOnePosition(l2);
										if(chrqtl[qchr[l1]]+2>chr_nqtl[qchr[l1]]&&qchr[l1]==qchr[l2]
											&&(grid[qchr[l1]][qloc[l1]]-grid[qchr[l2]][qloc[l2]])<=dqq[qchr[l1]]) t=0;
									}
								}
  							if(t!=0) 
  							{
									if(epistatic[l1][l2][k1][k2]==0&&r<=w_epistasis)
									{
										double t0=0,u,u0;
										for(j=0;j<nu;j++)
										{
											ANORMAL(&u,&u0);
  										t0=t0+u*u;
										}
  									tau=(nu-2)*h*vp/(nu*cc[k1]*cc[k2]);
										vepistasis[l1][l2][k1][k2]=nu*tau/t0;
									}
  								EpistasisIndicator_GROUP0(l1,l2,k1,k2);
								}
							}
						}
				}
	
				if(group==1)
				{
					if(dependence==1)
  				{
						if(gamma_main[l1]!=0&&gamma_main[l2]!=0) w_epistasis=c[0];
						if( (gamma_main[l1]!=0&&gamma_main[l2]==0)||(gamma_main[l1]==0&&gamma_main[l2]!=0) ) w_epistasis=c[1];
  					if(gamma_main[l1]==0&&gamma_main[l2]==0) w_epistasis=c[2];
  				}
	
					t=1;
  				double r=RANDOM();
					if( (gamma_epistasis[l1][l2]==0&&r<=w_epistasis)||(gamma_epistasis[l1][l2]!=0&&r>w_epistasis) )
					{
						if(w_epistasis!=0)
						{
							if(gamma1[l1]==0&&gamma1[l2]!=0) t=SamplingOnePosition(l1);
							if(gamma1[l1]!=0&&gamma1[l2]==0) t=SamplingOnePosition(l2);
							if(gamma1[l1]==0&&gamma1[l2]==0)
							{
								t=SamplingOnePosition(l1);
  							if(t!=0) t=SamplingOnePosition(l2);
  							if(chrqtl[qchr[l1]]+2>chr_nqtl[qchr[l1]]&&qchr[l1]==qchr[l2]
									&&(grid[qchr[l1]][qloc[l1]]-grid[qchr[l2]][qloc[l2]])<=dqq[qchr[l1]]) t=0;
							}
						}
						if(t!=0) 
						{
							if(gamma_epistasis[l1][l2]==0&&r<=w_epistasis)
  						{
								double t0=0,u,u0;
  							for(j=0;j<nu;j++)
								{
									ANORMAL(&u,&u0);
  								t0=t0+u*u;
								}
								tau=s*vp;
								vepistasis1[l1][l2]=nu*tau/t0;
							}
							EpistasisIndicator_GROUP1(l1,l2);
						}
					}
				}
  		}
	}
	
  //************************************************************
  // (6) update g by e fixed effects INDICATORS
	
	if(gbye==1) // 1: include g by e interactions
  {
		int t;
		for(l1=0;l1<nfixcova;l1++)
		if(gbye_fix_index[l1]==1)
			for(l2=0;l2<nqtl;l2++)
		//	if(gamma1[l2]!=0)
			{
				if(group==0)
				{
					for(k=0;k<nc;k++)
  				{
  					t=1;
						double r=RANDOM();
						if( (gbye_fix[l1][l2][k]==0&&r<=w_gbye)||(gbye_fix[l1][l2][k]!=0&&r>w_gbye) )
						{
							if(gamma1[l2]==0) t=SamplingOnePosition(l2);
							if(t!=0)
							{
  							if(gbye_fix[l1][l2][k]==0&&r<=w_gbye)
								{
  								double t0=0,u,u0;
									for(j=0;j<nu;j++)
									{
  									ANORMAL(&u,&u0);
										t0=t0+u*u;
									}
									tau=(nu-2)*h*vp/(nu*v_fix[l1]*cc[k]);
									v_gbye_fix[l1][l2][k]=nu*tau/t0;
								}
		
								GBYE_FIX_Indicator_GROUP0(l1,l2,k);
							}
  					}
					}
				}
  
  			if(group==1)
				{
					t=1;
  				double r=RANDOM();
					if( (gamma_gbye[l1][l2]==0&&r<=w_gbye)||(gamma_gbye[l1][l2]!=0&&r>w_gbye) )
					{
						if(gamma1[l2]==0) t=SamplingOnePosition(l2);
						if(t!=0)
						{
							if(gamma_gbye[l1][l2]==0&&r<=w_gbye)
							{
								double t0=0,u,u0;
								for(j=0;j<nu;j++)
  							{
  								ANORMAL(&u,&u0);
									t0=t0+u*u;
								}
								tau=s*vp;
								v_gbye_fix1[l1][l2]=nu*tau/t0;
							}
						
  						GBYE_FIX_Indicator_GROUP1(l1,l2);
						}
  				}
				}
	
  		}
	}
	
	//**********************************************************
	// update the threshold values
	
	if(category==3) // 3: ordinal
	{
		int j; double cutpoint0[cn+1],al0,al;
  
		for(j=0;j<=cn;j++) cutpoint0[j]=cutpoint[j];
	
  	al0=Likelihood(cutpoint,gvalue);
  
		for(j=2;j<=cn-2;j++)
		{
  		cutpoint0[j]=cutpoint[j]+0.01*(RANDOM()-0.5);
			if(cutpoint0[j]<=cutpoint0[j-1]) cutpoint0[j]=cutpoint0[j-1]+0.01*RANDOM();
			if(cutpoint0[j]>cutpoint[j+1]) cutpoint0[j]=cutpoint[j+1]-0.01*RANDOM();
		}
	
		al=Likelihood(cutpoint0,gvalue);
	
		if((al-al0)>log(RANDOM()))
			for(j=2;j<=cn-2;j++) cutpoint[j]=cutpoint0[j];
	}
  
  //***************************************************************
	}    //iter1 end here
	//***************************************************************
	
	
  //***************************************************************
	//SAVE THE RESULT
  
	//***************************************************************
	if(iter*iter1>=nburnin)
	{
  //***************************************************************
  
	if((iter!=0)&&(iter%200==0)&(verbose1>0))
	{
		Rprintf("%d",iter);
		Rprintf("\n");
	}
	
	if((iter!=0)&&((iter%200)==0))
	   R_CheckUserInterrupt();
  
	//CALCULATE THE NUMBER OF QTL
	int qtl_included=0;
  for(l=0;l<nqtl;l++) qtl_included=qtl_included+(gamma1[l]!=0);
  
	double ve0=0;
	for(i=0;i<ns;i++) ve0=ve0+ve[i];
  ve0=ve0/ns;
	
	//CALCULATE DEVIANCE
	amubar+=amu;
	vebar+=ve0;
	for (i=0; i<ns; i++) gvaluebar[i]+=gvalue[i];
	if (category!=1) for (l=0; l<=cn; l++) cutpointbar[l]+=cutpoint[l];
	
	double dev=0.0;

	if (longi_factor != 1){ // for independent samples

		// if (category==1) for(i=0;i<ns;i++) dev=dev+log(2*3.14159265358*ve[i])+pow(y[i]-amu-gvalue[i],2)/ve[i];
		if (category==1) for(i=0;i<ns;i++) dev=dev+log(2*3.14159265358*ve[i])+pow(y[i]-amu-gvalue[i]-vbvalue[i]-qcvalue[i],2)/ve[i];
		else dev=-2*Likelihood(cutpoint,gvalue);

	} else { // for longitudinal data
		
		double *pd, *p, *pt, *pdpt, *del, *psi, *delpsi, *psitdel, *d, **tmp, **tmp_inv, *a, atsiga, det, like;
		int r, s, *t, sum_t, prev_t, i1, j1, sum_t_sq=0, idx;

		p = grid_p;
		r = num_grid; s = num_subject; t = num_timepts;

		for (i1=0; i1<r; i1++) ran_deltabar[i1] += ran_delta[i1];
		for (i1=0; i1<0.5*r*(r-1); i1++) ran_psibar[i1] += ran_psi[i1];

		for (i1=0; i1<s; i1++) sum_t_sq += t[i1]*t[i1];
		
		a = (double *)malloc(max_num_timept*sizeof(double));
		pd = (double *)malloc(ns1*r*sizeof(double));
		del = (double*) malloc(r*r*sizeof(double));
		psi = (double*) malloc(r*r*sizeof(double));
		delpsi = (double*) malloc(r*r*sizeof(double));
		psitdel = (double*) malloc(r*r*sizeof(double));
		d = (double*) malloc(r*r*sizeof(double));
		pt = (double *)malloc(max_num_timept*r*sizeof(double));
		pdpt = (double *)malloc(sum_t_sq*sizeof(double));
		tmp = (double**) malloc(max_num_timept*sizeof(double*));
		tmp_inv = (double**) malloc(max_num_timept*sizeof(double*));
		for (i1=0; i1<max_num_timept; i1++) {
			tmp[i1] = (double*) malloc(max_num_timept*sizeof(double));
			tmp_inv[i1] = (double*) malloc(max_num_timept*sizeof(double));
		}

		for (i1=0; i1<r*r; i1++) {del[i1] = 0; psi[i1] = 0;}

		for (i1=0; i1<r; i1++){ del[i1*(r+1)] = ran_delta[i1]; psi[i1*(r+1)] = 1;}

		idx=0;
		for (i1=0; i1<r; i1++) 
			for (j1=(i1+1); j1<r; j1++) { psi[j1*r+i1] = ran_psi[idx]; idx++; }

		matrix_product(del,psi,delpsi,r,r,r);
		matrix_transpose(delpsi,psitdel,r,r);
		matrix_product(delpsi,psitdel,d,r,r,r);
		matrix_product(p,d,pd,ns1,r,r);
		
		/*for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",del[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",psi[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",delpsi[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",psitdel[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",d[k1]);*/

		sum_t = 0; prev_t = 0;
		for (i1=0; i1<s; i1++){
			matrix_transpose(p+r*prev_t,pt,t[i1],r);
			matrix_product(pd+r*prev_t,pt,pdpt+sum_t,t[i1],t[i1],r);

			/*if (i1 == 0 || i1 == s-1)
				for (k1 = 0; k1 < t[i1]*t[i1]; k1++) fprintf(file8,"%lf\t",pdpt[sum_t+k1]);*/
			
			sum_t += t[i1]*t[i1];
			prev_t += t[i1];
		}
		//fprintf(file8,"\n");
		
		like = 0;
		prev_t = 0; idx = 0;
		for (k1=0; k1<s; k1++) {

			for (i1=0; i1<t[k1]; i1++)
				for (j1=0; j1<t[k1]; j1++) {
					tmp[i1][j1] = pdpt[idx];
					if (i1 == j1) tmp[i1][j1] += ve[prev_t+i1];
					idx++;
				}
		
			if (t[k1]==1) tmp_inv[0][0] = 1.0/tmp[0][0];
			else INVERSE(tmp, t[k1], tmp_inv);

			det = Determinant(tmp, t[k1]);
			
			for (i1=0; i1<t[k1]; i1++)
				a[i1] = y[prev_t+i1]-amu-gvalue[prev_t+i1];

			atsiga = 0;
			for (i1=0; i1<t[k1]; i1++)
				for (j1=0; j1<t[k1]; j1++) 
					atsiga += tmp_inv[i1][j1]*a[i1]*a[j1]; 

			like += -0.5*((double)t[k1])*log(2*3.14159265358) - 0.5*log(det) - 0.5*atsiga;
			
			prev_t += t[k1];

		}

		//dev = -1.0*like;
		dev = -2.0*like;
		
		free(a);
		free(pdpt); 
		free(pt); 
		free(pd); 
		free(psitdel);
		free(d);

		free(delpsi);
		free(psi);
		free(del);

		for (i1=0; i1<max_num_timept; i1++) {
			free(tmp[i1]); 
			free(tmp_inv[i1]);
		}
		
		free(tmp); 
		free(tmp_inv);

	}
  // save to "deviance"
	fprintf(file6,"%lf\n",dev);
	
	// posterior predictive assessment (1) ////////////// 
	/*double dev_y=0.0,dev_yrep=0.0,e_y=0.0,var_y=0.0,u,u0;
	double *yrep;
	yrep = (double*) malloc(ns*sizeof(double));
	
	for(i=0;i<ns;i++) {
		ANORMAL(&u,&u0);
		yrep[i] = u*sqrt(ve[i])+(amu+gvalue[i]+vbvalue[i]+qcvalue[i]);
	}

	for(i=0;i<ns;i++) {
		e_y = amu+gvalue[i]+vbvalue[i]+qcvalue[i];
		var_y = ve[i];
		dev_y = dev_y + pow(y[i]-e_y,2)/var_y;
		dev_yrep = dev_yrep + pow(yrep[i]-e_y,2)/var_y;
	}

	fprintf(file8,"%lf\t%lf\n",dev_y, dev_yrep);
	free(yrep);*/
	///////////////////////////////////////////////////

	// posterior predictive assessment (2) ////////////// 
	/* double e_y;

	for(i=0;i<ns;i++) {
		e_y = amu+gvalue[i];
		fprintf(file8,"%lf\t",e_y);
	}
	fprintf(file8,"\n");*/
	///////////////////////////////////////////////////
	
	// save to "iterdiag"
	fprintf(file1,"\n");
	fprintf(file1,"%d\t",iter+1);
	fprintf(file1,"%d\t",qtl_included);
  fprintf(file1,"%f\t",amu);
	fprintf(file1,"%f\t",ve0);
  
	// save to "covariates"
	if(env_factor==1)
  {
		fprintf(file2,"\n");
		for(l=0;l<nfixcova;l++) fprintf(file2,"%f\t",fix[l]);
		for(l=0;l<nrancova;l++) fprintf(file2,"%f\t",vran[l]);
	}
	if(category==3)
	  for(l=2;l<=cn-2;l++) fprintf(file2,"%f\t",cutpoint[l]);
	fprintf(file2,"\n");

	// save to "mixed"
	if (kin_factor == 1){
		fprintf(file7,"%f\t",amu);
		fprintf(file7,"%f\t",ve0);
		fprintf(file7,"%f\t",kin_omega[0]);
		fprintf(file7,"\n");
	}
	if (longi_factor == 1){
		fprintf(file7,"%f\t",amu);
		fprintf(file7,"%f\t",ve0);
		for (i=0; i<num_grid; i++) fprintf(file7,"%f\t",ran_delta[i]);
		for (i=0; i<num_grid*(num_grid-1)/2; i++) fprintf(file7,"%f\t",ran_psi[i]);
		fprintf(file7,"\n");
	}
	

	//***************************************************************
	if(group==0)
  {
  //***************************************************************

	// save to "mainloci"
	double var1[ng];
  for(k=0;k<nc;k++) var1[k]=0;
	for(l=0;l<nqtl;l++)
		if(gamma1[l]!=0)
		{
			fprintf(file3,"\n");
			fprintf(file3,"%d\t",iter+1);
	    fprintf(file3,"%d\t",qtl_included);
	    fprintf(file3,"%d\t",qchr[l]+1);
	//  fprintf(file3,"%f\t",grid[qchr[l]][qloc[l]]);
			fprintf(file3,"%d\t",qloc[l]);
  		for(k=0;k<nc;k++) fprintf(file3,"%f\t",main1[l][k]);
  		for(k=0;k<nc;k++)
			{
				double ss1=0,ss2=0,ss=0;
				if(main1[l][k]!=0)
				{
					for(i=0;i<ns;i++)
					{
  					ss1=ss1+pow(coef[i][l][k],2);
						ss2=ss2+coef[i][l][k];
  				}
					ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2))*pow(main1[l][k],2);
				}
  			fprintf(file3,"%f\t",ss);
				var1[k]=var1[k]+ss;
			}
		}

	for(k=0;k<nc;k++) fprintf(file1,"%f\t",var1[k]);
	
	// save to "pairloci"
	double var2[ng][ng];
	for(k1=0;k1<nc;k1++)
  	for(k2=0;k2<nc;k2++) var2[k1][k2]=0;
	if(epistasis==1)
	{
  	int n_epis=0;
  	for(l1=0;l1<nqtl;l1++)
			for(l2=l1+1;l2<nqtl;l2++)
				for(k1=0;k1<nc;k1++)
  				for(k2=0;k2<nc;k2++)
						if(epistatic[l1][l2][k1][k2]!=0) n_epis=n_epis+1;
	
		for(l1=0;l1<nqtl;l1++)
			for(l2=l1+1;l2<nqtl;l2++)
				if(gamma1[l1]!=0&&gamma1[l2]!=0&&gamma_epistasis[l1][l2]!=0)
				{
					fprintf(file4,"\n");
					fprintf(file4,"%d\t",iter+1);
					fprintf(file4,"%d\t",n_epis);
  				fprintf(file4,"%d\t",qchr[l1]+1);
  //		  fprintf(file4,"%f\t",grid[qchr[l1]][qloc[l1]]);
					fprintf(file4,"%d\t",qloc[l1]);
					fprintf(file4,"%d\t",qchr[l2]+1);
	//			fprintf(file4,"%f\t",grid[qchr[l2]][qloc[l2]]);
					fprintf(file4,"%d\t",qloc[l2]);
					for(k1=0;k1<nc;k1++)
						for(k2=0;k2<nc;k2++) fprintf(file4,"%f\t",epistatic[l1][l2][k1][k2]);
  
					for(k1=0;k1<nc;k1++)
  				for(k2=0;k2<nc;k2++)
					{
						double ss1=0,ss2=0,ss=0;
  					if(epistatic[l1][l2][k1][k2]!=0)
						{
							for(i=0;i<ns;i++)
							{
								ss1=ss1+pow(coef[i][l1][k1]*coef[i][l2][k2],2);
								ss2=ss2+coef[i][l1][k1]*coef[i][l2][k2];
							}
							ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2))*pow(epistatic[l1][l2][k1][k2],2);
						}
  					fprintf(file4,"%f\t",ss);
						var2[k1][k2]=var2[k1][k2]+ss;
					}
  			}
      for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++) fprintf(file1,"%f\t",var2[k1][k2]);
	}
  
	
	// save to "gbye"
	double var3[ng];
	for(k=0;k<nc;k++) var3[k]=0;
	if(gbye==1)
	{
		int n_gbye=0;
		for(l1=0;l1<nfixcova;l1++)
			for(l2=0;l2<nqtl;l2++)
  			for(k=0;k<nc;k++)
  				if(gbye_fix[l1][l2][k]!=0) n_gbye=n_gbye+1;
	
		for(l1=0;l1<nfixcova;l1++)
			 if(gbye_fix_index[l1]==1)
				for(l2=0;l2<nqtl;l2++)
					if(gamma1[l2]!=0.0)
						if(gamma_gbye[l1][l2]!=0.0)
  					{
							fprintf(file5,"\n");
  						fprintf(file5,"%d\t",iter+1);
							fprintf(file5,"%d\t",n_gbye);
							fprintf(file5,"%d\t",l1+1);
  						fprintf(file5,"%d\t",qchr[l2]+1);
						//fprintf(file5,"%f\t",grid[qchr[l2]][qloc[l2]]);
							fprintf(file5,"%d\t",qloc[l2]);
							for(k=0;k<nc;k++) fprintf(file5,"%f\t",gbye_fix[l1][l2][k]);
	
							for(k=0;k<nc;k++)
							{
								double ss1=0,ss2=0,ss=0;
								if(gbye_fix[l1][l2][k]!=0)
  							{
									for(i=0;i<ns;i++)
									{
  									ss1=ss1+pow(coef_fix[i][l1]*coef[i][l2][k],2);
  									ss2=ss2+coef_fix[i][l1]*coef[i][l2][k];
									}
									ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2))*pow(gbye_fix[l1][l2][k],2);
  							}
								fprintf(file5,"%f\t",ss);
								var3[k]=var3[k]+ss;
							}
						}
		for(k=0;k<nc;k++) fprintf(file1,"%f\t",var3[k]);
	}
	
	double var=0;
	for(k1=0;k1<nc;k1++)
  {
  	var=var+var1[k1]+var3[k1];
		for(k2=0;k2<nc;k2++) var=var+var2[k1][k2];
	}
	if(env_factor==1) fprintf(file1,"%f\t",vp-var-ve0);
	fprintf(file1,"%f\t",var);
	
	//***************************************************************
	}      //group=0 end
  //***************************************************************
	
	//***************************************************************
  if(group==1)
	{
	//***************************************************************
	
  // save to "mainloci"
	double var1=0;
	for(l=0;l<nqtl;l++)
	if(gamma1[l]!=0)
	{
		fprintf(file3,"\n");
		fprintf(file3,"%d\t",iter+1);
	  fprintf(file3,"%d\t",qtl_included);
	  fprintf(file3,"%d\t",qchr[l]+1);
  //fprintf(file3,"%f\t",grid[qchr[l]][qloc[l]]);
		fprintf(file3,"%d\t",qloc[l]);
		for(k=0;k<nc;k++) fprintf(file3,"%f\t",main1[l][k]);
  
  	double ss1=0,ss2=0,ss=0;
		for(i=0;i<ns;i++)
		{
  		double s=0;
			for(k=0;k<nc;k++) s=s+coef[i][l][k]*main1[l][k];
			ss1=ss1+pow(s,2);
			ss2=ss2+s;
		}
		ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2)); //main-effect variance
		fprintf(file3,"%f\t",ss);
		var1=var1+ss;
	}
	fprintf(file1,"%f\t",var1);
  
  
	// save to "pairloci"
	double var2=0;
	if(epistasis==1)
	{
		int n_epis=0;
		for(l1=0;l1<nqtl;l1++)
  		for(l2=l1+1;l2<nqtl;l2++)
				if(gamma_epistasis[l1][l2]!=0) n_epis=n_epis+1;
  
		for(l1=0;l1<nqtl;l1++)
			for(l2=l1+1;l2<nqtl;l2++)
  		if(gamma1[l1]!=0&&gamma1[l2]!=0&&gamma_epistasis[l1][l2]!=0)
			{
				fprintf(file4,"\n");
				fprintf(file4,"%d\t",iter+1);
				fprintf(file4,"%d\t",n_epis);
				fprintf(file4,"%d\t",qchr[l1]+1);
	//		fprintf(file4,"%f\t",grid[qchr[l1]][qloc[l1]]);
				fprintf(file4,"%d\t",qloc[l1]);
				fprintf(file4,"%d\t",qchr[l2]+1);
  //		fprintf(file4,"%f\t",grid[qchr[l2]][qloc[l2]]);
				fprintf(file4,"%d\t",qloc[l2]);
				for(k1=0;k1<nc;k1++)
  				for(k2=0;k2<nc;k2++) fprintf(file4,"%f\t",epistatic[l1][l2][k1][k2]);
  
				double ss1=0,ss2=0,ss=0;
				for(i=0;i<ns;i++)
  			{
					double s=0;
					for(k1=0;k1<nc;k1++)
						for(k2=0;k2<nc;k2++)
							s=s+coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
					ss1=ss1+pow(s,2);
					ss2=ss2+s;
				}
				ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2)); //epistatic variance
				fprintf(file4,"%f\t",ss);
  			var2=var2+ss;
  		}
			fprintf(file1,"%f\t",var2);
	}
	
	
	// save to "gbye"
	double var3=0;
  if(gbye==1)
	{
  	int n_gbye=0;
		for(l1=0;l1<nfixcova;l1++)
			for(l2=0;l2<nqtl;l2++)
  			if(gamma_gbye[l1][l2]!=0.0) n_gbye=n_gbye+1;
	
		for(l1=0;l1<nfixcova;l1++)
			 if(gbye_fix_index[l1]==1)
				for(l2=0;l2<nqtl;l2++)
				if(gamma1[l2]!=0.0)
				if(gamma_gbye[l1][l2]!=0.0)
				{
					fprintf(file5,"\n");
  				fprintf(file5,"%d\t",iter+1);
					fprintf(file5,"%d\t",n_gbye);
					fprintf(file5,"%d\t",l1+1);
  				fprintf(file5,"%d\t",qchr[l2]+1);
  //			fprintf(file5,"%f\t",grid[qchr[l2]][qloc[l2]]);
					fprintf(file5,"%d\t",qloc[l2]);
					for(k=0;k<nc;k++) fprintf(file5,"%f\t",gbye_fix[l1][l2][k]);
  
					double ss1=0,ss2=0,ss=0;
					for(i=0;i<ns;i++)
					{
						double s=0;
						for(k=0;k<nc;k++) s=s+coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];
						ss1=ss1+pow(s,2);
						ss2=ss2+s;
					}
					ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2)); //GXE variance
  				fprintf(file5,"%f\t",ss);
  				var3=var3+ss;
				}
				fprintf(file1,"%f\t",var3);
	}
	
	double var=var1+var2+var3;  //total genetic variance
	if(env_factor==1) fprintf(file1,"%f\t",vp-var-ve0);   //covariate variance
  fprintf(file1,"%f\t",var);
	
	//***********************************************************
  } //group=1 end
	//***********************************************************
	
	//***********************************************************
  }
  //***********************************************************

	// **********************************************************
	} //iter end here
	// **********************************************************

	// **********************************************************
	// ITERATION ENDS HERE
	// **********************************************************
	
	//CALCULATE dhat
	double dhat=0.0;
	amubar/=(double)(niter);
  vebar/=(double)(niter);

	if (longi_factor != 1){ // for independent samples
		if (category==1)
			for (i=0; i<ns; i++)
			{
				gvaluebar[i]/=(double)(niter);
				dhat=dhat+log(2*3.14159265358*vebar)+pow(y[i]-amubar-gvaluebar[i],2)/vebar;
			}
		else { 
			for (l=0; l<=cn; l++) cutpointbar[l]/=(double)(niter);
			for (i=0; i<ns; i++) gvaluebar[i]/=(double)(niter);
			double cc[cn+1],al=0.0;
			for(i=0;i<ns;i++)
			{
				for(l=0; l <=cn; l++) cc[l]=pnorm((cutpointbar[l]-amubar-gvaluebar[i])/sqrt(vebar),0,1,1,0);
				double t=0.0;
				for(l=1; l<=cn; l++) t+=((w[i]==(l-1))*(cc[l]-cc[l-1]));
				al+=log(t+1e-20);
			}
			dhat=-2*al;
		}
	} else { // for longitudinal data

		//dhat = (double) -1.0*num_grid*(num_grid+1.0);
		double *pd, *p, *pt, *pdpt, *del, *psi, *delpsi, *psitdel, *d, **tmp, **tmp_inv, *a, atsiga, det, like;
		int r, s, *t, sum_t, prev_t, i1, j1, sum_t_sq=0, idx;

		p = grid_p;
		r = num_grid; s = num_subject; t = num_timepts;


		for (i1=0; i1<r; i1++) ran_deltabar[i1] /= (double)(niter);
		for (i1=0; i1<0.5*r*(r-1); i1++) ran_psibar[i1] /= (double)(niter);

		//for (i1=0; i1<r; i1++) fprintf(file8,"%lf\t",ran_deltabar[i1]);
		//for (i1=0; i1<0.5*r*(r-1); i1++) fprintf(file8,"%lf\t",ran_psibar[i1]);
		//fprintf(file8,"\n");

		for (i=0; i<ns; i++) gvaluebar[i]/=(double)(niter);

		for (i1=0; i1<s; i1++) sum_t_sq += t[i1]*t[i1];
		
		a = (double *)malloc(max_num_timept*sizeof(double));
		pd = (double *)malloc(ns1*r*sizeof(double));
		del = (double*) malloc(r*r*sizeof(double));
		psi = (double*) malloc(r*r*sizeof(double));
		delpsi = (double*) malloc(r*r*sizeof(double));
		psitdel = (double*) malloc(r*r*sizeof(double));
		d = (double*) malloc(r*r*sizeof(double));
		pt = (double *)malloc(max_num_timept*r*sizeof(double));
		pdpt = (double *)malloc(sum_t_sq*sizeof(double));
		tmp = (double**) malloc(max_num_timept*sizeof(double*));
		tmp_inv = (double**) malloc(max_num_timept*sizeof(double*));
		for (i1=0; i1<max_num_timept; i1++) {
			tmp[i1] = (double*) malloc(max_num_timept*sizeof(double));
			tmp_inv[i1] = (double*) malloc(max_num_timept*sizeof(double));
		}

		for (i1=0; i1<r*r; i1++) {del[i1] = 0; psi[i1] = 0;}

		for (i1=0; i1<r; i1++){ del[i1*(r+1)] = ran_deltabar[i1]; psi[i1*(r+1)] = 1;}

		idx=0;
		for (i1=0; i1<r; i1++) 
			for (j1=(i1+1); j1<r; j1++) { psi[j1*r+i1] = ran_psibar[idx]; idx++; }

		matrix_product(del,psi,delpsi,r,r,r);
		matrix_transpose(delpsi,psitdel,r,r);
		matrix_product(delpsi,psitdel,d,r,r,r);
		matrix_product(p,d,pd,ns1,r,r);
		
		/*for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",del[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",psi[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",delpsi[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",psitdel[k1]);
		for (k1 = 0; k1 < r*r; k1++) fprintf(file8,"%lf\t",d[k1]);*/

		sum_t = 0; prev_t = 0;
		for (i1=0; i1<s; i1++){
			matrix_transpose(p+r*prev_t,pt,t[i1],r);
			matrix_product(pd+r*prev_t,pt,pdpt+sum_t,t[i1],t[i1],r);

			/*if (i1 == 0 || i1 == s-1)
				for (k1 = 0; k1 < t[i1]*t[i1]; k1++) fprintf(file8,"%lf\t",pdpt[sum_t+k1]);*/
			
			sum_t += t[i1]*t[i1];
			prev_t += t[i1];
		}
		//fprintf(file8,"\n");
		
		like = 0;
		prev_t = 0; idx = 0;
		for (k1=0; k1<s; k1++) {

			for (i1=0; i1<t[k1]; i1++)
				for (j1=0; j1<t[k1]; j1++) {
					tmp[i1][j1] = pdpt[idx];
					if (i1 == j1) tmp[i1][j1] += vebar;
					idx++;
				}
		
			if (t[k1]==1) tmp_inv[0][0] = 1.0/tmp[0][0];
			else INVERSE(tmp, t[k1], tmp_inv);

			det = Determinant(tmp, t[k1]);
			
			for (i1=0; i1<t[k1]; i1++)
				a[i1] = y[prev_t+i1]-amubar-gvaluebar[prev_t+i1];

			atsiga = 0;
			for (i1=0; i1<t[k1]; i1++)
				for (j1=0; j1<t[k1]; j1++) 
					atsiga += tmp_inv[i1][j1]*a[i1]*a[j1]; 

			like += -0.5*((double)t[k1])*log(2*3.14159265358) - 0.5*log(det) - 0.5*atsiga;
			
			prev_t += t[k1];

		}

		dhat = -2.0*like;
		
		free(a);
		free(pdpt); 
		free(pt); 
		free(pd); 
		free(psitdel);
		free(d);

		free(delpsi);
		free(psi);
		free(del);

		for (i1=0; i1<max_num_timept; i1++) {
			free(tmp[i1]); 
			free(tmp_inv[i1]);
		}
		
		free(tmp); 
		free(tmp_inv);

	}

	//save dhat
	fprintf(file6,"%lf\n",dhat);
	
	fclose(file1);
	fclose(file2);
  fclose(file3);
	fclose(file4);
  fclose(file5);
	fclose(file6);
	fclose(file7);
	fclose(file8);
}
  
	
	
