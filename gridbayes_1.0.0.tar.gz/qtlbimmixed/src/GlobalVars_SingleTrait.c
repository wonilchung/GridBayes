/******************************************************************************
* File: GlobalVars_SingleTrait.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "GlobalVars_SingleTrait.h"

//***************************************************************************************
// group qbOp variable definitions
/// @{


/// coefficients of QTL main effectsf
double ***coef;
/// QTL position indicators, position is grid[qchr[l]][qloc[l]]
int *qloc;
/// chromosomes that QTL locate
int *qchr;

/// group qbOpCovariate variable definitions
/// @{
/// effects of fixed covariates
double  *fix;
/// effects of random covariates
double  **ran;
/// variances of random covariates
double  *vran;
/// interactions of QTL main effects and fixed covariates
double ***gbye_fix;
/// @}

/// group qbOpIterdiag variable definitions
/// @{
/// overall mean
double amu;
/// QTL indicators
int *gamma1;
/// residual variance
double *ve;
/// @}

/// group qbOpMainloci variable definitions
/// @{
/// main effects
double  **main1;
/// main effects indicators
int *gamma_main;
/// prior variance of main effects
double  **vmain;
/// prior variance of main effects
double  *vmain1;
/// @}

/// group qbOpPairloci variable definitions
/// @{
/// epistatic effects
double ****epistatic;
/// epistatic effects indicators
int **gamma_epistasis;
/// prior variance of epistatic effects
double ****vepistasis;
/// prior variance of epistatic effects
double **vepistasis1;
/// @}

/// group qbOpGbyE variable definitions
/// @{
/// g-by-e indicators
double  **gamma_gbye;
/// prior variance of g-by-e effects
double ***v_gbye_fix;
/// prior variance of g-by-e effects
double **v_gbye_fix1;
/// @}

/// @}


/// QTL genotypes
int **geno;
/// phenotypic data
double *y;
/// genotypic values
double *gvalue;

/// for kinship matrix /////

/// latent normal variable c
double* latent_c;
/// omega value
double* kin_omega;
/// q by c value
double* qcvalue;
/////////////////////////////

/// for longitudinal data ///

/// latent normal variable b
double* latent_b;
/// delta of random effect
double* ran_delta;
/// psi of random effect
double* ran_psi;
/// vb of random effect
double* vbvalue;
/////////////////////////////
