/******************************************************************************
* File: RMultipleTraitMCMCSetup.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "GlobalVars.h"
#include "GlobalVars_MultipleTraits.h"
#include "RInterfaces.h"
#include "MultipleTraitsMCMC.h"

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/Utils.h>

#include <stdio.h>
#include <time.h>
#include <math.h>


void RMultipleTraitsMCMCSetup(int *nind,int *nchr,int *ngen,int *npheno,int *nloci,
	double *loci,double *prob,double *yvalue,int *multipletrait,int *traittype,int *ncategory,
	int *iter,int *thin,int *burnin,
  int *algorithm,int *genoupdate,
	int *epis,int *emainqtl,int *eqtl,int *mnqtl,
	double *interval,int *chrnqtl,
	int *envi,int *qtl_envi,int *nrancov,int *nfixcov,int *intcov,double *rancoef,
	double *fixcoef,int *nran, int *depen,double *prop,int *seed,int *verbose,
	int *diffloc, int *qtlloc)
              
{
	int l,i,j,k,ph;

// **************************************************************************
// parameter values passed from r function bmq.mcmc
  qtlloc1=*qtlloc;
  ns=*nind;
	ns1=*nind;
	nlg=*nchr;
	ng=*ngen;
	npheno1=*npheno;
	multiple1=*multipletrait;
	if(ng==3) cross=2;
	else cross=1;

	ngrid=(int *)S_alloc(nlg, sizeof(int));
  ngrid=nloci;
  tngrid=0;
	for(i=0;i<nlg;i++) tngrid=tngrid+ngrid[i];
	chl=ngrid[0];
  for(i=1;i<nlg;i++)
		if(ngrid[i]>chl) chl=ngrid[i];


	grid=(double **)S_alloc(nlg, sizeof(double *));
	for(i=0;i<nlg;i++) grid[i]=(double *)S_alloc(chl, sizeof(double));
  int pos=0;
	for(i=0;i<nlg;i++)
		for(j=0;j<ngrid[i];j++) 
		{
			grid[i][j]=loci[pos];
			pos=pos+1;
		}


  qprob = (double ****)S_alloc(nlg, sizeof(double ***));
  for(i=0; i<nlg; i++) 
	{
		qprob[i] = (double ***)S_alloc(ns, sizeof(double**));
    for(j=0; j<ns; j++) 
		{
			qprob[i][j] = (double **)S_alloc(chl, sizeof(double *));
			for(k=0; k<chl; k++) 
			{
				qprob[i][j][k] = (double *)S_alloc(ng, sizeof(double));
			}
		}
	}
	pos=0;
	for(l=0;l<nlg;l++)
		for(k=0;k<ng;k++)
			for(j=0;j<ngrid[l];j++)
				for(i=0;i<ns1;i++)
				{
					qprob[l][i][j][k]=prob[pos];
					pos=pos+1;
				}



// test
/*
	FILE *file2;
    file2=fopen("c://Temp//test2.dat","a");
	
	for(l=0;l<nlg;l++)
	{
		fprintf(file2,"\n");
	    for(i=0;i<ns1;i++)
		{
			for(j=0;j<ngrid[l];j++)
			{
				for(k=0;k<ng;k++) fprintf(file2,"%f\t", qprob[l][i][j][k]);
				fprintf(file2,"\n");
			}
		}
	}
    fclose(file2);   */

  
  y=(double **)S_alloc(npheno1,sizeof(double *));
	for(i=0;i<npheno1;i++) 	y[i]=(double *)S_alloc(ns1, sizeof(double));
  pos=0;
	for(j=0;j<npheno1;j++)
			{
				for(k=0;k<ns1;k++) 
        {
          y[j][k]=yvalue[pos];
          pos++;
        }
			}   


	category=*traittype;
	cn=*ncategory;
	
	
	niter=*iter;
	nthin=*thin;
	nburnin=*burnin;
	verbose1=*verbose;
	difflocation=*diffloc;

	gibbs=*algorithm;
	updategeno=*genoupdate;


	epistasis=*epis;
	e_nqtl_main=*emainqtl;
	e_nqtl=*eqtl;
	nqtl=*mnqtl;

	dqq=(double *)S_alloc(nlg, sizeof(double));
	dqq=interval;

	chr_nqtl=(int *)S_alloc(nlg, sizeof(int));
	chr_nqtl=chrnqtl;


	env_factor=*envi; 
	gbye=*qtl_envi;  
	
	nrancova=*nrancov;  
	nfixcova=*nfixcov;  

	gbye_fix_index=(int *)S_alloc(nfixcova, sizeof(int));
	gbye_fix_index=intcov; 

	coef_ran = (double **)S_alloc(ns1, sizeof(double *));
	for(i=0; i<ns1; i++) coef_ran[i] = (double *)S_alloc(nrancova, sizeof(double));
	for(i=0; i<ns1; i++) coef_ran[i]=rancoef+i*(*nrancov);

	nran1=(int *)S_alloc(nrancova,sizeof(int));
	nran1=nran;   

	coef_fix = (double **)S_alloc(ns1, sizeof(double *));
	for(i=0; i<ns1; i++) coef_fix[i] = (double *)S_alloc(nfixcova, sizeof(double));
	for(i=0; i<ns1; i++) coef_fix[i]=fixcoef+i*(*nfixcov);
 

	dependence=*depen;
	c=prop;
	
	seed1=*seed;
     
//***************************************************************************
    
	group=0;
	nc=(group==0)*(ng-1)+(group==1)*ng;

//**************************************************************************
// for binary and ordinal traits
 
	w=(int *)S_alloc(ns1, sizeof(int));
	cutpoint=(double *)S_alloc((cn+1), sizeof(double));

//**************************************************************************
// parameters used in prior specification

	//Calculate the priors of main and epistatic effect indicators
	int nc0=(group==0)*nc+(group==1)*1;
	w_main=0;
	if(nqtl!=0) w_main=1-pow(1-e_nqtl_main*1.0/(nqtl*1.0),1.0/nc0);
	w_epistasis=0;
	if(epistasis==1&&nqtl!=0) w_epistasis=1-pow( (1-e_nqtl*1.0/(nqtl*1.0))/pow(1-w_main,nc0),1.0/(nc0*nc0*(nqtl-1.0)) );
	w_gbye=0;
	if(nqtl!=0) w_gbye=(1.0*e_nqtl_main)/nqtl;

	vmain=(double ***)S_alloc(npheno1, sizeof(double **));
  for(i=0;i<npheno1;i++){
  	vmain[i]=(double **)S_alloc(nqtl, sizeof(double *));
  	for(j=0;j<nqtl;j++)   	vmain[i][j]=(double *)S_alloc(ng, sizeof(double));
  }


	vepistasis = (double *****)S_alloc(npheno1, sizeof(double ****));
  for(l=0;l<npheno1;l++)
  {
		vepistasis[l] = (double ****)S_alloc(nqtl, sizeof(double ***));
  	for(i=0; i<nqtl; i++)
  	{
  		vepistasis[l][i] = (double ***)S_alloc(nqtl, sizeof(double**));
    		for(j=0; j<nqtl; j++)
    		{
    			vepistasis[l][i][j] = (double **)S_alloc(ng, sizeof(double *));
    			for(k=0; k<ng; k++) vepistasis[l][i][j][k] = (double *)S_alloc(ng, sizeof(double));
    		}
     }
  }
    
	v_gbye_fix = (double ****)S_alloc(npheno1, sizeof(double ***));
	for(i=0;i<npheno1;i++)
	{
  	v_gbye_fix[i] = (double ***)S_alloc(nfixcova, sizeof(double **));
  	for(j=0; j<nfixcova; j++) 
  	{
      v_gbye_fix[i][j] = (double **)S_alloc(nqtl, sizeof(double *));
      for(k=0;k<nqtl;k++) v_gbye_fix[i][j][k] = (double *)S_alloc(ng, sizeof(double));
    }
  }
//*********************************************************************************
// genetic model parameters

  amu = (double *)S_alloc(npheno1,sizeof(double));
  sigma = (double **)S_alloc(npheno1,sizeof(double *));
  for(i=0;i<npheno1;i++) sigma[i]=(double *)S_alloc(npheno1,sizeof(double));

	main1 = (double ***)S_alloc(npheno1, sizeof(double **));
	for(i=0; i<npheno1; i++)
  {
   main1[i] = (double **)S_alloc(nqtl, sizeof(double *));
	for(j=0; j<nqtl; j++) main1[i][j] = (double *)S_alloc(ng, sizeof(double)); 
  }                                            
  epistatic = (double *****)S_alloc(npheno1, sizeof(double ****));
  for(ph=0;ph<npheno1;ph++)
  {  	epistatic[ph] = (double ****)S_alloc(nqtl, sizeof(double ***));
  	for(i=0; i<nqtl; i++) 
  	{
		epistatic[ph][i] = (double ***)S_alloc(nqtl, sizeof(double**));
	 	for(j=0; j<nqtl; j++) 
	   	{
			epistatic[ph][i][j] = (double **)S_alloc(ng, sizeof(double *));
			for(k=0; k<ng; k++) 
          epistatic[ph][i][j][k] = (double *)S_alloc(ng, sizeof(double));
    	}
    }
  }

	gvalue=(double **)S_alloc(npheno1, sizeof(double *));
	for(i=0;i<npheno1;i++) gvalue[i] = (double *)S_alloc(ns1,sizeof(double));

  geno = (int ***)S_alloc(npheno1, sizeof(int **));
  for(k=0;k<npheno1;k++)
  {
  	geno[k] = (int **)S_alloc(ns1, sizeof(int *));
  	for(i=0; i<ns1; i++) geno[k][i] = (int *)S_alloc(nqtl, sizeof(int));
  }	

  coef = (double ****)S_alloc(npheno1, sizeof(double ***));
  for(k=0;k<npheno1;k++)
  {
  coef[k] = (double ***)S_alloc(ns1, sizeof(double **));
    for(i=0; i<ns1; i++) 
  	{
  		coef[k][i] = (double **)S_alloc(nqtl, sizeof(double *));
  		for(j=0;j<nqtl;j++) coef[k][i][j]=(double *)S_alloc(ng, sizeof(double));
  	}
  }
  
//******************************************************************************
// QTL positions, genetic effects indicators
// This is for Bayesian SUR which will be used later

	qloc=(int **)S_alloc(npheno1, sizeof(int *));
	for(i=0;i<npheno1;i++) 	qloc[i]=(int *)S_alloc(nqtl, sizeof(int));

	qchr=(int **)S_alloc(npheno1, sizeof(int *));
	for(i=0;i<npheno1;i++) 	qchr[i]=(int *)S_alloc(nqtl, sizeof(int));

	chrqtl=(int *)S_alloc(nlg, sizeof(int));


	gamma1=(int **)S_alloc(npheno1, sizeof(int *));
	for(i=0;i<npheno1;i++) 	gamma1[i]=(int *)S_alloc(nqtl, sizeof(int));

	gamma_main=(int **)S_alloc(npheno1, sizeof(int *));
	for(i=0;i<npheno1;i++) 	gamma_main[i]=(int *)S_alloc(nqtl, sizeof(int));

	gamma_epistasis = (int ***)S_alloc(npheno1, sizeof(int **));
	for(i=0;i<npheno1;i++)
  { 
  gamma_epistasis[i] = (int **)S_alloc(nqtl, sizeof(int *));
	for(j=0; j<nqtl; j++) gamma_epistasis[i][j] = (int *)S_alloc(nqtl, sizeof(int));
  }


//**********************************************************************************
// environmental covariate parameters
	fix=(double **)S_alloc(npheno1, sizeof(double *));
  for(i=0;i<npheno1;i++)	fix[i]=(double *)S_alloc(nfixcova, sizeof(double));

	ran = (double ***)S_alloc(npheno1, sizeof(double **));
  for(i=0;i<npheno1;i++)
  {
	ran[i] = (double **)S_alloc(nrancova, sizeof(double *));
	for(j=0; j<nrancova; j++) ran[i][j] = (double *)S_alloc(ns1, sizeof(double));
  }

  vran=(double **)S_alloc(npheno1, sizeof(double *));
  for(i=0;i<npheno1;i++)	vran[i]=(double *)S_alloc(nrancova, sizeof(double));

	gbye_fix = (double ****)S_alloc(npheno1, sizeof(double ***));
	for(k=0;k<npheno1;k++)
	{
	gbye_fix[k] = (double ***)S_alloc(nfixcova, sizeof(double **));
	for(i=0; i<nfixcova; i++) 
	 {
		gbye_fix[k][i] = (double **)S_alloc(nqtl, sizeof(double *));
		for(j=0;j<nqtl;j++) gbye_fix[k][i][j]=(double *)S_alloc(ng, sizeof(double));
	 }
  }
	gamma_gbye = (double ***)S_alloc(npheno1, sizeof(double **));
  for(i=0;i<npheno1;i++)
  {
	gamma_gbye[i] = (double **)S_alloc(nfixcova, sizeof(double *));
	for(j=0; j<nfixcova; j++) gamma_gbye[i][j] = (double *)S_alloc(nqtl, sizeof(double));
  }
//*********************************************************************************

	
	pd1=(double *)S_alloc(nqtl, sizeof(double));
	pd2=(double *)S_alloc(nqtl, sizeof(double));

	x=(double *)S_alloc(ng, sizeof(double));

//**********************************************************************************

	// Assign the binary or ordinal phenotypes

	//int i,j,k,
	int nl;

	for(i=0;i<ns1;i++)
		if(category!=1) w[i]=(int)y[0][i]; //Don't know if this will work w[i]=(int)y[i];


	// REMOVE THE INDIVIDUALS WITH MISSING PHENOTYPIC AND COVARIATE VALUES
  
	int ii=-1;
	for(i=0;i<ns1;i++)
	{ 	
		int miss=0;			
    int YMISS=0; 
		for(j=0;j<nfixcova;j++) miss=miss+(coef_fix[i][j]==999);
		for(j=0;j<nrancova;j++) miss=miss+(coef_ran[i][j]==999);
  	for(k=0;k<npheno1;k++) YMISS = YMISS + (y[k][i]==999);

		if(YMISS==0&&miss==0)
		{
			ii=ii+1;
			for(k=0;k<npheno1;k++) y[k][ii]=y[k][i];
      w[ii]=w[i];
			for(nl=0;nl<nlg;nl++)
				for(j=0;j<ngrid[nl];j++)
					for(k=0;k<ng;k++) qprob[nl][ii][j][k]=qprob[nl][i][j][k];
			
			for(j=0;j<nfixcova;j++) coef_fix[ii][j]=coef_fix[i][j];
			for(j=0;j<nrancova;j++) coef_ran[ii][j]=coef_ran[i][j];
		}
	
	}
	ns=ii+1;      

//*******************************************
// call mcmc algorithm
	multipleTraitsMCMC();
 
}
