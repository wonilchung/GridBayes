/******************************************************************************
* File: MultipleTraitMCMC.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#include "GlobalVars.h"
#include "GlobalVars_MultipleTraits.h"
#include "StatUtils.h"
#include "MatrixUtils.h"
#include "MultipleTraitsMCMC.h"

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/Utils.h>

#include <math.h>
#include <time.h>

// global variables - Cross,x.
///Transfering genotypes to regression coefficients
/*
void Coefficient(int genotype)          //updategeno=1
{
	int k;

	if(group==1)
	{
		for(k=0;k<ng;k++) x[k]=(genotype==k)*1.0;
	}

	if(group==0)
	{
		if(cross==2)                 //Cockerham model
		{
			x[0]=genotype-1.0,
			x[1]=genotype*(2.0-genotype)-0.5;
		}
		else x[0]=genotype-0.5;
	}

	return;
} */


void ResidualVariance_MultipleTraits()
{
 double **newsigma,**g,**chol,*mu,*sample;
 double det,**temp,**omega;
 int i,j,k;

 newsigma = malloc(npheno1*sizeof(double *));
 for(i=0;i<npheno1;i++) newsigma[i]= malloc(npheno1*sizeof(double));

 omega = malloc(npheno1*sizeof(double *));
 for(i=0;i<npheno1;i++) omega[i]= malloc(npheno1*sizeof(double));

 chol = malloc(npheno1*sizeof(double *));
 for(i=0;i<npheno1;i++) chol[i]= malloc(npheno1*sizeof(double));

 temp = malloc(npheno1*sizeof(double *));
 for(i=0;i<npheno1;i++) temp[i]= malloc(npheno1*sizeof(double));

 g = malloc(npheno1*sizeof(double *));
 for(i=0;i<npheno1;i++) g[i]= malloc(ns*sizeof(double));
 
 mu = malloc(npheno1*sizeof(double));

 sample = malloc(npheno1*sizeof(double));
   
 for(i=0;i<npheno1;i++)
 {
  mu[i]=0;
  sample[i]=0;
  for(j=0;j<npheno1;j++)
    {
     newsigma[i][j]=0;
     temp[i][j]=0;
     omega[i][j]=0;
     chol[i][j]=0;     
    }
    
   for(k=0;k<ns;k++) g[i][k]=0;  
 }

  for(i=0;i<ns;i++)
     for(j=0;j<npheno1;j++) 
          g[j][i] = y[j][i] - amu[j] - gvalue[j][i];
 
 
	XprimeX(g,npheno1,ns,omega);

  det = Determinant(omega,npheno1);
  if(det < 1e-15 ){     
		Rprintf("\n\n Covariance matrix approaching near singularity.. quitting!\n");
		exit(1);
  }   
  else {
		INVERSE(omega,npheno1,temp);
		Cholesky(temp,npheno1,chol);
  }
     

	for(i=0;i<npheno1;i++)
    for(j=0;j<npheno1;j++)   
		{
      temp[i][j]=0;
      newsigma[i][j]=0;  
		}     
  for(i=0;i<ns;i++)
  {
     Multivariate_RNORM(chol,mu,npheno1,sample);  
      for(j=0;j<npheno1;j++)
        for(k=0;k<npheno1;k++)
          temp[j][k] = sample[j]*sample[k];
     MatrixCopy(temp,newsigma,npheno1,npheno1,1);
     
   } 

	//   if(gibbs==1)   
	MatrixCopy(newsigma,sigma,npheno1,npheno1,0);        
	/*
	if(gibbs==0)
	{

   det=Determinant(newsigma,npheno1);
   if(det < 1e-15)  {
    Rprintf("\n Determinant of newly sampled Sigma near 0 det= %f\n",det);
    exit(1); 
   }
   
   double det1,like_old,like_new,alpha,r;
   XprimeY(omega,newsigma,npheno1,npheno1,npheno1,temp);
   like_new = pow(det,ns/2)*exp(-0.5*Trace(temp,npheno1));
   det1 = Determinant(sigma,npheno1);
   XprimeY(omega,sigma,npheno1,npheno1,npheno1,temp);
   like_old = pow(det1,ns/2)*exp(-0.5*Trace(temp,npheno1));
   alpha = like_new/like_old;

   int accept=0;
   if(alpha < 1)
   {
    r=RANDOM();
    if(r < alpha)
    { MatrixCopy(newsigma,sigma,npheno1,npheno1,0);        
     accept = 1;
    }
   }
   else {
   MatrixCopy(newsigma,sigma,npheno1,npheno1,0);        
   accept=1;
   }
 }*/     
    for(i=0;i<npheno1;i++)
    {
     free(newsigma[i]);
     free(omega[i]);
     free(temp[i]);
     free(chol[i]);
     free(g[i]);
    }
    free(newsigma);
    free(omega);
    free(temp);
    free(chol);
    free(mu);
    free(sample);
    free(g);
 
}


void MT_Coefficient0(int i,int l,int ph,int ql)     //updategeno=0
{ 
	if(cross==2)                //Cockerham model
	{
		x[0]=qprob[qchr[ph][l]][i][ql][2]-qprob[qchr[ph][l]][i][ql][0],
		x[1]=0.5*(qprob[qchr[ph][l]][i][ql][1]-qprob[qchr[ph][l]][i][ql][0]-qprob[qchr[ph][l]][i][ql][2]);
	}
	else x[0]=0.5*(qprob[qchr[ph][l]][i][ql][1]-qprob[qchr[ph][l]][i][ql][0]);

	return;
}

//******************************************************************************************
//used in updating QTL genotypes and locations.

double MT_GenotypeSampling(int i,int l,int ph,int ii,int ql)   //if updategeno==1(0), dosenot need ql(ii) 
{
    int l1,k,k1,k2; double g;
	
	if(updategeno==1) Coefficient(ii);
	if(updategeno==0) MT_Coefficient0(i,l,ph,ql);
	g=gvalue[ph][i];
	for(k=0;k<nc;k++) g=g-coef[ph][i][l][k]*main1[ph][l][k]+x[k]*main1[ph][l][k];
			
	if(epistasis==1)
		for(l1=0;l1<nqtl;l1++)
		{
			if(l1<l && gamma1[ph][l1]!=0 && gamma_epistasis[ph][l1][l]!=0)
				for(k1=0;k1<nc;k1++)
					for(k2=0;k2<nc;k2++) 
		g=g-coef[ph][i][l1][k1]*coef[ph][i][l][k2]*epistatic[ph][l1][l][k1][k2]+coef[ph][i][l1][k1]*x[k2]*epistatic[ph][l1][l][k1][k2];

            if(l1>l && gamma1[ph][l1]!=0 && gamma_epistasis[ph][l][l1]!=0) 
				for(k1=0;k1<nc;k1++)
					for(k2=0;k2<nc;k2++) 
						g=g-coef[ph][i][l][k1]*coef[ph][i][l1][k2]*epistatic[ph][l][l1][k1][k2]+x[k1]*coef[ph][i][l1][k2]*epistatic[ph][l][l1][k1][k2];
		}

	if(gbye==1)
		for(l1=0;l1<nfixcova;l1++) 
			if(gbye_fix_index[l1]==1&&gamma_gbye[ph][l1][l]!=0)
				for(k=0;k<nc;k++) 
					g=g-coef_fix[i][l1]*coef[ph][i][l][k]*gbye_fix[ph][l1][l][k]
                                    +coef_fix[i][l1]*x[k]*gbye_fix[ph][l1][l][k];
		
	return(g);
} 
   
//*************************************************************************************
// update the overall mean

void MT_Mean(double y_bar,double vp,int trait)  //prior for amu is N(y_bar,vp)
{
	int i,ph; double t=0.0,u,u0,g[npheno1][ns1]; 
	if(multiple1==0)
	{	
    for(i=0;i<ns;i++) t=t+(y[0][i]-gvalue[0][i]);
	
	ANORMAL(&u,&u0); 
	amu[trait]=(t+y_bar*ve/vp)/(ns+ve/vp)+u*sqrt(ve/(ns+ve/vp));  
  }
	else if(multiple1>=1)
	{
    for(i=0;i<ns;i++) 
    {  for(ph=0;ph<npheno1;ph++)
      {
       if(ph==trait) g[ph][i]=gvalue[ph][i];
       else g[ph][i]=gvalue[ph][i] + amu[ph];         
  
       t=t+(y[ph][i]-g[ph][i])*sigma[trait][ph];
        }   
     }
	ANORMAL(&u,&u0); 
	amu[trait]=(t+y_bar/vp)/(ns*sigma[trait][trait]+1/vp)+u/sqrt(ns*sigma[trait][trait]+1/vp); 
 } 
	return;
}
//*******************************************************
//update marginal effects
  
void MT_MainEffect(int l,int trait,int forindicators,int effect)
{
	int i,k,ph; double g[npheno1][ns1],t1,t2,t3,u,u0;
	for(k=0;k<nc;k++) 
	{ if(forindicators==1) k=effect;
		if(main1[trait][l][k]!=0 || forindicators==1)
		{
			t1=0,t2=0;
			for(i=0;i<ns;i++)                     
			{
				double z=coef[trait][i][l][k];
				if(multiple1==0)
				{
        g[trait][i]=gvalue[trait][i]-z*main1[trait][l][k];
				t1=t1+z*(y[trait][i]-amu[trait]-g[trait][i]);
				t2=t2+pow(z,2);
				}
				if(multiple1>=1)
				{ 
				  for(ph=0;ph<npheno1;ph++)
				  {
            if(ph==trait) g[ph][i]=gvalue[ph][i]-z*main1[ph][l][k];
            else g[ph][i]=gvalue[ph][i];
             
	   		  	t1=t1+z*(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
		  		  }
		  		  t2=t2+z*z;            								
				}
			}	
       	
  		ANORMAL(&u,&u0);
      if(multiple1==0)	{      
     		t3=1/vmain[trait][l][k]+t2/ve;
	   		main1[trait][l][k]=t1/(ve*t3)+u/sqrt(t3);
			}
      else if(multiple1>=1) {
        t3=t2*sigma[trait][trait] + 1/vmain[trait][l][k];
	   		main1[trait][l][k]=t1/t3+u/sqrt(t3);
      }
			for(i=0;i<ns;i++) gvalue[trait][i]=g[trait][i]+coef[trait][i][l][k]*main1[trait][l][k];
		}
		
		if(forindicators==1) k=nc-1;
		  
	}
	return;
}


//************************************************************
//update epistatic effects

void MT_EpistaticEffect(int l1,int l2,int trait)
{
	int i,k1,k2,ph; double g[npheno1][ns1],t1,t2,t3,u,u0;

	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++)
		{
			if(epistatic[trait][l1][l2][k1][k2]!=0)
			{
				if(multiple1==0)
				{
					t1=0,t2=0;
					for(i=0;i<ns;i++)                     
					{
						double z=coef[0][i][l1][k1]*coef[0][i][l2][k2];
						g[trait][i]=gvalue[trait][i]-z*epistatic[0][l1][l2][k1][k2];
						t1=t1+z*(y[0][i]-amu[0]-g[0][i]);
						t2=t2+pow(z,2);
					}	 	
					t3=1/vepistasis[0][l1][l2][k1][k2]+t2/ve;

					ANORMAL(&u,&u0);
					epistatic[0][l1][l2][k1][k2]=t1/(ve*t3)+u/sqrt(t3);
	 
					for(i=0;i<ns;i++) 
						gvalue[0][i]=g[0][i]+coef[0][i][l1][k1]*coef[0][i][l2][k2]*epistatic[0][l1][l2][k1][k2];
				}
				if(multiple1>=1)
				{
					t1=0,t2=0;
					for(i=0;i<ns;i++)                     
					{
						double z=coef[trait][i][l1][k1]*coef[trait][i][l2][k2];
						for(ph=0;ph<npheno1;ph++)
						{
							if(ph==trait)  g[ph][i]=gvalue[ph][i]-z*epistatic[ph][l1][l2][k1][k2];
							else g[ph][i]=gvalue[ph][i];
							
							t1=t1+z*(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
						}
						t2=t2+z*z;

					}	 	
					t3=t2*sigma[trait][trait] + 1.0/vepistasis[trait][l1][l2][k1][k2];
					
					ANORMAL(&u,&u0);
					epistatic[trait][l1][l2][k1][k2]=t1/t3+u/sqrt(t3);
	 
					for(i=0;i<ns;i++) 
						gvalue[trait][i]=g[trait][i]+coef[trait][i][l1][k1]*coef[trait][i][l2][k2]*epistatic[trait][l1][l2][k1][k2];
				}
			}
		}

	return;
} 

//************************************************************
//update g by e fixed effects

void MT_GBYE_FixedCovariate(int l1,int l2,int trait)
{
	int i,k,ph; double g[npheno1][ns1],t1,t2,t3,u,u0;

	for(k=0;k<nc;k++)
	{
		if(gbye_fix[trait][l1][l2][k]!=0)
		{
			if(multiple1==0)
			{
				t1=0,t2=0;
				for(i=0;i<ns;i++)                     
				{
					double z=coef_fix[i][l1]*coef[0][i][l2][k];
					g[0][i]=gvalue[0][i]-z*gbye_fix[0][l1][l2][k];
					t1=t1+z*(y[0][i]-amu[0]-g[0][i]);
					t2=t2+pow(z,2);
				}	 	
		 		t3=1/v_gbye_fix[0][l1][l2][k]+t2/ve;

				ANORMAL(&u,&u0);
				gbye_fix[0][l1][l2][k]=t1/(ve*t3)+u/sqrt(t3);

				for(i=0;i<ns;i++) gvalue[0][i]=g[0][i]+coef_fix[i][l1]*coef[0][i][l2][k]*gbye_fix[0][l1][l2][k];
			}
			if(multiple1>=1)
			{
				t1=0,t2=0;
				for(i=0;i<ns;i++)
				{
					double z=coef_fix[i][l1]*coef[trait][i][l2][k];
					for(ph=0;ph<npheno1;ph++)
					{
							if(ph==trait) g[ph][i]=gvalue[ph][i]-z*gbye_fix[ph][l1][l2][k];
							else g[ph][i]=gvalue[ph][i];

							t1=t1+z*(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
					}
					t2=t2+z*z;
				}
				t3=t2*sigma[trait][trait] + 1.0/v_gbye_fix[trait][l1][l2][k];
				ANORMAL(&u,&u0);
				gbye_fix[trait][l1][l2][k]=t1/t3+u/sqrt(t3);

				for(i=0;i<ns;i++) 
				gvalue[trait][i]=g[trait][i]+coef_fix[i][l1]*coef[trait][i][l2][k]*gbye_fix[trait][l1][l2][k];
			}
		}
	}

	return;
}

//***********************************************************
//updating genetic variances


void MT_MainVariance(int l,int k,int nu,double tau,int trait) //prior for vmain is Inv-chisq(nu,(nu-2)/nu*tau),E(vmain)=tau
{

	int j; double t1,t2,u,u0;

	t1=pow(main1[trait][l][k],2);
	t2=0;
	for(j=0;j<1+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	vmain[trait][l][k]=(t1+nu*tau)/t2;

	return;

}

/*  
void MT_EpistaticVariance(double vp,int trait)    //prior for vepistasis is Inv-chisq(nu,(nu-2)/nu*tau),E(vepistasis)=tau
{
	int l1,l2,k1,k2,j;double t1,t2,u,u0;

	int nu=6; double tau=0.1;

	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++)
		{
			int n_epis=0;
			for(l1=0;l1<nqtl;l1++)
				for(l2=0;l2<nqtl;l2++)
					if(epistatic[trait][l1][l2][k1][k2]!=0) n_epis=n_epis+1; 
			
			t1=0,t2=0;
			for(l1=0;l1<nqtl;l1++)
				for(l2=l1+1;l2<nqtl;l2++)
					if(epistatic[trait][l1][l2][k1][k2]!=0) t1=t1+pow(epistatic[trait][l1][l2][k1][k2],2);

			for(j=0;j<n_epis+nu;j++)
			{
				ANORMAL(&u,&u0);
				t2=t2+u*u; 
			} 
     	
			t1=t1/(vepistasis[trait][k1][k2]*vp);t2=t2/(vepistasis[trait][k1][k2]*vp);
			vepistasis[trait][k1][k2]=(t1+nu*(nu-2.0)/nu*tau)/t2;
		}

	return;
} */ 

void MT_EpistaticVariance(int l1,int l2,int k1,int k2,int nu,double tau,int trait)    //prior for vepistasis is Inv-chisq(nu,(nu-2)/nu*tau),E(vepistasis)=tau
{
	int j;double t1,t2,u,u0;

	t1=pow(epistatic[trait][l1][l2][k1][k2],2);
	t2=0;
	for(j=0;j<1+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	vepistasis[trait][l1][l2][k1][k2]=(t1+nu*tau)/t2;

	return;
}

//updating genetic variances
/*
void MT_GBYE_FixedCovariate_Variance(int l1,double vp,int trait)  //prior for V_GBYE is Inv-chisq(nu,(nu-2)/nu*tau),E(V_GBYE)=tau
{
	int l2,k,j; double t1,t2,u,u0;

	int nu=6; double tau=0.1;

	for(k=0;k<nc;k++) 
	{
		int n_gbye=0; 
		for(l2=0;l2<nqtl;l2++)
			if(gbye_fix[trait][l1][l2][k]!=0) n_gbye=n_gbye+1;

		t1=0,t2=0;
		for(l2=0;l2<nqtl;l2++)
			if(gbye_fix[trait][l1][l2][k]!=0) t1=t1+pow(gbye_fix[trait][l1][l2][k],2);

		for(j=0;j<n_gbye+nu;j++)
		{
			ANORMAL(&u,&u0);
			t2=t2+u*u; 
		} 
     	
		t1=t1/(v_gbye_fix[trait][l1][k]*vp);t2=t2/(v_gbye_fix[trait][l1][k]*vp);
		v_gbye_fix[trait][l1][k]=(t1+nu*(nu-2.0)/nu*tau)/t2;
	}

	return;
} */

void MT_GBYE_FixedCovariate_Variance(int l1,int l2,int k,int nu,double tau,int trait)  //prior for V_GBYE is Inv-chisq(nu,(nu-2)/nu*tau),E(V_GBYE)=tau
{
	int j; double t1,t2,u,u0;

	t1=pow(gbye_fix[trait][l1][l2][k],2);
	t2=0;
	for(j=0;j<1+nu;j++)
	{
		ANORMAL(&u,&u0);
		t2=t2+u*u;
	}
	v_gbye_fix[trait][l1][l2][k]=(t1+nu*tau)/t2;
	
	return;
}

        
 
//*******************************************************
//update nongenetic effects

void MT_FixedCovariate(int l,int trait)
{
	int i,ph; double g[npheno1][ns1],z,t1=0.0,t2=0.0,t3,u,u0;

    for(i=0;i<ns;i++)
    {			
			z=coef_fix[i][l];
  		for(ph=0;ph<npheno1;ph++)
  		{
        if(ph==trait)		g[ph][i]=gvalue[ph][i]-z*fix[ph][l]; 
        else g[ph][i]=gvalue[ph][i];		
      	t1=t1+z*(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
  		}
     t2=t2+z*z;
    }
	t3=t2*sigma[trait][trait];	               //prior is uniform

	ANORMAL(&u,&u0); 	
	fix[trait][l]=t1/t3+u/sqrt(t3);
        
	for(i=0;i<ns;i++) gvalue[trait][i]=g[trait][i]+coef_fix[i][l]*fix[trait][l];

	return;
}

void MT_RandomCovariate(int l, int trait)
{
	int i,k,ph; double g[npheno1][ns1],t1,t2,t3,u,u0;
		
	for(i=0;i<ns;i++) 
	 for(ph=0;ph<npheno1;ph++)
	   if(ph==trait)
         g[ph][i]=gvalue[ph][i]-ran[ph][l][(int)coef_ran[i][l]];
      else g[ph][i]=gvalue[ph][i];

	for(k=0;k<nran1[l];k++)
	{
		t1=0,t2=0;
		for(i=0;i<ns;i++)                    
			if(coef_ran[i][l]==k)
			{
  		for(ph=0;ph<npheno1;ph++) t1=t1+(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
				t2=t2+1.0;
			}	 	
		t3=1/vran[trait][l]+t2*sigma[trait][trait];

		ANORMAL(&u,&u0);
		ran[trait][l][k]=t1/t3+u/sqrt(t3);
	}	
	for(i=0;i<ns;i++) gvalue[trait][i]=g[trait][i]+ran[trait][l][(int)coef_ran[i][l]];
		
	return;	
}

void MT_RanVariance(int l,double vp,int trait)         //prior is Inv-chisq(nu,tau) Now prior is uniform
{
	int k; double t1=0,t2=0,u,u0;

//	int nu=6; double tau=vp/3;

	for(k=0;k<nran1[l];k++) t1=t1+pow(ran[trait][l][k],2);
	for(k=0;k<nran1[l]-2;k++)
	{
        ANORMAL(&u,&u0);
        t2=t2+u*u; 
	} 
     	
	vran[trait][l]=t1/t2;      //see Gelman P301
	
	return;
}
    
//***********************************************************
//update QTL genotypes : generate ibd

void MT_QTLgenotype(int trait,int l,int nl,int ql,int i)    //trait not used for same.loc
{ 
	int k,ph,ph1; double summ[ng],temp[npheno1],summ_sl[npheno1][ng];              
  
  if(difflocation==1)
	for(k=0;k<ng;k++) summ[k]=MT_GenotypeSampling(i,l,trait,k,ql); 

  if(difflocation==0)
  for(ph=0;ph<npheno1;ph++)
  	for(k=0;k<ng;k++) summ_sl[ph][k]=MT_GenotypeSampling(i,l,ph,k,ql); 
              
    double sum1=0.0;
    for(k=0;k<ng;k++)
    {
			if(multiple1==0)
    	{
         summ[k]=exp(-0.5*pow(y[0][i]-(amu[0]+summ[k]),2)/ve)*qprob[nl][i][ql][k];
         sum1=sum1+summ[k]; 
			}
			if(multiple1>0)
        {
         double sum=0.0;  
         if(difflocation==1)
         {
            for(ph=0;ph<npheno1;ph++)
            {
              temp[ph]=0.0;
              for(ph1=0;ph1<npheno1;ph1++)
               { 
               if(ph1==trait)  temp[ph] = temp[ph] + (y[ph1][i]-amu[ph1]-summ[k])*sigma[ph][ph1];
               else temp[ph] = temp[ph] + (y[ph1][i]-amu[ph1]-gvalue[ph1][i])*sigma[ph][ph1];
                }
               if(ph==trait) sum = sum +temp[ph]*(y[ph][i]-amu[ph]-summ[k]);
               else sum = sum + temp[ph]*(y[ph][i]-amu[ph]-gvalue[ph][i]);   
             }
           }
         if(difflocation==0)
         {
            for(ph=0;ph<npheno1;ph++)
            {
              temp[ph]=0.0;
              for(ph1=0;ph1<npheno1;ph1++)
              temp[ph] = temp[ph] + (y[ph1][i]-amu[ph1]-summ_sl[ph1][k])*sigma[ph][ph1];

              sum = sum +temp[ph]*(y[ph][i]-amu[ph]-summ_sl[ph][k]);
             }
           }
               
         summ[k]=exp(-0.5*sum)*qprob[nl][i][ql][k];
         sum1=sum1+summ[k]; 
        }
    }
	for(k=0;k<ng;k++) summ[k]=summ[k]/sum1; 

    MULTINORMAL(summ);

	pdd1=0.0,pdd2=0.0;
    for(k=0;k<ng;k++)
    {
	   pdd1=pdd1+qprob[nl][i][ql][k]*(ibd==k);
     pdd2=pdd2+summ[k]*(ibd==k);
    }     
	return;
}

//*******************************************************
//UPDATE THE QTL INHERITANCE OF NON-FOUNDERS

void MT_QTLINHERITANCE(int l,int i,int trait)
{   
	int k;

	MT_QTLgenotype(trait,l,qchr[trait][l],qloc[trait][l],i); 

	geno[trait][i][l]=ibd;
	Coefficient(ibd);
	for(k=0;k<nc;k++) coef[trait][i][l][k]=x[k];
    
	pd1[l]=pd1[l]+log(pdd1+1e-20);
    pd2[l]=pd2[l]+log(pdd2+1e-20);		    

	return;
}
 
double LogLikelihood(double **yvalue,double **gvalue,double *mu,double **sigma)
{
 double likelihood=0.0,temp[npheno1],sum=0.0;
 int i,ph,ph1;
 for(i=0;i<ns;i++)
 {
		sum=0.0;
    for(ph=0;ph<npheno1;ph++)
    {
      temp[ph]=0.0;
      for(ph1=0;ph1<npheno1;ph1++)
      { 
      temp[ph] = temp[ph] + (yvalue[ph1][i]-mu[ph1]-gvalue[ph1][i])*sigma[ph][ph1];
       }
       sum = sum + temp[ph]*(yvalue[ph][i]-mu[ph]-gvalue[ph][i]);
     }  
    likelihood = likelihood + sum;
 }

 likelihood = -0.5*likelihood;
 return(likelihood);

} 
 
//*******************************************************
//UPDATE POSITIONS OF QTLS

void MT_QTLPOSITION(int l,int qlnew,int trait)
{
	int i,ph,geno1[ns1],k; 
  double **g;
  g = malloc(npheno1*sizeof(double *));
  for(ph=0;ph<npheno1;ph++) g[ph]= malloc(ns1*sizeof(double));

	double prob0=0.0,prob1=0.0,pd10=0.0,pd20=0.0;

	if(multiple1==0)  for(i=0;i<ns;i++)  prob0=prob0-0.5*pow(y[0][i]-amu[0]-gvalue[0][i],2)/ve;

	if(multiple1>=1)  prob0=LogLikelihood(y,gvalue,amu,sigma);

	for(i=0;i<ns;i++)
	{
		if(updategeno==1)
		{
			int kk=0;
			for(k=0;k<ng;k++)
				if(qprob[qchr[trait][l]][i][qlnew][k]>0.99) 
				{
					geno1[i]=k;
					kk=1;
				}    
			if(kk==0)
			{
        MT_QTLgenotype(trait,l,qchr[trait][l],qlnew,i);                             
				pd10=pd10+log(pdd1+1e-20);
				pd20=pd20+log(pdd2+1e-20);
				geno1[i]=ibd;
			}
			int ii=geno1[i];
           if(multiple1==0) 
             {
                g[0][i] = MT_GenotypeSampling(i,l,0,ii,qlnew); //0 is not 
                prob1=prob1-0.5*pow(y[0][i]-amu[0]-g[0][i],2)/ve;               
             }
          if(multiple1==1) 
            {
            for(ph=0;ph<npheno1;ph++)
        			g[ph][i]=MT_GenotypeSampling(i,l,ph,ii,qlnew);  //qlnew is not used
        		}	
          if(multiple1==2) 
            {
              for(ph=0;ph<npheno1;ph++)
              {
                 if(difflocation==0)
                 {
                  if(gamma1[ph][l]!=0) g[ph][i]=MT_GenotypeSampling(i,l,ph,ii,qlnew); 
                  else g[ph][i]=gvalue[ph][i];
                  }
                 if(difflocation==1)
                 { 
                  if(gamma1[ph][l]!=0 && ph==trait) 
                        g[ph][i]=MT_GenotypeSampling(i,l,ph,ii,qlnew); 
                  else g[ph][i]=gvalue[ph][i];
                 } 
              }
        		}	
		} 
        
		if(updategeno==0) 
      {  
       if(multiple1==0) 
            {
            g[0][i] = MT_GenotypeSampling(i,l,0,0,qlnew); //0 is not 
            prob1=prob1-0.5*pow(y[0][i]-amu[0]-g[0][i],2)/ve;               
            }
          if(multiple1==1) 
            for(ph=0;ph<npheno1;ph++)
                    g[ph][i]=MT_GenotypeSampling(i,l,ph,0,qlnew); //0 is not used

          if(multiple1==2) 
            for(ph=0;ph<npheno1;ph++)
            {
             if(difflocation==0)
             {
              if(gamma1[ph][l]!=0) g[ph][i]=MT_GenotypeSampling(i,l,ph,0,qlnew); 
              else g[ph][i]=gvalue[ph][i];
              }
             if(difflocation==1)
              { 
              if(gamma1[ph][l]!=0 && ph==trait) g[ph][i]=MT_GenotypeSampling(i,l,ph,0,qlnew); 
              else g[ph][i]=gvalue[ph][i];
              }
            }
        
      }  
	}   


if(multiple1>=1)  prob1 = LogLikelihood(y,g,amu,sigma);

    double s1=(prob1-prob0)+(pd10-pd1[l])+(pd2[l]-pd20); //Needed for genoupdate
         
 if(s1>log(RANDOM())) 
	{
		qloc[trait][l]=qlnew;
   for(i=0;i<ns;i++)          
		{
			if(updategeno==1)
			{
				geno[trait][i][l]=geno1[i];
				Coefficient(geno1[i]);
			}  

      if(updategeno==0) MT_Coefficient0(i,l,trait,qloc[trait][l]);

			for(k=0;k<nc;k++) coef[trait][i][l][k]=x[k];

      for(ph=0;ph<npheno1;ph++)  gvalue[ph][i]=g[ph][i];				
  			
		}		
	 		
		pd1[l]=pd10,pd2[l]=pd20;
	}
		   for(ph=0;ph<npheno1;ph++)  free(g[ph]);
		   free(g);
	return;
}                              




void QTLPOSITION_SameLocation(int l,int qlnew)
{
	int i,ph,k;
// int geno1[ns1];   
   double **g;
   g = malloc(npheno1*sizeof(double *));
   for(ph=0;ph<npheno1;ph++) g[ph]= malloc(ns1*sizeof(double));

	double prob0=0.0;

 if(multiple1==0)  for(i=0;i<ns;i++)  prob0=prob0-0.5*pow(y[0][i]-amu[0]-gvalue[0][i],2)/ve;

 if(multiple1>=1)  prob0=LogLikelihood(y,gvalue,amu,sigma);

            
    double prob1=0.0,pd10=0.0,pd20=0.0;       
	for(i=0;i<ns;i++)
	{
/*		if(updategeno==1)
		{
			int kk=0;
			for(k=0;k<ng;k++)
				if(qprob[qchr[l]][i][qlnew][k]>0.99) 
				{
					geno1[i]=k;
					kk=1;
				}    
			if(kk==0)
			{
				MT_QTLgenotype(l,qchr[l],qlnew,i);                             
           
				pd10=pd10+log(pdd1+1e-20);
				pd20=pd20+log(pdd2+1e-20);

				geno1[i]=ibd;
			}
			int ii=geno1[i];
			g[i]=MT_GenotypeSampling(i,l,ii,qlnew);  //qlnew is not used
		} 
        */
		if(updategeno==0) 
      {  
       if(multiple1==0) 
            {
            g[0][i] = MT_GenotypeSampling(i,l,0,0,qlnew); //0 is not 
            prob1=prob1-0.5*pow(y[0][i]-amu[0]-g[0][i],2)/ve;               
            }
          if(multiple1==1) 
            for(ph=0;ph<npheno1;ph++)
                    g[ph][i]=MT_GenotypeSampling(i,l,ph,0,qlnew); //0 is not used

          if(multiple1==2) 
            for(ph=0;ph<npheno1;ph++)
            {
              if(gamma1[ph][l]!=0) g[ph][i]=MT_GenotypeSampling(i,l,ph,0,qlnew); 
              else g[ph][i]=gvalue[ph][i];
            }
        
      }  
	}   


	if(multiple1>=1)  prob1 = LogLikelihood(y,g,amu,sigma);

  double s1=(prob1-prob0)+(pd10-pd1[l])+(pd2[l]-pd20); //Needed for genoupdate
         
	if(s1>log(RANDOM())) 
	{
    qloc[0][l]=qlnew;
   for(i=0;i<ns;i++)          
		{
      if(updategeno==0) MT_Coefficient0(i,l,0,qloc[0][l]);
			for(k=0;k<nc;k++) coef[0][i][l][k]=x[k];

    for(ph=0;ph<npheno1;ph++)  gvalue[ph][i]=g[ph][i];				
      
/*			if(updategeno==1)
			{
				geno[i][l]=geno1[i];
				Coefficient(geno1[i]);
			}  */
			
		}		
	 	
		pd1[l]=pd10,pd2[l]=pd20;
	}
		   for(ph=0;ph<npheno1;ph++)  free(g[ph]);
		   free(g);
	return;
}                              
                     
//*************************************************************
//Sampling a position

int MT_SamplingOnePosition(int l,int trait)
{	
	int nl,ph,i,k,chr0[nlg],t,tt,ttt,grid00[tngrid]; double r,grid0[tngrid];                                   
	for(i=0;i<nlg;i++)
	{
		chrqtl[i]=0;
  if(difflocation==1)		
		for(k=0;k<nqtl;k++) chrqtl[i]=chrqtl[i]+(qchr[trait][k]==i&&gamma1[trait][k]!=0);

	if(difflocation==0)	
		for(k=0;k<nqtl;k++) 
  		{ t=0;
        if(qchr[trait][k]==i)
    		  {
           for(ph=0;ph<npheno1;ph++) t = t+gamma1[ph][k];
            chrqtl[i]=chrqtl[i]+(t>=1);
          } 
      }    

		
	}
// chrqtl contains the number of QTLs in each chromosome that are currently in the model
	t=0;
  for(i=0;i<nlg;i++) 
	{
		if(grid[i][ngrid[i]-1]!=0&&dqq[i]!=0)
			chr0[i]=ngrid[i]-(int)(2*dqq[i]*chrqtl[i]*ngrid[i]/grid[i][ngrid[i]-1]);
		if(dqq[i]==0) chr0[i]=ngrid[i]-chrqtl[i];
		if(grid[i][ngrid[i]-1]==0) chr0[i]=0;
		if(chrqtl[i]>=chr_nqtl[i]||chr0[i]<=0) chr0[i]=0;
		t=t+chr0[i];
	}
//chr0 stores the number of putative QTL positions that is going to be considered for the new position.
	if(t!=0)
	{
		r=t*RANDOM();
		tt=0;
    for(i=0;i<nlg;i++) 
		{
			if(r>=tt&&r<(tt+chr0[i])) qchr[trait][l]=i;
			tt=tt+chr0[i];
		}		
		nl=qchr[trait][l];
		if(chrqtl[nl]+1>chr_nqtl[nl]||chr0[nl]==0) t=0;
	}

	if(t!=0)
	{
		if(chrqtl[nl]==0) qloc[trait][l]=(int)(RANDOM()*ngrid[nl]);
		if(chrqtl[nl]>0)
		{
			tt=0;
			if(difflocation==1)
    		{	for(k=0;k<nqtl;k++)
      				if(qchr[trait][k]==nl&&gamma1[trait][k]!=0) 
      				{
      					grid0[tt]=grid[nl][qloc[trait][k]];
      					tt=tt+1;
      				}
      	}
      	
    	if(difflocation==0)
      	{	for(k=0;k<nqtl;k++)
      			if(qchr[trait][k]==nl)
      				{
      				 int temp=0;
        		   for(ph=0;ph<npheno1;ph++) temp = temp+gamma1[ph][k];
      				 if(temp>=1)
               { 
      					grid0[tt]=grid[nl][qloc[trait][k]];
      					tt=tt+1;
      					}
      				}
         }
			
//grid0 contains the locations of all QTLs on chr nl (the new chromosome) currently in the model
			qloc[trait][l]=(int)(RANDOM()*ngrid[nl]);
			tt=0;
			for(k=0;k<chrqtl[nl];k++)
				if(fabs(grid[nl][qloc[trait][l]]-grid0[k])<=dqq[nl]) tt=tt+1;
	
  		if(tt!=0)
			{
				ttt=0;
				for(i=0;i<ngrid[nl];i++)
				{
					grid00[i]=1;
					for(k=0;k<chrqtl[nl];k++)
						if(fabs(grid[nl][i]-grid0[k])<=dqq[nl]) grid00[i]=0;
					ttt=ttt+grid00[i];
				}
// grid00 is the vector of indicators, indicating the putative locations that can be considered for the new locus based on the constraint dqq (minimum distance between flanking QTLs).
				if(ttt!=0)
				{
					r=RANDOM()*ttt;
					tt=0;
					for(i=0;i<ngrid[nl];i++)
					{
						if(r>=tt&&r<(tt+grid00[i])) qloc[trait][l]=i;
						tt=tt+grid00[i];
					}	
				}
				if(ttt==0) t=0;
			}

			for(k=0;k<chrqtl[nl];k++)
				if(fabs(grid[nl][qloc[trait][l]]-grid0[k])<=dqq[nl]) t=0;
		}
	}

	if(t!=0)
	{
		for(i=0;i<ns;i++)         
		{
			if(updategeno==1)
			{
				double prr[ng];
				for(k=0;k<ng;k++) prr[k]=qprob[nl][i][qloc[trait][l]][k];
				MULTINORMAL(prr);                                     
				geno[trait][i][l]=ibd;
				Coefficient(ibd);
			}
			if(updategeno==0) MT_Coefficient0(i,l,trait,qloc[trait][l]);
		
    	for(k=0;k<nc;k++) coef[trait][i][l][k]=x[k];
		}
	}

	return(t);
}

//***************************************************************
//Deleting QTL with all 0 effects
/*
void ZeroEffect()
{
	int l1,l2; 

    for(l1=0;l1<nqtl;l1++) gamma1[l1]=0;

    for(l1=0;l1<nqtl;l1++)
	{
		gamma1[l1]=gamma1[l1]+(gamma_main[l1]!=0);
    
	    if(epistasis==1)
		{
			for(l2=l1+1;l2<nqtl;l2++) gamma1[l1]=gamma1[l1]+(gamma_epistasis[l1][l2]!=0);   
			
			for(l2=0;l2<=l1-1;l2++) gamma1[l1]=gamma1[l1]+(gamma_epistasis[l2][l1]!=0);
		}

		if(gbye==1)
			for(l2=0;l2<nfixcova;l2++) 
				if(gbye_fix_index[l2]==1) gamma1[l1]=gamma1[l1]+(gamma_gbye[l2][l1]!=0);
	}

	return;
} */

void MT_ZeroEffect1(int l,int trait)
{
	int l0; 

	gamma1[trait][l]=(gamma_main[trait][l]!=0);

	if(epistasis==1)
	{
		for(l0=0;l0<=l-1;l0++) gamma1[trait][l]=gamma1[trait][l]+(gamma_epistasis[trait][l0][l]!=0);
		for(l0=l+1;l0<nqtl;l0++) gamma1[trait][l]=gamma1[trait][l]+(gamma_epistasis[trait][l][l0]!=0);   			
	}

	if(gbye==1)
	{
	for(l0=0;l0<nfixcova;l0++) 
	if(gbye_fix_index[l0]==1) gamma1[trait][l]=gamma1[trait][l]+(gamma_gbye[trait][l0][l]!=0.0);
	}

	return;
}

void MT_ZeroEffect2(int l1, int l2, int trait)
{
	int l0; 

	gamma1[trait][l1]=(gamma_main[trait][l1]!=0);
	gamma1[trait][l2]=(gamma_main[trait][l2]!=0);

	if(epistasis==1)
	{
		for(l0=0;l0<=l1-1;l0++) gamma1[trait][l1]=gamma1[trait][l1]+(gamma_epistasis[trait][l0][l1]!=0);
		for(l0=l1+1;l0<nqtl;l0++) gamma1[trait][l1]=gamma1[trait][l1]+(gamma_epistasis[trait][l1][l0]!=0);
		
		for(l0=0;l0<=l2-1;l0++) gamma1[trait][l2]=gamma1[trait][l2]+(gamma_epistasis[trait][l0][l2]!=0);
		for(l0=l2+1;l0<nqtl;l0++) gamma1[trait][l2]=gamma1[trait][l2]+(gamma_epistasis[trait][l2][l0]!=0); 
	}

	if(gbye==1)
	{
		for(l0=0;l0<nfixcova;l0++) 
			if(gbye_fix_index[l0]==1) 
			{
				gamma1[trait][l1]=gamma1[trait][l1]+(gamma_gbye[trait][l0][l1]!=0.0);
				gamma1[trait][l2]=gamma1[trait][l2]+(gamma_gbye[trait][l0][l2]!=0.0);
			}
	}

	return;
} 

//************************************************************************
//Update main effect for traditional multiple traits jointly for all phenotypes
/*
void MT_MainEffect_Traditional(int l, int k,FILE *file6)
{
	int i,j,k1,ph,ph1;
double **g,t2=0;
  double **sigma_beta_post,**tsigma1,**tsigma2,**chol;
  double *beta_ph,*beta_ph1,*newbeta;
 
         beta_ph = malloc(npheno1*sizeof(double));
         beta_ph1 = malloc(npheno1*sizeof(double));
         newbeta = malloc(npheno1*sizeof(double));
         g = malloc(npheno1*sizeof(double *));
         for (ph=0;ph<npheno1;ph++) g[ph] = malloc(ns*sizeof(double));

  tsigma1 = malloc(npheno1*sizeof(double *));
  tsigma2 = malloc(npheno1*sizeof(double *));
  chol = malloc(npheno1*sizeof(double *));
  sigma_beta_post = malloc(npheno1*sizeof(double *));
  for (ph=0;ph<npheno1;ph++)
  {   tsigma1[ph] = malloc(npheno1*sizeof(double));
      tsigma2[ph] = malloc(npheno1*sizeof(double));
      chol[ph] = malloc(npheno1*sizeof(double));
      sigma_beta_post[ph] = malloc(npheno1*sizeof(double));
   }
  for(ph=0;ph<npheno1;ph++) beta_ph1[ph]=0.0,beta_ph[ph]=0.0;

 if(multiple1==1)
  {  t2=0.0;
       for(i=0;i<ns;i++)
        { 
          double z=coef[i][l][k];
				  for(ph=0;ph<npheno1;ph++)
				  {
            g[ph][i]=gvalue[ph][i]-z*main1[ph][l][k];
             
	   		  	beta_ph1[ph]=beta_ph1[ph]+z*(y[ph][i]-amu[ph]-g[ph][i]);
		  		}
		  		t2=t2+z*z;
        }

   for(ph=0;ph<npheno1;ph++)
      for(ph1=0;ph1<npheno1;ph1++)
          {
           sigma_beta_post[ph][ph1]=sigma[ph][ph1]*t2;
      if(ph1==ph)  sigma_beta_post[ph][ph1] = sigma_beta_post[ph][ph1] + 1/vmain[ph][k];
          }

         
     INVERSE(sigma_beta_post,npheno1,tsigma1);
     XprimeY(tsigma1,sigma,npheno1,npheno1,npheno1,tsigma2);

       for(ph=0;ph<npheno1;ph++)
        for(ph1=0;ph1<npheno1;ph1++)
          beta_ph[ph] = beta_ph[ph]+tsigma2[ph][ph1]*beta_ph1[ph1]; 

  
  for(ph=0;ph<npheno1;ph++)     
   for(int k=0;k<npheno1;k++) chol[ph][k]=0;
      Cholesky(tsigma1,npheno1,chol);
      Multivariate_RNORM(chol,beta_ph,npheno1,newbeta);
      for(int trait=0;trait<npheno1;trait++) 
      {
        main1[trait][l][k]=newbeta[trait];
     		for(i=0;i<ns;i++) gvalue[trait][i]=g[trait][i]+coef[i][l][k]*main1[trait][l][k];
      }

  }
 for(ph=0;ph<npheno1;ph++)
  {
   free(g[ph]);
   free(tsigma1[ph]);
   free(tsigma2[ph]);
   free(chol[ph]);
   free(sigma_beta_post[ph]);
  }
   free(g);
   free(tsigma1);
   free(tsigma2);
   free(chol);
   free(sigma_beta_post);
   free(beta_ph);
   free(beta_ph1);
   free(newbeta);
	return;


} */

//************************************************************************
//Update main effect indicators

void MT_MainEffectIndicator_GROUP0(int l,int k,int trait)    
{
	int i,k1,ph,ph1;
	double **g,**g2,bf_10=0,gamma10,gamma_1=-(1e+100),gamma_0=-(1e+100);
  double t1=0,t2=0,t3=0,f1=0,f2=0;
  double **sigma_beta_post,**tsigma1,**tsigma2,**chol;
  double *beta_ph,*beta_ph1,*newbeta;
 
  beta_ph = malloc(npheno1*sizeof(double));
  beta_ph1 = malloc(npheno1*sizeof(double));
  newbeta = malloc(npheno1*sizeof(double));
  g2 = malloc(npheno1*sizeof(double *));
  g = malloc(npheno1*sizeof(double *));
  for (ph=0;ph<npheno1;ph++)
  {  
  g[ph] = malloc(ns*sizeof(double));
  g2[ph] = malloc(ns*sizeof(double));
   }

  tsigma1 = malloc(npheno1*sizeof(double *));
  tsigma2 = malloc(npheno1*sizeof(double *));
  chol = malloc(npheno1*sizeof(double *));
  sigma_beta_post = malloc(npheno1*sizeof(double *));
  for (ph=0;ph<npheno1;ph++)
  {   tsigma1[ph] = malloc(npheno1*sizeof(double));
      tsigma2[ph] = malloc(npheno1*sizeof(double));
      chol[ph] = malloc(npheno1*sizeof(double));
      sigma_beta_post[ph] = malloc(npheno1*sizeof(double));
   }
  for(ph=0;ph<npheno1;ph++) beta_ph1[ph]=0.0,beta_ph[ph]=0.0;


	if(multiple1==0)
	{
      	 for(i=0;i<ns;i++)                     
        	{
        		double z=coef[trait][i][l][k];
        		g[0][i]=gvalue[0][i]-z*main1[0][l][k];
        		t1=t1+z*(y[0][i]-amu[0]-g[0][i]);
        		t2=t2+z*z;
      	   }	 	
      	 t3=1/vmain[0][l][k]+t2/ve;	
	
        	for(i=0;i<ns;i++)                     
        	{
      		double z=coef[trait][i][l][k];
      		f1=f1+pow(y[0][i]-amu[0]-g[0][i],2)/ve;
      		f2=f2+pow(y[0][i]-amu[0]-g[0][i]-z*t1/(ve*t3),2)/ve;
        	}
	bf_10=-0.5*log(vmain[0][l][k])-0.5*pow(t1/(ve*t3),2)/vmain[0][l][k]-0.5*log(t3);
	bf_10=-0.5*f2+0.5*f1+bf_10;      
        	
  }
  if(multiple1==1)
  {  t2=0.0;
       for(i=0;i<ns;i++)
        { 
          double z=coef[trait][i][l][k];
				  for(ph=0;ph<npheno1;ph++)
				  {
            g[ph][i]=gvalue[ph][i]-z*main1[ph][l][k];
             
	   		  	beta_ph1[ph]=beta_ph1[ph]+z*(y[ph][i]-amu[ph]-g[ph][i]);
		  		}
		  		t2=t2+z*z;
        }

   for(ph=0;ph<npheno1;ph++)
      for(ph1=0;ph1<npheno1;ph1++)
          {
           sigma_beta_post[ph][ph1]=sigma[ph][ph1]*t2;
      if(ph1==ph)  sigma_beta_post[ph][ph1] = sigma_beta_post[ph][ph1] + 1/vmain[ph][l][k];
          }

         
     INVERSE(sigma_beta_post,npheno1,tsigma1);
     XprimeY(tsigma1,sigma,npheno1,npheno1,npheno1,tsigma2);
       for(ph=0;ph<npheno1;ph++)
        for(ph1=0;ph1<npheno1;ph1++)
          beta_ph[ph] = beta_ph[ph]+tsigma2[ph][ph1]*beta_ph1[ph1]; 

   f1 = LogLikelihood(y,g,amu,sigma);
      for(i=0;i<ns;i++)
       {
       double z=coef[trait][i][l][k]; 
        for(ph=0;ph<npheno1;ph++)
          g2[ph][i] = g[ph][i] + z*beta_ph[ph];
        }  
  f2 = LogLikelihood(y,g2,amu,sigma);      
 
  double tt;
  tt=Determinant(sigma_beta_post,npheno1); 

  for(ph=0;ph<npheno1;ph++) bf_10=bf_10-0.5*log(vmain[ph][l][k]);
  bf_10 = bf_10 - 0.5*log(tt);    
  for(ph=0;ph<npheno1;ph++) bf_10 = bf_10 - 0.5*beta_ph[ph]*beta_ph[ph]/vmain[ph][l][k];
	bf_10=bf_10+f2-f1;      
  }

  
	if(multiple1==2)
  {  t1=0,t2=0;

       for(i=0;i<ns;i++)
        { 
          double z=coef[trait][i][l][k];
				  for(ph=0;ph<npheno1;ph++)
				  {
            if(ph==trait) g[ph][i]=gvalue[ph][i]-z*main1[ph][l][k];
            else g[ph][i]=gvalue[ph][i];
             
	   		  	t1=t1+z*(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
  		    }
		  		  t2=t2+z*z;            								
          
        }

   f1 = LogLikelihood(y,g,amu,sigma);
   t3=t2*sigma[trait][trait] + 1.0/vmain[trait][l][k];
      for(i=0;i<ns;i++)
       {
        for(ph=0;ph<npheno1;ph++)
          {
        double z=coef[trait][i][l][k]; 
             if(ph==trait) g2[ph][i] = g[ph][i] + z*t1/t3;
             else g2[ph][i]=g[ph][i];
          }
        }  
  f2 = LogLikelihood(y,g2,amu,sigma);   
  bf_10 = -0.5*log(vmain[trait][l][k]) - 0.5*log(t3);  
  bf_10 = bf_10 - 0.5*pow(t1/t3,2)/vmain[trait][l][k];
	bf_10=bf_10+f2-f1;      
	
  }

	gamma10=log(w_main)-log(1-w_main);
	if(gibbs==1) gamma_1=bf_10+gamma10-log(1+exp(bf_10+gamma10));

	if(gibbs==0&&main1[trait][l][k]==0) gamma_1=bf_10;
	if(gibbs==0&&main1[trait][l][k]!=0) gamma_0=-bf_10;  
	      

	double r=log(RANDOM());
  if(multiple1==0)
  {
  	if(r<gamma_1) 
  	{
  		double u,u0;
  		ANORMAL(&u,&u0);
  		main1[0][l][k]=t1/(ve*t3)+u/sqrt(t3);
  		gamma_main[0][l]=1;
  		gamma1[0][l]=1;
  		for(i=0;i<ns;i++) gvalue[0][i]=g[0][i]+coef[0][i][l][k]*main1[0][l][k];
  	}
  	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
  	{
  		main1[0][l][k]=0;
  		double sum1=0;
  		for(k1=0;k1<nc;k1++) sum1=sum1+fabs(main1[0][l][k1]);
  		if(sum1==0) 
  		{
  			gamma_main[l]=0; 
  			MT_ZeroEffect1(l,0);
  		}
  		for(i=0;i<ns;i++) gvalue[0][i]=g[0][i];
  	}
  }
  if(multiple1==1)
  {
  	if(r<gamma_1) 
  	{
      Cholesky(tsigma1,npheno1,chol);
      Multivariate_RNORM(chol,beta_ph,npheno1,newbeta);
      for(ph=0;ph<npheno1;ph++) 
      {   
      main1[ph][l][k]=newbeta[ph];
 //     MT_MainEffect(l,ph,1,k);
  		for(i=0;i<ns;i++) gvalue[ph][i]=g[ph][i]+coef[ph][i][l][k]*main1[ph][l][k];
  		gamma_main[ph][l]=1;
  		gamma1[ph][l]=1;
       }
  	}
  	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
  	{
  		double sum1=0;
  	  for(ph=0;ph<npheno1;ph++)
      {
      main1[ph][l][k]=0;
  		for(k1=0;k1<nc;k1++) sum1=sum1+fabs(main1[ph][l][k1]);
  		}
  		if(sum1==0) 
  		{
      for(ph=0;ph<npheno1;ph++)  
       {
        gamma_main[ph][l]=0; 
  			MT_ZeroEffect1(l,ph);		
  			}
  		}
  	for(i=0;i<ns;i++) 
      for(ph=0;ph<npheno1;ph++)
            gvalue[ph][i]=g[ph][i];
          
  	}
  }
 if(multiple1==2)
  {
  	if(r<gamma_1) 
  	{
   		double u,u0;
  		ANORMAL(&u,&u0);
  		main1[trait][l][k]=t1/t3+u/sqrt(t3);
   	for(i=0;i<ns;i++) gvalue[trait][i]=g[trait][i]+coef[trait][i][l][k]*main1[trait][l][k];

  		gamma_main[trait][l]=1;
  		gamma1[trait][l]=1;     
  	}
  	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
  	{
  		double sum1=0;
      main1[trait][l][k]=0;
  		for(k1=0;k1<nc;k1++) sum1=sum1+fabs(main1[trait][l][k1]);
  		if(sum1==0) 
  		{
        gamma_main[trait][l]=0; 
  			MT_ZeroEffect1(l,trait);		
  		}
  	for(i=0;i<ns;i++) 
        gvalue[trait][i]=g[trait][i];
          
  	}
  }

  
 for(ph=0;ph<npheno1;ph++)
  {
   free(g[ph]);
   free(g2[ph]);
   free(tsigma1[ph]);
   free(tsigma2[ph]);
   free(chol[ph]);
   free(sigma_beta_post[ph]);
  }
   free(g);
   free(g2);
   free(tsigma1);
   free(tsigma2);
   free(chol);
   free(sigma_beta_post);
   free(beta_ph);
   free(beta_ph1);
   free(newbeta);
	return;
}

/*
void MT_MainEffectIndicator_GROUP1(int l)   
{	
	int i,k;
	double g[ns1],bf_10,gamma10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1[ng],t2[ng],t3[ng],f1=0,f2=0;


	for(i=0;i<ng;i++)
	{
		t1[i]=0, t2[i]=0, t3[i]=0;
	}

	for(i=0;i<ns;i++)
	{
		g[i]=gvalue[i];
		for(k=0;k<nc;k++) g[i]=g[i]-coef[i][l][k]*main1[l][k];
	}

	for(k=0;k<nc;k++)
	{
		for(i=0;i<ns;i++)                     
		{
			double z=coef[i][l][k];
			t1[k]=t1[k]+z*(y[i]-amu-g[i]);
			t2[k]=t2[k]+z*z;
		}	 	
		t3[k]=1/vmain[k]+t2[k]/ve;
	}	
	
	for(i=0;i<ns;i++)                     
	{
		f1=f1+pow(y[i]-amu-g[i],2)/ve;
		double f3=0;
		for(k=0;k<nc;k++) f3=f3+coef[i][l][k]*t1[k]/(ve*t3[k]);
		f2=f2+pow(y[i]-amu-g[i]-f3,2)/ve;
	}

	bf_10=0;
	for(k=0;k<nc;k++) bf_10=bf_10-0.5*log(vmain[k])-0.5*pow(t1[k]/(ve*t3[k]),2)/vmain[k]-0.5*log(t3[k]);
	bf_10=-0.5*f2+0.5*f1+bf_10;       
	
	gamma10=log(w_main)-log(1-w_main);
	if(gibbs==1) gamma_1=bf_10+gamma10-log(1+exp(bf_10+gamma10));
	if(gibbs==0&&gamma_main[l]==0) gamma_1=bf_10;
	if(gibbs==0&&gamma_main[l]!=0) gamma_0=-bf_10;  
	      
	double r=log(RANDOM());
	if(r<gamma_1) 
	{
		for(k=0;k<nc;k++) 
		{
			double u,u0;
			ANORMAL(&u,&u0);
			main1[l][k]=t1[k]/(ve*t3[k])+u/sqrt(t3[k]);
		}
		gamma_main[l]=1;
		gamma1[l]=1;
		for(i=0;i<ns;i++)
		{
			gvalue[i]=g[i];
			for(k=0;k<nc;k++) gvalue[i]=gvalue[i]+coef[i][l][k]*main1[l][k];
		}
	}
	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
	{
		for(k=0;k<nc;k++) main1[l][k]=0;
		gamma_main[l]=0;
		for(i=0;i<ns;i++) gvalue[i]=g[i];
		MT_ZeroEffect1(l);
	}

	return;
}
*/
//************************************************************************
//Update epistatic effect indicators


void MT_EpistasisIndicator_GROUP0(int l1,int l2,int k1,int k2,int trait)  
{
	int i,k01,k02,ph,ph1;
	double **g,**g2,bf_10=0.0,gamma10,gamma_1=-(1e+100),gamma_0=-(1e+100);
  double t1=0,t2=0,t3=0,f1=0,f2=0;
  double **sigma_beta_post,**tsigma1,**tsigma2,**chol;
  double *beta_ph,*beta_ph1,*newbeta;
 
  beta_ph = malloc(npheno1*sizeof(double));
  beta_ph1 = malloc(npheno1*sizeof(double));
  newbeta = malloc(npheno1*sizeof(double));
  g2 = malloc(npheno1*sizeof(double *));
  g = malloc(npheno1*sizeof(double *));
  for (ph=0;ph<npheno1;ph++)
  {  
		g[ph] = malloc(ns*sizeof(double));
		g2[ph] = malloc(ns*sizeof(double));
  }

  tsigma1 = malloc(npheno1*sizeof(double *));
  tsigma2 = malloc(npheno1*sizeof(double *));
  chol = malloc(npheno1*sizeof(double *));
  sigma_beta_post = malloc(npheno1*sizeof(double *));
  for (ph=0;ph<npheno1;ph++)
  {   
			tsigma1[ph] = malloc(npheno1*sizeof(double));
      tsigma2[ph] = malloc(npheno1*sizeof(double));
      chol[ph] = malloc(npheno1*sizeof(double));
      sigma_beta_post[ph] = malloc(npheno1*sizeof(double));
   }
  for(ph=0;ph<npheno1;ph++) beta_ph1[ph]=0.0,beta_ph[ph]=0.0;

	if(w_epistasis!=0)
	{
		if(multiple1==0)
		{	
			for(i=0;i<ns;i++)                     
			{
				double z=coef[0][i][l1][k1]*coef[0][i][l2][k2];
				g[0][i]=gvalue[0][i]-z*epistatic[0][l1][l2][k1][k2];
				t1=t1+z*(y[0][i]-amu[0]-g[0][i]);
				t2=t2+z*z;
			}	 	
			t3=1/vepistasis[0][l1][l2][k1][k2]+t2/ve;	
			
			for(i=0;i<ns;i++)                     
			{
				double z=coef[0][i][l1][k1]*coef[0][i][l2][k2];
				f1=f1+pow(y[0][i]-amu[0]-g[0][i],2)/ve;
				f2=f2+pow(y[0][i]-amu[0]-g[0][i]-z*t1/(ve*t3),2)/ve;
			}

			bf_10=-0.5*log(vepistasis[0][l1][l2][k1][k2])-0.5*pow(t1/(ve*t3),2)/vepistasis[0][l1][l2][k1][k2]-0.5*log(t3);
			bf_10=-0.5*f2+0.5*f1+bf_10;      
		}

		if(multiple1==1)
		{  t2=0.0;
				 for(i=0;i<ns;i++)
					{ 
						double z=coef[trait][i][l1][k1]*coef[trait][i][l2][k2];
						for(ph=0;ph<npheno1;ph++)
						{
							g[ph][i]=gvalue[ph][i]-z*epistatic[ph][l1][l2][k1][k2];
							beta_ph1[ph]=beta_ph1[ph]+z*(y[ph][i]-amu[ph]-g[ph][i]);
						}
						t2=t2+z*z;
					}

			for(ph=0;ph<npheno1;ph++)
				for(ph1=0;ph1<npheno1;ph1++)
				{
					sigma_beta_post[ph][ph1]=sigma[ph][ph1]*t2;
					if(ph1==ph)  
						sigma_beta_post[ph][ph1] = sigma_beta_post[ph][ph1] + 1.0/vepistasis[ph][l1][l2][k1][k2];
				}

					 
			 INVERSE(sigma_beta_post,npheno1,tsigma1);
			 XprimeY(tsigma1,sigma,npheno1,npheno1,npheno1,tsigma2);
				 for(ph=0;ph<npheno1;ph++)
					for(ph1=0;ph1<npheno1;ph1++)
						beta_ph[ph] = beta_ph[ph]+tsigma2[ph][ph1]*beta_ph1[ph1]; 

		 f1 = LogLikelihood(y,g,amu,sigma);
				for(i=0;i<ns;i++)
				 {
					double z=coef[trait][i][l1][k1]*coef[trait][i][l2][k2];
					for(ph=0;ph<npheno1;ph++)
						g2[ph][i] = g[ph][i] + z*beta_ph[ph];
					}  
		f2 = LogLikelihood(y,g2,amu,sigma);      
	 
		double tt;
		tt=Determinant(sigma_beta_post,npheno1); 

		for(ph=0;ph<npheno1;ph++) bf_10=bf_10-0.5*log(vepistasis[ph][l1][l2][k1][k2]);
		bf_10 = bf_10 - 0.5*log(tt);    
		for(ph=0;ph<npheno1;ph++) 
		bf_10 = bf_10 - 0.5*beta_ph[ph]*beta_ph[ph]/vepistasis[ph][l1][l2][k1][k2];
		
		bf_10=bf_10+f2-f1;      
		}

		if(multiple1==2)
		{  t1=0,t2=0;
					 for(i=0;i<ns;i++)
						{
							double z=coef[trait][i][l1][k1]*coef[trait][i][l2][k2];
							for(ph=0;ph<npheno1;ph++)
							{
								if(ph==trait) g[ph][i]=gvalue[ph][i]-z*epistatic[ph][l1][l2][k1][k2];
								else g[ph][i]=gvalue[ph][i];

								t1=t1+z*(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
							}
								t2=t2+z*z;

						}

			 f1 = LogLikelihood(y,g,amu,sigma);
			 t3=t2*sigma[trait][trait] + 1.0/vepistasis[trait][l1][l2][k1][k2];

					for(i=0;i<ns;i++)
					 {
						for(ph=0;ph<npheno1;ph++)
							{
								double z=coef[trait][i][l1][k1]*coef[trait][i][l2][k2];
								 if(ph==trait) g2[ph][i] = g[ph][i] + z*t1/t3;
								 else g2[ph][i]=g[ph][i];
							}
						}
			f2 = LogLikelihood(y,g2,amu,sigma);
			bf_10 = -0.5*log(vepistasis[trait][l1][l2][k1][k2]) - 0.5*log(t3);
			bf_10 = bf_10 - 0.5*pow(t1/t3,2)/vepistasis[trait][l1][l2][k1][k2];
			bf_10=bf_10+f2-f1;

		}

		gamma10=log(w_epistasis)-log(1-w_epistasis);
		if(gibbs==1) gamma_1=bf_10+gamma10-log(1+exp(bf_10+gamma10));
		if(gibbs==0 && epistatic[trait][l1][l2][k1][k2]==0) gamma_1=bf_10;
		if(gibbs==0 && epistatic[trait][l1][l2][k1][k2]!=0) gamma_0=-bf_10;

		double r=log(RANDOM());

   if(multiple1==0)
   {
    	if(r<gamma_1) 
    	{
    		double u,u0;
    		ANORMAL(&u,&u0);
    		epistatic[0][l1][l2][k1][k2]=t1/(ve*t3)+u/sqrt(t3);
    		gamma_epistasis[0][l1][l2]=1;
    		gamma1[0][l1]=1,gamma1[0][l2]=1;
    		for(i=0;i<ns;i++) 
        gvalue[0][i]=g[0][i]+coef[0][i][l1][k1]*coef[0][i][l2][k2]*epistatic[0][l1][l2][k1][k2];
    	}
    	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
    	{
    		epistatic[0][l1][l2][k1][k2]=0;
    		double sum1=0;
    		for(k01=0;k01<nc;k01++) 
    			for(k02=0;k02<nc;k02++) sum1=sum1+fabs(epistatic[0][l1][l2][k01][k02]);
    		if(sum1==0) 
    		{
    			gamma_epistasis[0][l1][l2]=0;  
    			MT_ZeroEffect2(l1,l2,0);
    		}
    		for(i=0;i<ns;i++) gvalue[0][i]=g[0][i];
    	}
    }

  if(multiple1==1)
  {
  	if(r<gamma_1) 
  	{
      Cholesky(tsigma1,npheno1,chol);
      Multivariate_RNORM(chol,beta_ph,npheno1,newbeta);
      for(ph=0;ph<npheno1;ph++) 
      {   
				epistatic[ph][l1][l2][k1][k2]=newbeta[ph];
				for(i=0;i<ns;i++) 
					gvalue[ph][i]=g[ph][i]+coef[ph][i][l1][k1]*coef[ph][i][l2][k2]*epistatic[ph][l1][l2][k1][k2];

				gamma_epistasis[ph][l1][l2]=1;
				gamma1[ph][l1]=1,gamma1[ph][l2]=1;
       }
  	}
  	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
  	{
  		double sum1=0;
  	  for(ph=0;ph<npheno1;ph++)
      {
				epistatic[ph][l1][l2][k1][k2]=0;
				for(k01=0;k01<nc;k01++) 
					for(k02=0;k02<nc;k02++) sum1=sum1+fabs(epistatic[ph][l1][l2][k01][k02]);
  		}
  		if(sum1==0) 
  		{
      for(ph=0;ph<npheno1;ph++)  
       {
    			gamma_epistasis[ph][l1][l2]=0;  
    			MT_ZeroEffect2(l1,l2,ph);
  			}
  		}
			for(i=0;i<ns;i++) 
				for(ph=0;ph<npheno1;ph++)
							gvalue[ph][i]=g[ph][i];
          
  	}
  }

 if(multiple1==2)
  {
  	if(r<gamma_1)
  	{
   		double u,u0;
  		ANORMAL(&u,&u0);
   		epistatic[trait][l1][l2][k1][k2]=t1/t3+u/sqrt(t3);
			for(i=0;i<ns;i++) 
			 gvalue[trait][i]=g[trait][i]+coef[trait][i][l1][k1]*coef[trait][i][l2][k2]*epistatic[trait][l1][l2][k1][k2];

  		gamma_epistasis[trait][l1][l2]=1;
   		gamma1[trait][l1]=1,gamma1[trait][l2]=1;
		
  	}
  	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
  	{
  		epistatic[trait][l1][l2][k1][k2]=0;
   		double sum1=0;
    		for(k01=0;k01<nc;k01++) 
    			for(k02=0;k02<nc;k02++) sum1=sum1+fabs(epistatic[trait][l1][l2][k01][k02]);
  		if(sum1==0)
  		{
    			gamma_epistasis[trait][l1][l2]=0;  
    			MT_ZeroEffect2(l1,l2,trait);
  		}
			for(i=0;i<ns;i++)
					gvalue[trait][i]=g[trait][i];

  	}
  }
    
    
	}  //end of w_epistasis != 0
 /*
	if(w_epistasis==0&&epistatic[trait][l1][l2][k1][k2]!=0)
	{
		for(i=0;i<ns;i++) 
    gvalue[trait][i]=gvalue[trait][i]-coef[trait][i][l1][k1]*coef[trait][i][l2][k2]*epistatic[trait][l1][l2][k1][k2];
		epistatic[trait][l1][l2][k1][k2]=0;
		double sum1=0;
		for(k01=0;k01<nc;k01++) 
			for(k02=0;k02<nc;k02++) sum1=sum1+fabs(epistatic[trait][l1][l2][k01][k02]);
		if(sum1==0) 
		{
			gamma_epistasis[trait][l1][l2]=0;  
			MT_ZeroEffect2(l1,l2,trait);
		}
	}*/

 for(ph=0;ph<npheno1;ph++)
  {
   free(g[ph]);
   free(g2[ph]);
   free(tsigma1[ph]);
   free(tsigma2[ph]);
   free(chol[ph]);
   free(sigma_beta_post[ph]);
  }
   free(g);
   free(g2);
   free(tsigma1);
   free(tsigma2);
   free(chol);
   free(sigma_beta_post);
   free(beta_ph);
   free(beta_ph1);
   free(newbeta);
	return;	
}

/*
void MT_EpistasisIndicator_GROUP1(int l1,int l2)    
{
	int i,k1,k2;
	double g[ns1],bf_10,gamma10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1[ng][ng],t2[ng][ng],t3[ng][ng],f1=0,f2=0;

	if(w_epistasis!=0)
	{

	for(k1=0;k1<ng;k1++)
	   for(k2=0;k2<ng;k2++)
	   {
           t1[k1][k2]=0, t2[k1][k2]=0, t3[k1][k2]=0;
	   }

	for(i=0;i<ns;i++)
	{
		g[i]=gvalue[i];
		for(k1=0;k1<nc;k1++) 
			for(k2=0;k2<nc;k2++) g[i]=g[i]-coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
	}

	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++)
		{
			for(i=0;i<ns;i++)                     
			{
				double z=coef[i][l1][k1]*coef[i][l2][k2];
				t1[k1][k2]=t1[k1][k2]+z*(y[i]-amu-g[i]);
				t2[k1][k2]=t2[k1][k2]+z*z;
			}	 	
			t3[k1][k2]=1/vepistasis[k1][k2]+t2[k1][k2]/ve;
		}	
	
	for(i=0;i<ns;i++)                     
	{
		f1=f1+pow(y[i]-amu-g[i],2)/ve;
		double f3=0;
		for(k1=0;k1<nc;k1++) 
			for(k2=0;k2<nc;k2++) f3=f3+coef[i][l1][k1]*coef[i][l2][k2]*t1[k1][k2]/(ve*t3[k1][k2]);
		f2=f2+pow(y[i]-amu-g[i]-f3,2)/ve;
	}

	bf_10=0;
	for(k1=0;k1<nc;k1++) 
		for(k2=0;k2<nc;k2++) 
			bf_10=bf_10-0.5*log(vepistasis[k1][k2])-0.5*pow(t1[k1][k2]/(ve*t3[k1][k2]),2)/vepistasis[k1][k2]-0.5*log(t3[k1][k2]);
	bf_10=-0.5*f2+0.5*f1+bf_10;      

	gamma10=log(w_epistasis)-log(1-w_epistasis);
	if(gibbs==1) gamma_1=bf_10+gamma10-log(1+exp(bf_10+gamma10));
	if(gibbs==0&&gamma_epistasis[l1][l2]==0) gamma_1=bf_10;
	if(gibbs==0&&gamma_epistasis[l1][l2]!=0) gamma_0=-bf_10;
	      
	double r=log(RANDOM());
	if(r<gamma_1) 
	{
		for(k1=0;k1<nc;k1++) 
			for(k2=0;k2<nc;k2++)  
			{
				double u,u0;
				ANORMAL(&u,&u0);
				epistatic[l1][l2][k1][k2]=t1[k1][k2]/(ve*t3[k1][k2])+u/sqrt(t3[k1][k2]);
			}
		gamma_epistasis[l1][l2]=1;
		gamma1[l1]=1,gamma1[l2]=1;
		for(i=0;i<ns;i++)
		{
			gvalue[i]=g[i];
			for(k1=0;k1<nc;k1++) 
				for(k2=0;k2<nc;k2++) gvalue[i]=gvalue[i]+coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
		}
	}
	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
	{
		for(k1=0;k1<nc;k1++) 
			for(k2=0;k2<nc;k2++) epistatic[l1][l2][k1][k2]=0;
		gamma_epistasis[l1][l2]=0;
		for(i=0;i<ns;i++) gvalue[i]=g[i];
		MT_ZeroEffect2(l1,l2);
	}

	}

	if(w_epistasis==0&&gamma_epistasis[l1][l2]!=0)
	{
		for(i=0;i<ns;i++)
			for(k1=0;k1<nc;k1++) 
				for(k2=0;k2<nc;k2++) gvalue[i]=gvalue[i]-coef[i][l1][k1]*coef[i][l2][k2]*epistatic[l1][l2][k1][k2];
		for(k1=0;k1<nc;k1++) 
			for(k2=0;k2<nc;k2++) epistatic[l1][l2][k1][k2]=0;
		gamma_epistasis[l1][l2]=0;
		MT_ZeroEffect2(l1,l2);
	}

	return;	
}

*/
//************************************************************************
//Update g by e fixed effect indicators


void MT_GBYE_FIX_Indicator_GROUP0(int l1,int l2,int k,int trait)  //use the constraint model
{
	int i,k1,ph,ph1;
	double **g,**g2,bf_10=0.0,gamma10,gamma_1=-(1e+100),gamma_0=-(1e+100);

  double t1=0,t2=0,t3=0,f1=0,f2=0;
  double **sigma_beta_post,**tsigma1,**tsigma2,**chol;
  double *beta_ph,*beta_ph1,*newbeta;
 
  beta_ph = malloc(npheno1*sizeof(double));
  beta_ph1 = malloc(npheno1*sizeof(double));
  newbeta = malloc(npheno1*sizeof(double));
  g2 = malloc(npheno1*sizeof(double *));
  g = malloc(npheno1*sizeof(double *));
  for (ph=0;ph<npheno1;ph++)
  {  
		g[ph] = malloc(ns*sizeof(double));
		g2[ph] = malloc(ns*sizeof(double));
  }

  tsigma1 = malloc(npheno1*sizeof(double *));
  tsigma2 = malloc(npheno1*sizeof(double *));
  chol = malloc(npheno1*sizeof(double *));
  sigma_beta_post = malloc(npheno1*sizeof(double *));
  for (ph=0;ph<npheno1;ph++)
  {   tsigma1[ph] = malloc(npheno1*sizeof(double));
      tsigma2[ph] = malloc(npheno1*sizeof(double));
      chol[ph] = malloc(npheno1*sizeof(double));
      sigma_beta_post[ph] = malloc(npheno1*sizeof(double));
   }
  for(ph=0;ph<npheno1;ph++) beta_ph1[ph]=0.0,beta_ph[ph]=0.0;

  if(multiple1==1)
  {  t2=0.0;
       for(i=0;i<ns;i++)
        { 
      		double z=coef_fix[i][l1]*coef[trait][i][l2][k];
				  for(ph=0;ph<npheno1;ph++)
				  {
            g[ph][i]=gvalue[ph][i]-z*gbye_fix[ph][l1][l2][k];
             
	   		  	beta_ph1[ph]=beta_ph1[ph]+z*(y[ph][i]-amu[ph]-g[ph][i]);
		  		}
		  		t2=t2+z*z;
        }

   for(ph=0;ph<npheno1;ph++)
      for(ph1=0;ph1<npheno1;ph1++)
      {
          sigma_beta_post[ph][ph1]=sigma[ph][ph1]*t2;
					if(ph1==ph)  
					sigma_beta_post[ph][ph1] = sigma_beta_post[ph][ph1] + 1.0/v_gbye_fix[ph][l1][l2][k];
      }

         
     INVERSE(sigma_beta_post,npheno1,tsigma1);
     XprimeY(tsigma1,sigma,npheno1,npheno1,npheno1,tsigma2);
       for(ph=0;ph<npheno1;ph++)
        for(ph1=0;ph1<npheno1;ph1++)
          beta_ph[ph] = beta_ph[ph]+tsigma2[ph][ph1]*beta_ph1[ph1]; 

   f1 = LogLikelihood(y,g,amu,sigma);
      for(i=0;i<ns;i++)
       {
    		double z=coef_fix[i][l1]*coef[trait][i][l2][k];
        for(ph=0;ph<npheno1;ph++)
          g2[ph][i] = g[ph][i] + z*beta_ph[ph];
        }  
  f2 = LogLikelihood(y,g2,amu,sigma);      
 
  double tt;
  tt=Determinant(sigma_beta_post,npheno1); 

  for(ph=0;ph<npheno1;ph++) bf_10=bf_10-0.5*log(v_gbye_fix[ph][l1][l2][k]);
  bf_10 = bf_10 - 0.5*log(tt);    
  for(ph=0;ph<npheno1;ph++) 
  bf_10 = bf_10 - 0.5*beta_ph[ph]*beta_ph[ph]/v_gbye_fix[ph][l1][l2][k];
	
  bf_10=bf_10+f2-f1;      
  }


	if(multiple1==2)
	{   
  t1=0,t2=0;
	for(i=0;i<ns;i++)                     
	{
		double z=coef_fix[i][l1]*coef[trait][i][l2][k];
	  for(ph=0;ph<npheno1;ph++)
		  {
       if(ph==trait) g[ph][i]=gvalue[ph][i]-z*gbye_fix[ph][l1][l2][k];
       else g[ph][i]=gvalue[ph][i];
	  	t1=t1+z*(y[ph][i]-amu[ph]-g[ph][i])*sigma[trait][ph];
	    }
 		  t2=t2+z*z;            								
	}	 	

  f1 = LogLikelihood(y,g,amu,sigma);
  t3=t2*sigma[trait][trait] + 1.0/v_gbye_fix[trait][l1][l2][k];
	
  for(i=0;i<ns;i++)
    {
    for(ph=0;ph<npheno1;ph++)
      {
  		double z=coef_fix[i][l1]*coef[trait][i][l2][k];
       if(ph==trait) g2[ph][i] = g[ph][i] + z*t1/t3;
       else g2[ph][i]=g[ph][i];
       }
    }  
  f2 = LogLikelihood(y,g2,amu,sigma);   

  bf_10 = -0.5*log(v_gbye_fix[trait][l1][l2][k]) - 0.5*log(t3);  
  bf_10 = bf_10 - 0.5*pow(t1/t3,2)/v_gbye_fix[trait][l1][l2][k];
	bf_10=bf_10+f2-f1;      
 }
 
	gamma10=log(w_gbye)-log(1-w_gbye);
	if(gibbs==1) gamma_1=bf_10+gamma10-log(1+exp(bf_10+gamma10));
	if(gibbs==0&&gbye_fix[trait][l1][l2][k]==0) gamma_1=bf_10;
	if(gibbs==0&&gbye_fix[trait][l1][l2][k]!=0) gamma_0=-bf_10;

	double r=log(RANDOM());
  if(multiple1==1)
  {
  	if(r<gamma_1) 
  	{
      Cholesky(tsigma1,npheno1,chol);
      Multivariate_RNORM(chol,beta_ph,npheno1,newbeta);
      for(ph=0;ph<npheno1;ph++) 
      {   
      gbye_fix[ph][l1][l2][k]=newbeta[ph];

  		for(i=0;i<ns;i++) 
      gvalue[ph][i]=g[ph][i]+coef_fix[i][l1]*coef[ph][i][l2][k]*gbye_fix[ph][l1][l2][k];

  		gamma_gbye[ph][l1][l2]=1;
  		gamma1[ph][l2]=1;
       }
  	}
  	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
  	{
  		double sum1=0;
  	  for(ph=0;ph<npheno1;ph++)
      {
  		gbye_fix[ph][l1][l2][k]=0;
  		for(k1=0;k1<nc;k1++) sum1=sum1+fabs(gbye_fix[ph][l1][l2][k]);
  		}
  		if(sum1==0) 
  		{
      for(ph=0;ph<npheno1;ph++)  
       {
        gamma_gbye[ph][l1][l2]=0; 
  			MT_ZeroEffect1(l2,ph);		
  			}
  		}
  	for(i=0;i<ns;i++) 
      for(ph=0;ph<npheno1;ph++)
            gvalue[ph][i]=g[ph][i];
          
  	}
  }
  if(multiple1==2)
	{
  	if(r<gamma_1) 
  	{
  		double u,u0;
  		ANORMAL(&u,&u0);
   		gbye_fix[trait][l1][l2][k]=t1/t3+u/sqrt(t3);		
  		gamma_gbye[trait][l1][l2]=1;
  		gamma1[trait][l2]=1;
  
  		for(i=0;i<ns;i++) 
  gvalue[trait][i]=g[trait][i]+coef_fix[i][l1]*coef[trait][i][l2][k]*gbye_fix[trait][l1][l2][k];
  	}
  	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
  	{
  		gbye_fix[trait][l1][l2][k]=0;
  		double sum1=0;
  		for(k1=0;k1<nc;k1++) sum1=sum1+fabs(gbye_fix[trait][l1][l2][k1]);
  		if(sum1==0) 
  		{
  			gamma_gbye[trait][l1][l2]=0;  
  			MT_ZeroEffect1(l2,trait);
  		}
  		for(i=0;i<ns;i++) gvalue[trait][i]=g[trait][i];
  	}
  }

 for(ph=0;ph<npheno1;ph++)
  {
   free(g[ph]);
   free(g2[ph]);
   free(tsigma1[ph]);
   free(tsigma2[ph]);
   free(chol[ph]);
   free(sigma_beta_post[ph]);
  }
   free(g);
   free(g2);
   free(tsigma1);
   free(tsigma2);
   free(chol);
   free(sigma_beta_post);
   free(beta_ph);
   free(beta_ph1);
   free(newbeta);

	return;	
}
/*
void MT_GBYE_FIX_Indicator_GROUP1(int l1,int l2)  
{
	int i,k;
	double g[ns1],bf_10,gamma10,gamma_1=-(1e+100),gamma_0=-(1e+100),t1[ng],t2[ng],t3[ng],f1=0,f2=0;

	for(i=0;i<ng;i++)
	{
		t1[i]=0, t2[i]=0, t3[i]=0;
	}

	for(i=0;i<ns;i++)
	{
		g[i]=gvalue[i];
		for(k=0;k<nc;k++) 
			g[i]=g[i]-coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];
	}

	for(k=0;k<nc;k++)
	{
		for(i=0;i<ns;i++)                     
		{
			double z=coef_fix[i][l1]*coef[i][l2][k];
			t1[k]=t1[k]+z*(y[i]-amu-g[i]);
			t2[k]=t2[k]+z*z;
		}	 	
		t3[k]=1/v_gbye_fix[l1][k]+t2[k]/ve;
	}
	
	for(i=0;i<ns;i++)                     
	{
		f1=f1+pow(y[i]-amu-g[i],2)/ve;
		double f3=0;
        for(k=0;k<nc;k++) f3=f3+coef_fix[i][l1]*coef[i][l2][k]*t1[k]/(ve*t3[k]);
		f2=f2+pow(y[i]-amu-g[i]-f3,2)/ve;
	}

	bf_10=0;
	for(k=0;k<nc;k++) bf_10=bf_10-0.5*log(v_gbye_fix[l1][k])-0.5*pow(t1[k]/(ve*t3[k]),2)/v_gbye_fix[l1][k]-0.5*log(t3[k]);
	bf_10=-0.5*f2+0.5*f1+bf_10;      

	gamma10=log(w_gbye)-log(1-w_gbye);
	if(gibbs==1) gamma_1=bf_10+gamma10-log(1+exp(bf_10+gamma10));
	if(gibbs==0&&gamma_gbye[l1][l2]==0) gamma_1=bf_10;
	if(gibbs==0&&gamma_gbye[l1][l2]!=0) gamma_0=-bf_10;

	double r=log(RANDOM());
	if(r<gamma_1) 
	{
		for(k=0;k<nc;k++)
		{
			double u,u0;
			ANORMAL(&u,&u0);
			gbye_fix[l1][l2][k]=t1[k]/(ve*t3[k])+u/sqrt(t3[k]);
		}
		gamma_gbye[l1][l2]=1;
		gamma1[l2]=1;
		for(i=0;i<ns;i++) 
		{
			gvalue[i]=g[i];
			for(k=0;k<nc;k++) gvalue[i]=gvalue[i]+coef_fix[i][l1]*coef[i][l2][k]*gbye_fix[l1][l2][k];
		}
	}
	if( (r>=gamma_1&&gibbs==1) || r<gamma_0 )
	{
		for(k=0;k<nc;k++) gbye_fix[l1][l2][k]=0;
		gamma_gbye[l1][l2]=0;  
		for(i=0;i<ns;i++) gvalue[i]=g[i];
		MT_ZeroEffect1(l2);
	}

	return;	
}
*/  
//*******************************************************************************    


// ************************************************************

void multipleTraitsMCMC()
{

	int i,j,l,k,k1,k2,l0,l1,l2,ph;     
	double **ybar,**sigma;
	  
	if(seed1==0)	srand(time(NULL));
	else srand(seed1);
	rand();    
  
	//*************************************************************************
  // calculating phenotypic mean and variance, and assign initial values
	
	double y_bar[npheno1],y2_bar[npheno1],vp[npheno1];
  
	sigma=malloc(npheno1*sizeof(double *));
	for(i=0;i<npheno1;i++) sigma[i] = malloc(npheno1*sizeof(double));
  
	if(category==1)
	{
	for(ph=0;ph<npheno1;ph++)
	{
		y_bar[ph]=0.0,y2_bar[ph]=0.0;
		for(i=0;i<ns;i++)
  	{
			y_bar[ph]=y_bar[ph]+y[ph][i];
  		y2_bar[ph]=y2_bar[ph]+y[ph][i]*y[ph][i];
		}
		y_bar[ph]=y_bar[ph]/ns;
  	amu[ph]=y_bar[ph];
		vp[ph]=(1.0/(ns-1))*(y2_bar[ph]-ns*pow(y_bar[ph],2));
	}	 
    ve=vp[0];  //Initializing Residual Variance
	
	if(sph==1)
		for(ph=0;ph<npheno1;ph++)
	  		for(i=0;i<ns;i++) y[ph][i]=(y[ph][i]-y_bar[ph])/sqrt(vp[ph]); //standardizing the phenotype
	
	if(multiple1>=1)
  {
	  ybar=malloc(npheno1*sizeof(double *));
    for(i=0;i<npheno1;i++) ybar[i] = malloc(ns1*sizeof(double));
	  
	 for(i=0;i<npheno1;i++) amu[i]=0;
    for(j=0;j<npheno1;j++)
	    for(i=0;i<ns;i++)
	        amu[j]=amu[j]+ y[j][i]/ns;
  
	          for(j=0;j<npheno1;j++) y_bar[j]=amu[j];
	  
	  for(j=0;j<npheno1;j++) 
	    for(i=0;i<ns;i++) ybar[j][i] = (y[j][i] - amu[j])/sqrt(ns-1);
	            
	   XprimeX(ybar,npheno1,ns,sigma);
     INVERSE(sigma,npheno1,sigma);
	
    }
	
	
  /*	amu=y_bar, ve=vp;            //initial values for amu and ve
		for(i=0;i<nrancova;i++) vran[i]=vp;  //initial values for vran[i]
		*/
  	
	/*  for(i=0;i<npheno1;i++)
	  {
	  for(j=0;j<npheno1;j++) vp[j]=sigma[i][j];
	  MT_Mean(y_bar,vp,i,fp);
	  }*/
	 
   
	}
  
	
	/*
  if(category!=1)
	{
		amu=0, ve=1.0;                        //initial values for amu and ve
  	for(i=0;i<nrancova;i++) vran[i]=1.0;  //initial values for vran[i]
	}
	*/
	//******************************************************************************
	//For specify the prior variances of QTL effects and g by e interactions
	
	double cc[ng];
  if(cross==2)
	{
  	cc[0]=1.0/2, cc[1]=1.0/4;
	}
	else cc[0]=1.0/4;
  for(k=0;k<nc;k++)
	 for(ph=0;ph<npheno1;ph++) 
	  for(l=0;l<nqtl;l++)
      vmain[ph][l][k]=1.0/cc[k];
	
	for(ph=0;ph<npheno1;ph++)
	{	
	 		for(l1=0;l1<nqtl-1;l1++)
				for(l2=l1+1;l2<nqtl;l2++)
	        for(k1=0;k1<nc;k1++)
        		for(k2=0;k2<nc;k2++) 
	          vepistasis[ph][l1][l2][k1][k2]=1.0/(cc[k1]*cc[k2]);
  	}
	
	
  double v_fix[20];   // 20 = the maximum number of fixed effects
	for(l=0;l<nfixcova;l++)
		if(gbye_fix_index[l]==1)
  	{
			double y_bar1=0.0,y_bar2=0.0;
			for(i=0;i<ns;i++) 
			{
				y_bar1=y_bar1+coef_fix[i][l];
				y_bar2=y_bar2+pow(coef_fix[i][l],2);
			}
  		y_bar1=y_bar1/ns;
			v_fix[l]=(1.0/(ns-1))*(y_bar2-ns*pow(y_bar1,2));
  	}
	
	  for(ph=0;ph<npheno1;ph++)
   		for(l1=0;l1<nfixcova;l1++)
				for(l2=0;l2<nqtl;l2++)
	  			for(k=0;k<nc;k++) v_gbye_fix[ph][l1][l2][k]=1.0/(v_fix[l1]*cc[k]);
  
	//******************************************************************************
	//Give initial threshold values for ordinal traits
	/*
	if(category==2)
	{
		cutpoint[0]=-1e+10,cutpoint[1]=0,cutpoint[2]=1e+10;
  }
	
  if(category==3)
	{
		cutpoint[0]=-1e+10, cutpoint[1]=0;
  	for(j=2;j<cn-1;j++) cutpoint[j]=(j-1)*1.0/(cn-2);
		cutpoint[cn-1]=1, cutpoint[cn]=1e+10;
	}
  */
	//******************************************************************************
	FILE *file1; 
	file1=fopen(iterfile,"w");
	
	FILE *file2;
	file2=fopen(covfile,"w"); 
  
	FILE *file3;
  file3=fopen(mainfile,"w");
	
	FILE *file4;
  file4=fopen(pairfile,"w");
	
	FILE *file5;
  file5=fopen(gbyefile,"w");
	
	FILE *file6;
	file6=fopen(devfile,"w");
	
	FILE *file7;
	file7=fopen(sigmafile,"w");
  
	
  // ***********************************************************                         
	// ITERATION STARTS HERE
	
  int iter,iter1;
	for(iter=0;iter<niter+(int)(1.0*nburnin/nthin);iter++)
	{ 
  for(iter1=0;iter1<nthin;iter1++)
	{
	
	//***********************************************************
	//UPDATING THE VALUES OF THE LIABILITY
	
	/// @warning: Review if this needs to be commented out. Also, call to TrunNormal doesnt have sufficient arguments
  //if(category!=1) 
		//for(i=0;i<ns;i++) y[0][i]=TrunNormal(w[i],amu[0]+gvalue[0][i],ve);      
  
	//********************************************************************************* 
	//UPDATE PARAMETERS
   
	for(ph=0;ph<npheno1;ph++)  MT_Mean(y_bar[ph],vp[ph],ph);
	
  
	//if(category!=2 && multiple1==0) ResidualVariance();
	
	if(category==1 && multiple1>=1) ResidualVariance_MultipleTraits();
	
	int nu=6; double h=0.1,tau;//,s=2; //nu=degrees of freedom, h=heritability, tau=scale
	
  for(l=0;l<nqtl;l++)
	    for(ph=0;ph<npheno1;ph++)    
  	      if(gamma_main[ph][l]!=0.0)
	        {
	         MT_MainEffect(l,ph,0,0); // 0 0 not used here	
      			for(k=0;k<nc;k++)
	    				if(main1[ph][l][k]!=0)
	       			{
      					tau=(nu-2)*h*vp[ph]/(nu*cc[k]);	
	    					MT_MainVariance(l,k,nu,tau,ph);
	    	   		}		
	         }
	
		
	  /*  for(l=0;l<nqtl;l++)
  	      if(gamma_main[l]!=0.0) 
	          for(k=0;k<nc;k++)    
              if(MAINTRUE==0) MT_MainEffect_Traditional(l,k); 
	*/	
	
  /*if(epistasis==1)
	{  for(ph=0;ph<npheno1;ph++)
	  	for(l1=0;l1<nqtl-1;l1++)
  	   	for(l2=l1+1;l2<nqtl;l2++)
			   	if(gamma_epistasis[ph][l1][l2]!=0)
				           MT_EpistaticEffect(l1,l2,ph);	
	} */
	
		if(epistasis==1)
		{
     for(ph=0;ph<npheno1;ph++)
	 		for(l1=0;l1<nqtl-1;l1++)
  			for(l2=l1+1;l2<nqtl;l2++)
					if(gamma_epistasis[ph][l1][l2]!=0.0) 
						{
             MT_EpistaticEffect(l1,l2,ph);	
	              for(k1=0;k1<nc;k1++)
	    						for(k2=0;k2<nc;k2++) 
      							if(epistatic[ph][l1][l2][k1][k2]!=0.0)
	    							{
	    								tau=(nu-2)*h*vp[ph]/(nu*cc[k1]*cc[k2]);
	    								MT_EpistaticVariance(l1,l2,k1,k2,nu,tau,ph);
	    							}
						}		
		}
  
	/*
  if(category!=1)
	{
		y_bar=0.0,y2_bar=0.0;
  	for(i=0;i<ns;i++)
		{
			y_bar=y_bar+y[i];
  		y2_bar=y2_bar+y[i]*y[i];
		}
		y_bar=y_bar/ns;
		vp=(1.0/(ns-1))*(y2_bar-ns*pow(y_bar,2));
	} */
	
	//for(k=0;k<nc;k++) vmain[k]=(float)ns;
  
	/*
  if(epistasis==1) 
	{
	for(ph=0;ph<npheno1;ph++)
  {	for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++) vepistasis[ph][k1][k2]=1.0/(cc[k1]*cc[k2]);
		MT_EpistaticVariance(vp[ph],ph);
  	}
	} */
	
	/*
	if(gbye==1)
	{  
		for(l1=0;l1<nfixcova;l1++)
  		if(gbye_fix_index[l1]==1)
			{
  		for(ph=0;ph<npheno1;ph++)
			{
				for(k=0;k<nc;k++) v_gbye_fix[ph][l1][k]=1.0/(v_fix[l1]*cc[k]);
  			MT_GBYE_FixedCovariate_Variance(l1,vp[ph],ph);
				}
			}
  } */  
  
	
	
	if(env_factor==1)
	{ 
	for(ph=0;ph<npheno1;ph++)
		for(l=0;l<nrancova;l++) 
  	{
			MT_RandomCovariate(l,ph);		
			MT_RanVariance(l,vp[ph],ph);
  	}
  for(ph=0;ph<npheno1;ph++)	
		for(l=0;l<nfixcova;l++) MT_FixedCovariate(l,ph);		
	}
  /*
	if(gbye==1)
	{ 
		for(l1=0;l1<nfixcova;l1++)
		 for(ph=0;ph<npheno1;ph++)
	  	if(gbye_fix_index[l1]==1)
				for(l2=0;l2<nqtl;l2++)
					if(gamma1[ph][l2]!=0.0 && gamma_gbye[ph][l1][l2]!=0.0) 
	        MT_GBYE_FixedCovariate(l1,l2,ph);	
	} */
  
  	if(gbye==1)
		{
		 for(ph=0;ph<npheno1;ph++)
			for(l1=0;l1<nfixcova;l1++)
				if(gbye_fix_index[l1]==1)
					for(l2=0;l2<nqtl;l2++)
						if(gamma1[ph][l2]!=0.0&&gamma_gbye[ph][l1][l2]!=0.0)
  					{
	            MT_GBYE_FixedCovariate(l1,l2,ph);	
            	for(k=0;k<nc;k++) 
								if(gbye_fix[ph][l1][l2][k]!=0)
								{
  								tau=(nu-2)*h*vp[ph]/(nu*v_fix[l1]*cc[k]);
					        MT_GBYE_FixedCovariate_Variance(l1,l2,k,nu,tau,ph);
								}
  					}		
  	 }
	  
	//************************************************************************************
	//UPDATE THE QTL INHERITANCE OF NON-FOUNDERS AND THE GENOTYPIC VALUES
	
	if(updategeno==1)
	{
    if(difflocation==1)
	  {
	    for(ph=0;ph<npheno1;ph++)
        for(l=0;l<nqtl;l++) 
          	if(gamma1[ph][l]!=0) 
	        	{
	        		pd1[l]=0.0,pd2[l]=0.0;
          		for(i=0;i<ns;i++)
	        		{
	         			int k,kk=0;
	        			for(k=0;k<ng;k++)
	        			   if(qprob[qchr[ph][l]][i][qloc[ph][l]][k]>0.99) 
	        			   {
	        				   ibd=k;
	        				   kk=1;
	        			   } 
	        			if(kk==0)
                  {
                  MT_QTLgenotype(ph,l,qchr[ph][l],qloc[ph][l],i); 
	              	pd1[l]=pd1[l]+log(pdd1+1e-20);
	                pd2[l]=pd2[l]+log(pdd2+1e-20);		    
	                }
	                if(ibd != geno[ph][i][l])
	                {
	        				gvalue[ph][i]=MT_GenotypeSampling(i,l,ph,ibd,0);
                	geno[ph][i][l]=ibd;
	              	Coefficient(ibd);
                	for(k=0;k<nc;k++) coef[ph][i][l][k]=x[k];
	                }
	  
          		}
	        	}
	  }
    if(difflocation==0)
    {
	    for(l=0;l<nqtl;l++) 
	     {
	      int t=0;
	      for(ph=0;ph<npheno1;ph++) t=t+gamma1[ph][l];
	        	if(t!=0) 
	        	{
          		pd1[l]=0.0,pd2[l]=0.0;
	        		for(i=0;i<ns;i++)
	        		{
           			int k,kk=0;
          			for(k=0;k<ng;k++)
	        			   if(qprob[qchr[0][l]][i][qloc[0][l]][k]>0.99) 
	        			   {
          				   ibd=k;
	        				   kk=1;
	        			   } 
	        			if(kk==0)
	                {
	                MT_QTLgenotype(0,l,qchr[0][l],qloc[0][l],i); 
	              	pd1[l]=pd1[l]+log(pdd1+1e-20);
	                pd2[l]=pd2[l]+log(pdd2+1e-20);		    
	                }
	                if(ibd != geno[0][i][l])
                  {
                	for(ph=0;ph<npheno1;ph++)	gvalue[ph][i]=MT_GenotypeSampling(i,l,ph,ibd,0);
	              	geno[0][i][l]=ibd;
	              	Coefficient(ibd);
	              	for(k=0;k<nc;k++) coef[0][i][l][k]=x[k];
	                    for(ph=1;ph<npheno1;ph++)
	                       {
	                          geno[ph][i][l]=geno[0][i][l];
                            for(k=0;k<nc;k++) coef[ph][i][l][k]=coef[0][i][l][k];     
	                       }
                	
	                }
	  
          		}
	        	}
	
       }
    }    	
	}     
	//**********************************************************************************
	//UPDATING QTL POSITIONS
	 
	
	if(difflocation==1)
  {
	for(l=0;l<nqtl;l++) 
	 {
    for(ph=0;ph<npheno1;ph++) 
    {
	      if(gamma1[ph][l]!=0) 
	    	{
  		  int cat[4],qlnew,test=0;
	
	  		double r=RANDOM();
		   	cat[0]=(r>=0&&r<0.25),cat[1]=(r>=0.25&&r<0.5),cat[2]=(r>=0.5&&r<0.75),cat[3]=(r>=0.75&&r<=1.0);
			  qlnew=cat[0]*(qloc[ph][l]-2)+cat[1]*(qloc[ph][l]-1)+cat[2]*(qloc[ph][l]+1)+cat[3]*(qloc[ph][l]+2);
			  if(qlnew<0) qlnew=0;
			  if(qlnew>=ngrid[qchr[ph][l]]-1) qlnew=ngrid[qchr[ph][l]]-1;
			  if(qlnew!=qloc[ph][l])
			  {
				for(l0=0;l0<nqtl;l0++)
  				if( qchr[ph][l0]==qchr[ph][l]&&l0!=l ) 
  test=test+(fabs(grid[qchr[ph][l]][qlnew]-grid[qchr[ph][l0]][qloc[ph][l0]])<=dqq[qchr[ph][l]]);
	// The above tests if proposed QTLNEW is not within the dqq distance of 
	// any existing QTLs in the model.	  
				if(test==0)   MT_QTLPOSITION(l,qlnew,ph);
			  }
		   }
		}   
   } 
	}	
    
	
	if(difflocation==0)
  {
	for(l=0;l<nqtl;l++) 
	 {
   	int t=0;
    for(ph=0;ph<npheno1;ph++) t=t+gamma1[ph][l];
	
	      if(t!=0) 
	    	{
			  int cat[4],ph1,qlnew,test=0;
	
	  		double r=RANDOM();
  	   	cat[0]=(r>=0&&r<0.25),cat[1]=(r>=0.25&&r<0.5),cat[2]=(r>=0.5&&r<0.75),cat[3]=(r>=0.75&&r<=1.0);
			  qlnew=cat[0]*(qloc[0][l]-2)+cat[1]*(qloc[0][l]-1)+cat[2]*(qloc[0][l]+1)+cat[3]*(qloc[0][l]+2);
			  if(qlnew<0) qlnew=0;
  		  if(qlnew>=ngrid[qchr[0][l]]-1) qlnew=ngrid[qchr[0][l]]-1;
  		  if(qlnew!=qloc[0][l])
			  {
				for(l0=0;l0<nqtl;l0++)
  				if( qchr[0][l0]==qchr[0][l]&&l0!=l ) 
	    	test=test+(fabs(grid[qchr[0][l]][qlnew]-grid[qchr[0][l0]][qloc[0][l0]])<=dqq[qchr[0][l]]);
	// The above tests if proposed QTLNEW is not within the dqq distance of 
	// any existing QTLs in the model.	  
	
	// Have to test this in the future: QTLPOSITION_Samelocation might be the reason
	//for anomalies in TMV: and QTLPOSITION_SameLocation is not coded for genoupdate
	if(qtlloc1==0)			if(test==0)   QTLPOSITION_SameLocation(l,qlnew);
	if(qtlloc1==1)			if(test==0)   MT_QTLPOSITION(l,qlnew,0);
			  }
           for(ph1=1;ph1<npheno1;ph1++)
             {
	               qchr[ph1][l]=qchr[0][l];
	               qloc[ph1][l]=qloc[0][l];
	               for(i=0;i<ns;i++)
	               {
	         				 geno[ph1][i][l]=geno[0][i][l];
	                 for(k=0;k<nc;k++) coef[ph1][i][l][k]=coef[0][i][l][k];   
                  }        
	           }
    
	//      if(t==npheno1) ph=npheno1-1;
	
  	   }
		   
	 } 
  }	
        
	//**********************************************************
	// UPDATE MARGINAL EFFECT INDICATORS
	
	for(l=0;l<nqtl;l++)
	{
		int t,ph1,tt,k1;
  
		if(group==0)
		{
  		for(k=0;k<nc;k++)
  		{
				t=1,tt=0;
				if(gibbs==1) 
  			{  
	      if(difflocation==0) 
	          {
	          for(ph1=0;ph1<npheno1;ph1++) tt=tt+gamma1[ph1][l];        
	                if(tt==0) 
	                {
	                t=MT_SamplingOnePosition(l,0);
	                if(t!=0)   
	                  for(ph1=1;ph1<npheno1;ph1++)
	                     {
                       qchr[ph1][l]=qchr[0][l];
                       qloc[ph1][l]=qloc[0][l];
	                       for(i=0;i<ns;i++)
	                				 {
	                          geno[ph1][i][l]=geno[0][i][l];
	                          for(k1=0;k1<nc;k1++) coef[ph1][i][l][k1]=coef[0][i][l][k1];     
	                          }
	                     }
                  }   
	          }
  
	      			for(ph=0;ph<npheno1;ph++)			
	      			  {
               	if(difflocation==1)
	             	   { 
	                  t=1;
                    if(gamma1[ph][l]==0) t=MT_SamplingOnePosition(l,ph);
                   }
	                 
	        				if(t!=0) MT_MainEffectIndicator_GROUP0(l,k,ph);
	      
	      			    if(multiple1==1) 
	                  {
	                  for(ph1=0;ph1<npheno1;ph1++) gamma1[ph1][l]=gamma1[ph][l];
                    ph=npheno1-1;
	                  }
	        			}	
    				
    			
				}
		if(gibbs==0)
  			{
				int ttt[npheno1],sumTTT=0,k1;
				for(ph=0;ph<npheno1;ph++)			
				  {
	    				double r=RANDOM();
	    				ttt[ph]=0;
	    				if( (main1[ph][l][k]==0&&r<=w_main)||(main1[ph][l][k]!=0&&r>w_main) ) 
	    				{
	             	if(difflocation==1)
	             	  { t=1;
                    if(gamma1[ph][l]==0) t=MT_SamplingOnePosition(l,ph);
                				if(t!=0) 
	                				{
	                					if(main1[ph][l][k]==0&&r<=w_main)
	                					{
	                						double t0=0,u,u0;
	                						for(j=0;j<nu;j++)
	                						{
                  							ANORMAL(&u,&u0);
	                							t0=t0+u*u;
                  						}
	                						tau=(nu-2)*h*vp[ph]/(nu*cc[k]);
	                						vmain[ph][l][k]=nu*tau/t0;
                  					}
	        				    MT_MainEffectIndicator_GROUP0(l,k,ph);
	                				}
            			}
                else ttt[ph]=1,sumTTT=sumTTT+ttt[ph];  	
	    				}
	        }
	         
	           if(difflocation==0 && sumTTT!=0) 
	            {
	            for(ph1=0;ph1<npheno1;ph1++) tt=tt+gamma1[ph1][l];        
                    if(tt==0) 
	                  {
	                  t=MT_SamplingOnePosition(l,0);
                    if(t!=0)   
                      for(ph1=1;ph1<npheno1;ph1++)
	                       {
	                       qchr[ph1][l]=qchr[0][l];
                         qloc[ph1][l]=qloc[0][l];
	                       for(i=0;i<ns;i++)
	                				 {
	                          geno[ph1][i][l]=geno[0][i][l];
	                          for(k1=0;k1<nc;k1++) coef[ph1][i][l][k1]=coef[0][i][l][k1];     
	                          }
	                       }
	                  }   
	            for(ph=0;ph<npheno1;ph++) 
	              {
                  if(ttt[ph]==1 && t!=0) MT_MainEffectIndicator_GROUP0(l,k,ph);
                	    if(multiple1==1) 
	                      {
	                      for(ph1=0;ph1<npheno1;ph1++) gamma1[ph1][l]=gamma1[ph][l];
	                      ph=npheno1-1;
	                      }
	              }
	                  
              }
	
  			}
	
	    
  		}
		} 
	  /*
  	if(group==1)
  	{
			t=1;
			if(gibbs==1) 
			{
				if(gamma1[l]==0) t=MT_SamplingOnePosition(l);
				if(t!=0) MT_MainEffectIndicator_GROUP1(l);
			}
  		if(gibbs==0)
			{
				double r=RANDOM();
  			if( (gamma_main[l]==0&&r<=w_main)||(gamma_main[l]!=0&&r>w_main) ) 
  			{
					if(gamma1[l]==0) t=MT_SamplingOnePosition(l);
					if(t!=0) MT_MainEffectIndicator_GROUP1(l);
  			}
			}
		} */
	
	 }     
	
	  
	    
	
	//**********************************************************
  // UPDATE TWO ORDER epistatic EFFECT INDICATORS
  		
	if(epistasis==1)
	{
		int t,ph1;
		
		for(l1=0;l1<nqtl-1;l1++)
			for(l2=l1+1;l2<nqtl;l2++)
  		{
				if(group==0)
  			{
					for(k1=0;k1<nc;k1++)
						for(k2=0;k2<nc;k2++)
  					{
					/*	if(dependence==1)
							{
  							if(main1[l1][k1]!=0&&main1[l2][k2]!=0) w_epistasis=c[0];
  							if( (main1[l1][k1]!=0&&main1[l2][k2]==0)||(main1[l1][k1]==0&&main1[l2][k2]!=0) ) w_epistasis=c[1];
								if(main1[l1][k1]==0&&main1[l2][k2]==0) w_epistasis=c[2];
							}   */
	
							t=1;
			if(gibbs==1) 
	   	{
        	if(w_epistasis!=0)
	        {
	            if(difflocation==0)
                {       int t1=0,t2=0;
        								for(ph=0;ph<npheno1;ph++) 
	                        {
	                          t1=t1+gamma1[ph][l1];
                            t2=t2+gamma1[ph][l2];
	                        }  
	                      if(t1==0 && t2!=0) t=MT_SamplingOnePosition(l1,0);
	      								if(t1!=0 && t2==0) t=MT_SamplingOnePosition(l2,0);
	      								if(t1==0 && t2==0) 
	      								{
	      									t=MT_SamplingOnePosition(l1,0);
	      									if(t!=0) t=MT_SamplingOnePosition(l2,0);
					if(chrqtl[qchr[0][l1]]+2>chr_nqtl[qchr[0][l1]]&&qchr[0][l1]==qchr[0][l2]
	&&(grid[qchr[0][l1]][qloc[0][l1]]-grid[qchr[0][l2]][qloc[0][l2]])<=dqq[qchr[0][l1]]) t=0;
        								}
                        if(t!=0)
	                        for(ph1=1;ph1<npheno1;ph1++)
	                           {
	                           qchr[ph1][l1]=qchr[0][l1];
	                           qloc[ph1][l1]=qloc[0][l1];
	                           qchr[ph1][l2]=qchr[0][l2];
	                           qloc[ph1][l2]=qloc[0][l2];
                             for(i=0;i<ns;i++)
	                              {
                                geno[ph1][i][l1]=geno[0][i][l1];
	                              geno[ph1][i][l2]=geno[0][i][l2];
	                              coef[ph1][i][l1][k1]=coef[0][i][l1][k1];
                                coef[ph1][i][l2][k2]=coef[0][i][l2][k2];
	                              }
	                           }  
        								
  							}
	          }
	        if(difflocation==0)
	          for(ph=0;ph<npheno1;ph++)
	          {			if(t!=0) MT_EpistasisIndicator_GROUP0(l1,l2,k1,k2,ph);
	      			    if(multiple1==1)
	                  {
                    for(ph1=0;ph1<npheno1;ph1++){
	                   gamma1[ph1][l1]=gamma1[ph][l1];
	                   gamma1[ph1][l2]=gamma1[ph][l2];
                     }
                    ph=npheno1-1;
	                  }
	          }
            if(difflocation==1)
	  					for(ph=0;ph<npheno1;ph++)
	            {		
	            	if(w_epistasis!=0)
	              {
									if(gamma1[ph][l1]==0 && gamma1[ph][l2]!=0) t=MT_SamplingOnePosition(l1,ph);
									if(gamma1[ph][l1]!=0 && gamma1[ph][l2]==0) t=MT_SamplingOnePosition(l2,ph);
									if(gamma1[ph][l1]==0 && gamma1[ph][l2]==0)
									{
										t=MT_SamplingOnePosition(l1,ph);
  									if(t!=0) t=MT_SamplingOnePosition(l2,ph);
  									if(chrqtl[qchr[ph][l1]]+2>chr_nqtl[qchr[ph][l1]]&&qchr[ph][l1]==qchr[ph][l2]
						&&(grid[qchr[ph][l1]][qloc[ph][l1]]-grid[qchr[ph][l2]][qloc[ph][l2]])<=dqq[qchr[ph][l1]]) t=0;
	
									}
							  }		
	              	if(t!=0) MT_EpistasisIndicator_GROUP0(l1,l2,k1,k2,ph);
	
  							
						  }		
  		      			
	
	       } 
  	if(gibbs==0)
		{
	      			int ttt[npheno1],sumTTT=0;
        			for(ph=0;ph<npheno1;ph++)			
        			{	ttt[ph]=0;
	 							double r=RANDOM();
	if((epistatic[ph][l1][l2][k1][k2]==0&&r<=w_epistasis)||(epistatic[ph][l1][l2][k1][k2]!=0&&r>w_epistasis)) 
								{
									if(w_epistasis!=0)
									{
									 if(difflocation==1)
  								 	{ t=1;
	                  if(gamma1[ph][l1]==0&&gamma1[ph][l2]!=0) t=MT_SamplingOnePosition(l1,ph);
										if(gamma1[ph][l1]!=0&&gamma1[ph][l2]==0) t=MT_SamplingOnePosition(l2,ph);
  									if(gamma1[ph][l1]==0&&gamma1[ph][l2]==0) 
  									{ t=MT_SamplingOnePosition(l1,ph);
											if(t!=0) t=MT_SamplingOnePosition(l2,ph);
	if(chrqtl[qchr[ph][l1]]+2>chr_nqtl[qchr[ph][l1]]&&qchr[ph][l1]==qchr[ph][l2]
  &&(grid[qchr[ph][l1]][qloc[ph][l1]]-grid[qchr[ph][l2]][qloc[ph][l2]])<=dqq[qchr[ph][l1]]) t=0;                }
							if(t!=0) 
								{
									if(epistatic[ph][l1][l2][k1][k2]==0&&r<=w_epistasis)
									{
										double t0=0,u,u0;
										for(j=0;j<nu;j++)
										{
											ANORMAL(&u,&u0);
											t0=t0+u*u;
  									}
  									tau=(nu-2)*h*vp[ph]/(nu*cc[k1]*cc[k2]);
										vepistasis[ph][l1][l2][k1][k2]=nu*tau/t0;
									}
								  MT_EpistasisIndicator_GROUP0(l1,l2,k1,k2,ph);
								}
	
										} else ttt[ph]=1,sumTTT=sumTTT+ttt[ph];  	
                  }
								}		
  						}
	            
	           if(difflocation==0 && sumTTT!=0) 
              {
	              int t1=0,t2=0;
	      								for(ph1=0;ph1<npheno1;ph1++) 
                          {
                            t1=t1+gamma1[ph1][l1];
	                          t2=t2+gamma1[ph1][l2];
	                        }  
	                      if(t1==0 && t2!=0) t=MT_SamplingOnePosition(l1,0);
	      								if(t1!=0 && t2==0) t=MT_SamplingOnePosition(l2,0);
	      								if(t1==0 && t2==0) 
	      								{
        									t=MT_SamplingOnePosition(l1,0);
	      									if(t!=0) t=MT_SamplingOnePosition(l2,0);
					if(chrqtl[qchr[0][l1]]+2>chr_nqtl[qchr[0][l1]]&&qchr[0][l1]==qchr[0][l2]
  &&(grid[qchr[0][l1]][qloc[0][l1]]-grid[qchr[0][l2]][qloc[0][l2]])<=dqq[qchr[0][l1]]) t=0;
        								}
	                      if(t!=0)
	                        for(ph1=1;ph1<npheno1;ph1++)
                             {
	                           qchr[ph1][l1]=qchr[0][l1];
	                           qloc[ph1][l1]=qloc[0][l1];
	                           qchr[ph1][l2]=qchr[0][l2];
	                           qloc[ph1][l2]=qloc[0][l2];
	                           for(i=0;i<ns;i++)
	                              {
	                              geno[ph1][i][l1]=geno[0][i][l1];
	                              geno[ph1][i][l2]=geno[0][i][l2];
	                              coef[ph1][i][l1][k1]=coef[0][i][l1][k1];
                                coef[ph1][i][l2][k2]=coef[0][i][l2][k2];
                                }
	                           }  
	            for(ph=0;ph<npheno1;ph++) 
	              {
	                if(ttt[ph]==1 && t!=0) MT_EpistasisIndicator_GROUP0(l1,l2,k1,k2,ph);
	              	    if(multiple1==1) 
	                      {
                        for(ph1=0;ph1<npheno1;ph1++){ 
	                      gamma1[ph1][l1]=gamma1[ph][l1];
                        gamma1[ph1][l2]=gamma1[ph][l2];
	                      }
	                      ph=npheno1-1;
                        }
	              }
	                  
              }
              		
									
	             
	      }  
	    }
	  } 
	
  /*			if(group==1)
				{	
					if(dependence==1)
  				{
  					if(gamma_main[l1]!=0&&gamma_main[l2]!=0) w_epistasis=c[0];
						if( (gamma_main[l1]!=0&&gamma_main[l2]==0)||(gamma_main[l1]==0&&gamma_main[l2]!=0) ) w_epistasis=c[1];
						if(gamma_main[l1]==0&&gamma_main[l2]==0) w_epistasis=c[2];
  				}
					
					t=1;
					if(gibbs==1)
					{
						if(w_epistasis!=0)
						{
							if(gamma1[l1]==0&&gamma1[l2]!=0) t=MT_SamplingOnePosition(l1);
							if(gamma1[l1]!=0&&gamma1[l2]==0) t=MT_SamplingOnePosition(l2);
							if(gamma1[l1]==0&&gamma1[l2]==0)
  						{
  							t=MT_SamplingOnePosition(l1);
								if(t!=0) t=MT_SamplingOnePosition(l2);
								if(chrqtl[qchr[l1]]+2>chr_nqtl[qchr[l1]]&&qchr[l1]==qchr[l2]
									&&(grid[qchr[l1]][qloc[l1]]-grid[qchr[l2]][qloc[l2]])<=dqq[qchr[l1]]) t=0;
							}
						}
						if(t!=0) MT_EpistasisIndicator_GROUP1(l1,l2);
  				}
					if(gibbs==0)
  				{
						double r=RANDOM();
						if( (gamma_epistasis[l1][l2]==0&&r<=w_epistasis)||(gamma_epistasis[l1][l2]!=0&&r>w_epistasis) )
  					{
							if(w_epistasis!=0)
							{
  							if(gamma1[l1]==0&&gamma1[l2]!=0) t=MT_SamplingOnePosition(l1);
  							if(gamma1[l1]!=0&&gamma1[l2]==0) t=MT_SamplingOnePosition(l2);
								if(gamma1[l1]==0&&gamma1[l2]==0) 
								{
									t=MT_SamplingOnePosition(l1);
									if(t!=0) t=MT_SamplingOnePosition(l2);
									if(chrqtl[qchr[l1]]+2>chr_nqtl[qchr[l1]]&&qchr[l1]==qchr[l2]
										&&(grid[qchr[l1]][qloc[l1]]-grid[qchr[l2]][qloc[l2]])<=dqq[qchr[l1]]) t=0;
  							}
							}
							if(t!=0) MT_EpistasisIndicator_GROUP1(l1,l2);
  					}
  				}
				}  */
	
  		} // l1 & l2 loop end here
	} //if(epistasis) end here 
	
	 
	//************************************************************
	//update g by e fixed effects INDICATORS
	
	if(gbye==1)
	{ 
	for(l1=0;l1<nfixcova;l1++)
   if(gbye_fix_index[l1]==1)
  	for(ph=0;ph<npheno1;ph++)
		 for(l2=0;l2<nqtl;l2++)		
			if(gamma1[ph][l2]!=0)
			{	
				if(group==0)
				{
					for(k=0;k<nc;k++)
  				{
						if(gibbs==1) MT_GBYE_FIX_Indicator_GROUP0(l1,l2,k,ph);
  					if(gibbs==0)
						{
							double r=RANDOM();
  				if((gbye_fix[ph][l1][l2][k]==0&&r<=w_gbye)||(gbye_fix[ph][l1][l2][k]!=0&&r>w_gbye))
	                      						{
	                      							if(gbye_fix[ph][l1][l2][k]==0&&r<=w_gbye)
                        							{
                        								double t0=0,u,u0;
	                      								for(j=0;j<nu;j++)
	                      								{
	                      									ANORMAL(&u,&u0);
	                      									t0=t0+u*u;
	                      								}
	                      								tau=(nu-2)*h*vp[ph]/(nu*v_fix[l1]*cc[k]);
                        								v_gbye_fix[ph][l1][l2][k]=nu*tau/t0;
	                      							}
	                      	
                  							MT_GBYE_FIX_Indicator_GROUP0(l1,l2,k,ph);
                        						}
								
						}
  				}
	     	    if(multiple1==1) 
	              {
								int ph1;
	              for(ph1=0;ph1<npheno1;ph1++) gamma1[ph1][l2]=gamma1[ph][l2];
	              ph=npheno1-1;
	              }
				}
	
			/*	if(group==1)
  			{
  				if(gibbs==1) MT_GBYE_FIX_Indicator_GROUP1(l1,l2);
	
					if(gibbs==0)
					{
						double r=RANDOM();
						if( (gamma_gbye[l1][l2]==0&&r<=w_gbye)||(gamma_gbye[l1][l2]!=0&&r>w_gbye) )
							MT_GBYE_FIX_Indicator_GROUP1(l1,l2);
  				}
				}*/
  
			}
	}
  
	//**********************************************************
	//update the threshold values
  /*
  if(category==3)
	{
		int j; double cutpoint0[cn+1],al0,al;
	
		for(j=0;j<=cn;j++) cutpoint0[j]=cutpoint[j];
				
		al0=Likelihood(cutpoint,gvalue);
  
		for(j=2;j<=cn-2;j++)
		{
  		cutpoint0[j]=cutpoint[j]+0.01*(RANDOM()-0.5);
  		if(cutpoint0[j]<=cutpoint0[j-1]) cutpoint0[j]=cutpoint0[j-1]+0.01*RANDOM();
			if(cutpoint0[j]>cutpoint[j+1]) cutpoint0[j]=cutpoint[j+1]-0.01*RANDOM(); 
		}
  
		al=Likelihood(cutpoint0,gvalue);
	
		if((al-al0)>log(RANDOM())) 
			for(j=2;j<=cn-2;j++) cutpoint[j]=cutpoint0[j];		
	}
	*/
	//***************************************************************
	   
	}    //iter1 end here
     
  //***************************************************************
	//CALCULATE THE NUMBER OF QTL
	/*
	Rprintf("\n");
	for(ph=0;ph<npheno1;ph++)
	{
	Rprintf("\nGAMMA[%d]",ph+1);           
    for(l=0;l<nqtl;l++)
	  Rprintf("\t%d",gamma1[ph][l]);             
  }
	Rprintf("\n");
	for(ph=0;ph<npheno1;ph++)
  {
	Rprintf("\nGMAIN[%d]",ph+1);           
	  for(l=0;l<nqtl;l++)
    Rprintf("\t%d",gamma_main[ph][l]);             
  }
	Rprintf("\n");
	for(ph=0;ph<npheno1;ph++)
	{
	for(l1=0;l1<nfixcova;l1++)
	{
	Rprintf("\nGBYE[%d,%d]",ph+1,l1+1);           
    for(l=0;l<nqtl;l++)
	  Rprintf("\t%f",gamma_gbye[ph][l1][l]);             
	}  
  } */
  
	
	
  
	int qtl_included[npheno1];
	for(ph=0;ph<npheno1;ph++)
	{ qtl_included[ph]=0;
	  for(l=0;l<nqtl;l++) qtl_included[ph]=qtl_included[ph]+(gamma1[ph][l]==1);  
	}
	//*************************************************************** 
	//SAVE THE RESULT 
	 
	if(iter*iter1>=nburnin)
  {
  
	if((iter!=0)&&(iter%10==0)&(verbose1>0))  
	{
		Rprintf("%d",iter);
		Rprintf("\n");
	}
	int ph1;
   if(multiple1>=1)   INVERSE(sigma,npheno1,sigma);
	
  
	/*//CALCULATE DEVIANCE
	double dev=0;  
  for(i=0;i<ns;i++) dev=dev+log(2*3.14159265358*ve)+pow(y[i]-amu-gvalue[i],2)/ve;
	*/
	// save to "iterdiag"
  for(ph1=0;ph1<npheno1;ph1++)
  {
	fprintf(file1,"\n");
	fprintf(file1,"%d\t",iter+1);
	fprintf(file1,"%d\t",ph1+1); /* yandell add */ 
	fprintf(file1,"%d\t",qtl_included[ph1]);
	fprintf(file1,"%f\t",amu[ph1]);
	if(multiple1>=1) ve=sigma[ph1][ph1];
  fprintf(file1,"%f\t",ve);
	
	
  // save to "covariates"
  if(env_factor==1)
	{
		fprintf(file2,"\n");
    fprintf(file2,"%d\t",ph1+1); /* yandell add */ 		
	
		for(l=0;l<nfixcova;l++) fprintf(file2,"%f\t",fix[ph1][l]);
		for(l=0;l<nrancova;l++) fprintf(file2,"%f\t",vran[ph1][l]);
	} 
	if(category==3)
	  for(l=2;l<=cn-2;l++) fprintf(file2,"%f\t",cutpoint[l]);
	      
	// save to "mainloci"
	double var1[ng];
  for(k=0;k<nc;k++) var1[k]=0;
  for(l=0;l<nqtl;l++) 
		if(gamma1[ph1][l]!=0) 
		{
			fprintf(file3,"\n");
			fprintf(file3,"%d\t",iter+1);
	    fprintf(file3,"%d\t",ph1+1); /* yandell add */ 		
	        fprintf(file3,"%d\t",qtl_included[ph1]);
          fprintf(file3,"%d\t",qchr[ph1][l]+1);
	//        fprintf(file3,"%f\t",grid[qchr[l]][qloc[l]]);
  		fprintf(file3,"%d\t",qloc[ph1][l]);
			for(k=0;k<nc;k++) fprintf(file3,"%f\t",main1[ph1][l][k]);
			for(k=0;k<nc;k++)
  		{
				double ss1=0,ss2=0,ss=0;
				if(main1[ph1][l][k]!=0)
  			{
  				for(i=0;i<ns;i++)
					{
						ss1=ss1+pow(coef[ph1][i][l][k],2);
						ss2=ss2+coef[ph1][i][l][k];
					}
					ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2))*pow(main1[ph1][l][k],2);
				}
  			fprintf(file3,"%f\t",ss);
				var1[k]=var1[k]+ss;
			}
  	}
  for(k=0;k<nc;k++) fprintf(file1,"%f\t",var1[k]);
	
	
  // save to "pairloci"
	double var2[ng][ng];
	for(k1=0;k1<nc;k1++)
		for(k2=0;k2<nc;k2++) var2[k1][k2]=0;
		
	if(epistasis==1)
	{
		int n_epis=0;
		for(l1=0;l1<nqtl;l1++)
			for(l2=l1+1;l2<nqtl;l2++)
  			for(k1=0;k1<nc;k1++)
  				for(k2=0;k2<nc;k2++)
						if(epistatic[ph1][l1][l2][k1][k2]!=0) n_epis=n_epis+1;
	
		for(l1=0;l1<nqtl;l1++)
			for(l2=l1+1;l2<nqtl;l2++) 
				if(gamma1[ph1][l1]!=0&&gamma1[ph1][l2]!=0&&gamma_epistasis[ph1][l1][l2]!=0) 
				{
  				fprintf(file4,"\n");
					fprintf(file4,"%d\t",iter+1);
          fprintf(file4,"%d\t",ph1+1); /* yandell add */ 				
					fprintf(file4,"%d\t",n_epis);
					fprintf(file4,"%d\t",qchr[ph1][l1]+1);
  //				fprintf(file4,"%f\t",grid[qchr[l1]][qloc[l1]]);
					fprintf(file4,"%d\t",qloc[ph1][l1]);
					fprintf(file4,"%d\t",qchr[ph1][l2]+1);
  //				fprintf(file4,"%f\t",grid[qchr[l2]][qloc[l2]]);
  				fprintf(file4,"%d\t",qloc[ph1][l2]);
					for(k1=0;k1<nc;k1++)
						for(k2=0;k2<nc;k2++) fprintf(file4,"%f\t",epistatic[ph1][l1][l2][k1][k2]);
	
					for(k1=0;k1<nc;k1++)
					for(k2=0;k2<nc;k2++)
					{
  					double ss1=0,ss2=0,ss=0;
						if(epistatic[ph1][l1][l2][k1][k2]!=0)
						{
  						for(i=0;i<ns;i++)
  						{
								ss1=ss1+pow(coef[ph1][i][l1][k1]*coef[ph1][i][l2][k2],2);
								ss2=ss2+coef[ph1][i][l1][k1]*coef[ph1][i][l2][k2];
  						}
							ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2))*pow(epistatic[ph1][l1][l2][k1][k2],2);
						}
						fprintf(file4,"%f\t",ss);
						var2[k1][k2]=var2[k1][k2]+ss;
					}
				}
	    for(k1=0;k1<nc;k1++)
			for(k2=0;k2<nc;k2++) fprintf(file1,"%f\t",var2[k1][k2]);
	}
  
   
	// save to "gbye"
	double var3[ng];
	for(k=0;k<nc;k++) var3[k]=0;
	
	if(gbye==1)
	{
  	int n_gbye=0;
		for(l1=0;l1<nfixcova;l1++)
  		for(l2=0;l2<nqtl;l2++)
				for(k=0;k<nc;k++)
					if(gbye_fix[ph1][l1][l2][k]!=0) n_gbye=n_gbye+1;
  	
		for(l1=0;l1<nfixcova;l1++)
			 if(gbye_fix_index[l1]==1)
  			for(l2=0;l2<nqtl;l2++)
  				if(gamma1[ph1][l2]!=0.0)
						if(gamma_gbye[ph1][l1][l2]!=0.0)
						{
							fprintf(file5,"\n");
							fprintf(file5,"%d\t",iter+1);
	            fprintf(file5,"%d\t",ph1+1); /* yandell add */ 		
							fprintf(file5,"%d\t",n_gbye);
  						fprintf(file5,"%d\t",l1+1);
							fprintf(file5,"%d\t",qchr[ph1][l2]+1);
						//	fprintf(file5,"%f\t",grid[qchr[l2]][qloc[l2]]);
  						fprintf(file5,"%d\t",qloc[ph1][l2]);
  						for(k=0;k<nc;k++) fprintf(file5,"%f\t",gbye_fix[ph1][l1][l2][k]);
	
							for(k=0;k<nc;k++)
  						{
								double ss1=0,ss2=0,ss=0;
								if(gbye_fix[ph1][l1][l2][k]!=0)
								{
									for(i=0;i<ns;i++)
									{
										ss1=ss1+pow(coef_fix[i][l1]*coef[ph1][i][l2][k],2);
										ss2=ss2+coef_fix[i][l1]*coef[ph1][i][l2][k];
									}
									ss=1.0/(ns-1)*(ss1-ns*pow(ss2/ns,2))*pow(gbye_fix[ph1][l1][l2][k],2);
  							}
  							fprintf(file5,"%f\t",ss);
								var3[k]=var3[k]+ss;
							}
						}
		for(k=0;k<nc;k++) fprintf(file1,"%f\t",var3[k]);
	}
	
  
	double var=0;
  for(k1=0;k1<nc;k1++)
	{
		var=var+var1[k1]+var3[k1];
  	for(k2=0;k2<nc;k2++) var=var+var2[k1][k2];
	}
	if(env_factor==1) fprintf(file1,"%f\t",vp[ph1]-var-ve);
  fprintf(file1,"%f\t",var);
  /*
	//save to "deviance"
	fprintf(file6,"%d\t",iter);
	fprintf(file6,"%lf\t",dev);
	fprintf(file6,"\n");
	
	}
   */
	     
	 
  if((multiple1>=1) & (ph1 == 0)) // only print sigma once per iteration.
   { 
	    for(i=0;i<npheno1;i++)
	          for(j=0;j<npheno1;j++)           fprintf(file7,"%f\t",sigma[i][j]);
  
	        fprintf(file7,"\n");   
	  }    
	fflush(NULL);
	 }
	}
	
	  
	} //iter end here
	
  
  fclose(file1);  
	fclose(file2); 
	fclose(file3); 
	fclose(file4);
	fclose(file5);
	fclose(file6);
	fclose(file7);
    
	
  /*
	Rprintf("\n");
	
  Rprintf("simulate %d MCMC steps,", niter*nthin);
	Rprintf(" record by %d", nthin);
	Rprintf("\n");
  
  if(epistasis==0) Rprintf("This is a non-epistatic model");
	if(epistasis==1) Rprintf("This is an epistatic model");Rprintf("\n");
	
	
	Rprintf("Prior number of main-effect QTL: %d", e_nqtl_main);Rprintf("\n");
	
	if(epistasis==1) {Rprintf("Prior number of all QTL: %d", e_nqtl);Rprintf("\n");}
  
	Rprintf("Maximum number of QTL: %d", nqtl);Rprintf("\n");
	
  Rprintf("maximun number of QTL at each chromosome: ");
  for(l=0;l<nlg;l++) Rprintf("%d ", chr_nqtl[l]);Rprintf("\n");
	
	Rprintf("Prior of main effect indicator: %f", w_main);Rprintf("\n");
  
	if(epistasis==1) Rprintf("Prior of epistatic effect indicator: %f", w_epistasis);Rprintf("\n");
	 
	Rprintf("\n"); */    
	
}
	
	      
	
	
  
  
	
	
	
	
	
	
  
	
  
	
	
  
	
	
  
