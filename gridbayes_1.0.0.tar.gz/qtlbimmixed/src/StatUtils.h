/******************************************************************************
* File: StatUtil.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#ifndef STAT_UTILS_H
#define STAT_UTILS_H

double RANDOM();
void ANORMAL(double *r1,double *r2);
void MULTINORMAL(double * prior1);
double NormalFunction(double x);
double TrunNormal(double t1, double t2, double b, double v);
double LeftTrunNormal(double t1, double b, double v);
void Multivariate_RNORM(double **sigma_cholesky,double *mu,int m,double *sample);
double floor_p(double number, double pos);

#endif // STAT_UTILS_H
