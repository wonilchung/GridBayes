/******************************************************************************
* File: MultipleTraitMCMC.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:  QTL Bayesian Interval Mapping with Mixed Model
*   Functions relevant to MCMC Model Selection for multiple trait analyses
******************************************************************************/

#ifndef MULTIPLE_TRAITS_MCMC_H
#define MULTIPLE_TRAITS_MCMC_H

/// Main MCMC analysis driver for multiple traits
void multipleTraitsMCMC();

/// @note: Temporary redeclaration here so that the compiler does not throw a warning. Definition in SingleTraitsMCMCSamplingRoutines.c
void Coefficient(int genotype);

#endif // MULTIPLE_TRAITS_MCMC_H
