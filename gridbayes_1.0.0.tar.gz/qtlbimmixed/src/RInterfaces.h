/******************************************************************************
* File: RInterfaces.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:  QTL Bayesian Interval Mapping with Mixed Model
*   Functions that are called from the r environment
******************************************************************************/

#ifndef R_INTERFACES_H
#define R_INTERFACES_H


void RSingleTraitMCMCSetup(int *nind,int *nchr,int *ngen, int *nloci,double *loci,double *prob,
					  double *yvalue,int *traittype,int *ncategory,
					  int *iter,int *thin,int *burnin,int *genoupdate,
            int *epis,int *emainqtl,int *eqtl,int *mnqtl,
					  double *interval,int *chrnqtl,
					  int *envi,int *qtl_envi,int *nrancov,int *nfixcov,int *intcov,double *rancoef,double *fixcoef,int *nran,
						int *kin, double *kinmatrix, double *ome_mean, double *ome_var, /*for kinship matrix*/
						int *longi,double *timecoef,int *subidcoef,int *subnum,int *gridnum, /*for longitudinal data*/
						double *del_mean, double *del_var, double *p_mean, double *p_var, double *sigma2,  /*for longitudinal data*/
					  int *depen,double *prop,int *contrast,double *censor_lo,double *censor_hi,
					  int *seed,int *verbose);


void RMultipleTraitsMCMCSetup(int *nind,int *nchr,int *ngen,int *npheno,int *nloci,double *loci,double *prob,
					  double *yvalue,int *multipletrait,int *traittype,int *ncategory,
					  int *iter,int *thin,int *burnin,int *algorithm,int *genoupdate,
					  int *epis,int *emainqtl,int *eqtl,int *mnqtl,
					  double *interval,int *chrnqtl,
					  int *envi,int *qtl_envi,int *nrancov,int *nfixcov,int *intcov,double *rancoef,double *fixcoef,int *nran,
					  int *depen,double *prop,
					  int *seed,int *verbose,
					  int *diffloc, int *qtlloc);  


void RBayesianAnovaSetup( int *nind,int *nchr,int *ngen, int *nloci,double *loci,double *prob,
					 double *yvalue,int *traittype,int *ncategory,
					 int *iter,int *thin,int *burnin,
           int *genoupdate,int *posupdate,
           int *epis,int *mnqtl,
					 double *interval,int *chrnqtl,
					 int *envi,int *qtl_envi,int *nrancov,int *nfixcov,int *intcov,double *rancoef,double *fixcoef,int *nran,
				   int *contrast,
					 int *qchr,int *qloc,int *gamma_main,int *gamma_epis,double *gamma_gbye,
					 int *seed,int *verbose );


void ROutputManager(char **iterFile,char **covFile,char **mainFile,char **pairFile,char **gbyeFile,char **devFile,char **sigmaFile,
									char **mixedFile,char **testFile);

void R_CheckUserInterrupt(void);

#endif // R_INTERFACES_H
