/******************************************************************************
* File: GlobalVars.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:  QTL Bayesian Interval Mapping with Mixed Model
*   Defining all the global variables used in the code
*   This should only be a temporary file, a stepping stone 
*   in the process of moving away from global variables
******************************************************************************/

//********************************************************************
// QTLBIMMIXED - 
// 
// 
//********************************************************************
#include <stdio.h>

#ifndef GLOBAL_VARS_H
#define GLOBAL_VARS_H


//***************************************************************************************
/// @defgroup qbPheno Variables that should reside in the qp.pheno structure
/// @{

/// 1: normal data; 2: binary data; 3:ordinal data
extern int category;
/// @warning No documentation available
extern double *censor_lo1;
/// @warning No documentation available
extern double *censor_hi1;
/// Categories # for binary or ordinal data
extern int cn;
/// threshold values for ordinal traits
extern double *cutpoint;
/// random effects #
extern int nrancova;
/// fixed effects #
extern int nfixcova;
/// random effect #
extern int *nran1;
/// random covariates
extern double **coef_ran;
/// fixed covariates
extern double **coef_fix;

///////////////////////////////////////////////
/// 1: use kinship matrix
extern int kin_factor;        
/// kinship matrix
extern double **kinmat;     
/// m matrix for random effect
extern double **kin_m;
/// (kin_m)^T(kin_m) matrix
extern double **mtm;
        				   
/// mean of prior for omega
extern double omega_mean;
/// variance of prior for omega
extern double omega_var;
///////////////////////////////////////////////

///////////////////////////////////////////////
/// 1:include longitudinal factors
extern int longi_factor;      
/// time covariates
extern double *coef_time;    
/// subject id covariates
extern int *coef_subid;       
/// number of subjects
extern int num_subject;        
/// number of grid
extern int num_grid;          
/// number of time points for each subject
extern int *num_timepts;      
/// p matrix for random effect for time 
extern double *grid_p;         
/// v matrix for random effect for time 
extern double *grid_v; 
/// maximun value of time point
extern int max_num_timept;    

/// mean of prior for delta
extern double delta_mean;			
/// variance of prior for delta
extern double delta_var;				
/// mean of prior for psi
extern double *psi_mean;				
/// variance of prior for psi
extern double *psi_var;				
/// fixed sigma^2
extern double sigma2_fixed;
////////////////////////////////////////////////

/// number of individuals
extern int ns;
/// number of individuals
/// @note This variable has to be removed and consumed by ns. There is no current need for two
extern int ns1;
/// ordinal or binary phenotype
extern int *w;

/// @}



//***************************************************************************************
/// @defgroup qbGeno Variables that should reside in the qb.geno structure
///@{

/// max number of grids
extern int chl;
/// QTL number at each chromosome
extern int *chrqtl;
/// cross type 0:RILs, 1:BC, 2:f2
extern int cross;
/// grid points
extern double **grid;
/// number of genotypes
extern int ng;
/// number of grids at each chromosome
extern int *ngrid;
/// number of chromosomes
extern int nlg;
// genotype probabilities for each individual at each grid
extern double ****qprob;
/// total number of grids
extern int tngrid;

///@}



//***************************************************************************************
/// @defgroup qbModel Variables that should reside in the qb.model structure
/// @note nc0 and multiple which have been listed in the variable classification excel file are not in this header!
/// @note nc is listed as an internal variable. What is it doing in a header? Or is my understanding of 'internal' flawed? - Ram
/// @{

/// see Chipman's paper
extern double *c;
/// max QTL # at each chromosome
extern int *chr_nqtl;
/// see Chipman's paper
extern int dependence;
/// distance between flanking two genes
extern double *dqq;
/// expected number of all QTL
extern int e_nqtl;
/// expected number of main-effect QTL
extern int e_nqtl_main;
/// 1:include environmental factors-need to fix this
extern int env_factor;
/// 1: epistatic model; 0: non-epistatic model;
extern int epistasis;
/// 1: include g by e interactions
extern int gbye;
/// indicating which fixed covariates are treated in g-by-e
extern int *gbye_fix_index;
/// 1: groupedly update all main effects or epistatic effects
extern int group;
/// the number of main effects at one QTL
extern int nc;
/// max QTL #
extern int nqtl;
/// prior for main effect indicator
extern double w_main;
/// prior for epistatic effect indicator
extern double w_epistasis;
/// prior for g by e indicator
extern double w_gbye;

/// @}



//***************************************************************************************
/// @defgroup qbMCMC Variables that should reside in the qb.mcmc structure
/// @{

/// 1: Gibbs scaning all effects; 0: Kohn's m-h method for MCMC algorithm
extern int gibbs;
/// Burnin
extern int nburnin;
/// Number of iterations
extern int niter;
/// Thinning value
extern int nthin;
/// the pseudo-random number generator
extern int seed1;
/// 1: update QTL genotypes; 0: doesn't update QTL genotype
extern int updategeno;
/// 1: update QTL positions; 0: doesn't update QTL positions
extern int updatepos;
/// Verbose
extern int verbose1;

///@}



//********************************************************************************
/// 1: standardized phenotype; 0: original phenotype
/// @warning deprecated
extern int sph;
//***********************************************************************************
/// genotypic valyes
extern double pdd1, pdd2;
extern double *pd1, *pd2;
extern int ibd;
extern double  *x;

//******************************************************************
extern char iterfile[100];
extern char pairfile[100];
extern char mainfile[100];
extern char gbyefile[100];
extern char covfile[100];
extern char devfile[100];
extern char sigmafile[100];
extern char mixedfile[100];
extern char testfile[100];

//*************************
extern FILE *log_file;
//*************************

#endif // GLOBAL_VARS_H
