/******************************************************************************
* File: GlobalVars_SingleTrait.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#ifndef GLOBAL_VARS_SINGLE_TRAIT_H
#define GLOBAL_VARS_SINGLE_TRAIT_H

/// @addtogroup qbGeno
/// @{

/// QTL genotypes
/// @note: RV contests the inclusion of this variable into a Genotype data structure. It is the only var in Geno that gets extra dimensions for multiple traits. Does that indicate that it belongs elsewhere?
extern int **geno;

/// @}

/// @addtogroup qbPheno
/// @{

/// phenotypic data
extern double *y;

/// @}

/// genotypic valyes
extern double *gvalue;


//***************************************************************************************
/// @defgroup qbOp Variables that should reside in the qp.op structure
/// @{


/// coefficients of QTL main effects
extern double ***coef;
/// QTL position indicators, position is grid[qchr[l]][qloc[l]]
extern int *qloc;
/// chromosomes that QTL locate
extern int *qchr;

/// @defgroup qbOpCovariate Variables in qb.op.covariate
/// @{
/// effects of fixed covariates
extern double  *fix;
/// effects of random covariates
extern double  **ran;
/// variances of random covariates
extern double  *vran;
/// interactions of QTL main effects and fixed covariates
extern double ***gbye_fix;
/// @}

/// @defgroup qbOpIterdiag Variables in qb.op.iterdiag
/// @{
/// overall mean
extern double amu;
/// QTL indicators
extern int *gamma1;
/// residual variance
extern double *ve;
/// @}

/// @defgroup qbOpMainloci Variables in qb.op.mainloci
/// @{
/// main effects
extern double  **main1;
/// main effects indicators
extern int *gamma_main;
/// prior variance of main effects
extern double  **vmain;
/// prior variance of main effects
extern double  *vmain1;
/// @}

/// @defgroup qbOpPairloci Variables in qb.op.pairloci
/// @{
/// epistatic effects
extern double ****epistatic;
/// epistatic effects indicators
extern int **gamma_epistasis;
/// prior variance of epistatic effects
extern double ****vepistasis;
/// prior variance of epistatic effects
extern double **vepistasis1;
/// @}

/// @defgroup qbOpGbyE Variables in qb.op.gbye
/// @{
/// g-by-e indicators
extern double  **gamma_gbye;
/// prior variance of g-by-e effects
extern double ***v_gbye_fix;
/// prior variance of g-by-e effects
extern double **v_gbye_fix1;
/// @}

/// latent normal variable c
extern double* latent_c;
/// omega value
extern double* kin_omega;
/// q by c value
extern double* qcvalue;
/////////////////////////////

/// latent normal variable b
extern double* latent_b;
/// delta of random effect
extern double* ran_delta;
/// psi of random effect
extern double* ran_psi;
/// vb of random effect
extern double* vbvalue;

/// @}

//*************************************************************************************************************
#endif // GLOBAL_VARS_SINGLE_TRAIT_H
