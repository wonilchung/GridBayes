/******************************************************************************
* File: GlobalVars.c
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description: QTL Bayesian Interval Mapping with Mixed Model
*   Defining all the global variables used in the code
*   This should only be a temporary file, a stepping stone 
*   in the process of moving away from global variables
******************************************************************************/

#include "GlobalVars.h"

// Defining global variables

int cross;         // cross type 0:RILs, 1:BC, 2:f2
int ng;            // number of genotypes
int ns;            // number of individuals 
int ns1;           // number of individuals 
int nlg;           // number of chromosomes
int m;             // number of marker   

//********************************************************************************

int haldane;      // 1: Haldane distance; 0: Kosambi distance
double cstep;     // length of the grid
double *recm;     // marker map
double lchr;      // chr length
int **mk;         // marker genotype
int kchr;         // number of markers

double ***genoprob;
double *chr_grid;


double **grid;     // grid points
double ****qprob;  // genotype probabilities for each individual at each grid

int tngrid;        // total number of grids
int *ngrid;        // number of grids at each chromosome
int chl;           // max number of grids 

//*****************************************************************************************
// these parameters are passed from r function bmq.mcmc

int category;          // 1: normal data; 2: binary data; 3:ordinal data
int cn;                // Categories # for binary or ordinal data

int niter;             // Number of iterations
int nthin;             // Thinning value
int nburnin;           // Burnin
int verbose1;          // Verbose

int gibbs;             // 1: Gibbs scaning all effects; 0: Kohn's m-h method for MCMC algorithm
int updategeno;        // 1: update QTL genotypes; 0: doesn't update QTL genotype
int updatepos;         // 1: update QTL positions; 0: doesn't update QTL positions

int epistasis;         // 1: epistatic model; 0: non-epistatic model;
int e_nqtl_main;       // expected number of main-effect QTL 
int e_nqtl;            // expected number of all QTL 
int nqtl;              // max QTL #  

double *dqq;            // distance between flanking two genes 
int *chr_nqtl;          // max QTL # at each chromosome

int env_factor;         // 1:include environmental factors-need to fix this
int gbye;               // 1: include g by e interactions
int nrancova;           // random effects #
int nfixcova;           // fixed effects # 
int *gbye_fix_index;    // indicating which fixed covariates are treated in g-by-e
int *nran1;             // random effect #
double **coef_ran;      // random covariates
double **coef_fix;      // fixed covariates

/////////////////////////////////////////////////////////////
int kin_factor;         // 1: use kinship matrix
double **kinmat;        // kinship matrix
double **kin_m;          // m matrix for random effect 
double **mtm;          // (kin_m)^T(kin_m) matrix
 
double omega_mean;			// mean of prior for omega
double omega_var;				// variance of prior for omega
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
int longi_factor;       // 1:include longitudinal factors
double *coef_time;      // time covariates
int *coef_subid;        // subject id covariates
int num_subject;        // number of subjects
int num_grid;           // number of grid
double *grid_p;         // p matrix for random effect for time 
double *grid_v;				  // v matrix for random effect for time 
int *num_timepts;       // number of time points for each subject
int max_num_timept;     // maximun value of time point

double delta_mean;			// mean of prior for delta
double delta_var;				// variance of prior for delta
double *psi_mean;				// mean of prior for psi
double *psi_var;				// variance of prior for psi

double sigma2_fixed;    // fixed sigma^2
//////////////////////////////////////////////////////////////

int dependence;         // see Chipman's paper
double *c;              // see Chipman's paper 

int seed1;		          // the pseudo-random number generator

//********************************************************************************
 
int group;             // 1: groupedly update all main effects or epistatic effects
int nc;                // the number of main effects at one QTL

int sph;               // 1: standardized phenotype; 0: original phenotype

//********************************************************************************
// for binary and ordinal traits

int *w;                // ordinal or binary phenotype
double *cutpoint;      // threshold values for ordinal traits

//********************************************************************************
// parameters used in prior specification

double w_main;          // prior for main effect indicator
double w_epistasis;     // prior for epistatic effect indicator
double w_gbye;          // prior for g by e indicator


//*********************************************************************************
// QTL positions, genetic effects indicators
int *chrqtl;           // QTL number at each chromosome

//**********************************************************************************

double pdd1, pdd2;
double *pd1, *pd2;

int ibd;

double  *x;

//**********************************************************************************

double *censor_lo1;
double *censor_hi1;   

char iterfile[100];
char pairfile[100];
char mainfile[100];
char gbyefile[100];
char covfile[100];
char devfile[100];
char sigmafile[100];
char mixedfile[100];
char testfile[100];

//*************************
FILE *log_file;
//*************************
