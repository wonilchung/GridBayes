/******************************************************************************
* File: GlobalVars_MultipleTraits.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:  This file holds all the variables that are differently 
*   dimensioned for the multiple traits code.
*   None of the global variables in this file have been extern-ed. 
*   This is so that they do not conflict with similarly named single-trait
*   versions of these variables that have different dimensions.
******************************************************************************/


/** 
@brief 
 *  
 * @note 
 * 
 */ 
#ifndef GLOBAL_VARS_MULTIPLE_TRAIT_H
#define GLOBAL_VARS_MULTIPLE_TRAIT_H


/// 0=uses QTLPOSITION_samelocation 1= uses QTLPOSITION
int qtlloc1;
/// Whether different locations are considered for each trait for each indicator or same locations are considered
int difflocation;       
/// Residual variance matrix for multiple triats
double **sigma;
/// Main Effect Variance scale for beta ~ N(0,cI) c=scale;
double scale;
//*******************************************************************************************


/// @addtogroup qbGeno
/// @{

/// QTL genotypes for the MT code
int ***geno;

/// @}

/// @addtogroup qbPheno
/// @{

/// phenotypic data for the MT code
double **y;
/// The number of phenotypes to be jointly analyzed
int npheno1;            
/// 
int multiple1;

/// @}

/// genotypic valyes for the MT code
double **gvalue;


//***************************************************************************************
/// @defgroup qbOp_MT Multiple Traits variants of the qb.op variables
/// @{


/// coefficients of QTL main effects
double ****coef;
/// QTL position indicators, position is grid[qchr[l]][qloc[l]]
int **qloc;
/// chromosomes that QTL locate
int **qchr;

/// @defgroup qbOpCovariate_MT Multiple Traits variant of qb.op.covariate
/// @{
/// effects of fixed covariates
double  **fix;
/// effects of random covariates
double  ***ran;
/// variances of random covariates
double  **vran;
/// interactions of QTL main effects and fixed covariates
double ****gbye_fix;
/// @}

/// @defgroup qbOpIterdiag_MT Multiple Traits variant of qb.op.iterdiag
/// @{
/// overall mean
double *amu;
/// QTL indicators
int **gamma1;
/// residual variance
double ve;
/// @}

/// @defgroup qbOpMainloci_MT Multiple Traits variant of qb.op.mainloci
/// @{
/// main effects
double  ***main1;
/// main effects indicators
int **gamma_main;
/// prior variance of main effects
double  ***vmain;
/// @}

/// @defgroup qbOpPairloci_MT Multiple Traits variant of qb.op.pairloci
/// @{
/// epistatic effects
double *****epistatic;
/// epistatic effects indicators
int ***gamma_epistasis;
/// prior variance of epistatic effects
double *****vepistasis;
/// @}

/// @defgroup qbOpGbyE_MT Multiple Traits variant of qb.op.gbye
/// @{
/// g-by-e indicators
double  ***gamma_gbye;
/// prior variance of g-by-e effects
double ****v_gbye_fix;
/// @}

/// @}

#endif // GLOBAL_VARS_MULTIPLE_TRAIT_H
