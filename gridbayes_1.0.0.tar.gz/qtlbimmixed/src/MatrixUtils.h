/******************************************************************************
* File: MatrixUtils.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:
******************************************************************************/

#ifndef MATRIX_UTILS_H
#define MATRIX_UTILS_H

double Determinant(double **a,int n);

void CoFactor(double **a,int n,double **b);

void Transpose(double **a,int n);

void INVERSE(double **a, int n, double **b);

void MatrixCopy(double **a,double **b,int row,int col,int add);

void XminusY(double **a, double **b, int row, int col, double **target);

void XprimeX(double **a, int row, int col, double **target);

void XprimeY(double **x, double **y, int xrow, int xcol, int ycol,double **target);

void XprimeVec(double **x, double *y, int xrow, int xcol,double *target);

double Trace(double **a,int n);

void Cholesky(double **q,int n,double **lower);

double inner_product(double *v1,	int d1, double *v2,	int d2,	int n);

void matrix_product(double *m1,	double *m2, double *r, int n,	int m, int k);

void matrix_transpose(double *m, double *r, int n_row, int n_col);

void matrix_xtx(double *m, double *r, int n_row, int n_col);

#endif // MATRIX_UTILS_H
