/******************************************************************************
* File: SingleTraitMCMCSamplingRoutines.h
* Version: qtlbimmixed 1.0
* Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
*         Samprit Banerjee, Nengjun Yi
* First Revised: 07.17.2012
* Last Revised:  07.17.2012
* Description:  QTL Bayesian Interval Mapping with Mixed Model
*   Functions relevant to single trait analyses
******************************************************************************/

#ifndef SINGLE_TRAIT_H
#define SINGLE_TRAIT_H

void ZeroEffect1(int l);
void ZeroEffect2(int l1,int l2);
void Coefficient(int genotype);

double Likelihood(double *p,double *g);

void Coefficient0(int i,int l,int ql);

double GenotypeSampling(int i,int l,int ii,int ql);

void Mean(double y_bar,double vp);

void ResidualVariance(double vp);
void ResidualVariance1(int nu,double tau); // added by wonil

void MainEffect(int l,int k);
void MainEffect1(int l);

void EpistaticEffect(int l1,int l2,int k1,int k2);
void EpistaticEffect1(int l1,int l2);

void GBYE_FixedCovariate(int l1,int l2,int k);
void GBYE_FixedCovariate1(int l1,int l2);

void MainVariance(int l,int k,int nu,double tau);
void MainVariance1(int l,int nu,double tau);

void EpistaticVariance(int l1,int l2,int k1,int k2,int nu,double tau);
void EpistaticVariance1(int l1,int l2,int nu,double tau);

void GBYE_FixedCovariate_Variance(int l1,int l2,int k,int nu,double tau);
void GBYE_FixedCovariate_Variance1(int l1,int l2,int nu,double tau);

void FixedCovariate(int l);

void RandomCovariate(int l);

void RanVariance(int l);

void QTLgenotype(int l,int nl,int ql,int i);

void QTLPOSITION(int l,int qlnew);

int SamplingOnePosition(int l);

void MainEffectIndicator_GROUP0(int l,int k);

void MainEffectIndicator_GROUP1(int l);

void EpistasisIndicator_GROUP0(int l1,int l2,int k1,int k2);

void EpistasisIndicator_GROUP1(int l1,int l2);

void GBYE_FIX_Indicator_GROUP0(int l1,int l2,int k);

void GBYE_FIX_Indicator_GROUP1(int l1,int l2);

// for kinship matrix ///////////////////////////////////
void RandomOmega();
void LatentC();
/////////////////////////////////////////////////////////

// for longitudinal data ////////////////////////////////
void IncidenceMatrix();
void RandomDelta();
void RandomPsi();
void RandomV();
void LatentB();
/////////////////////////////////////////////////////////


#endif // SINGLE_TRAIT_H
