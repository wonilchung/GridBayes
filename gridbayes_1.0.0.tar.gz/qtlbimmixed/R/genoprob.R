###########################################################################
# File: genoprob.R
# Version: qtlbimmixed 1.0
# Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
#         Samprit Banerjee, Nengjun Yi
# First Revised: 07.17.2012
# Last Revised:  07.17.2012
# License: GNU General Public License
# R Functions: qb.genoprob
# Description: 
###########################################################################


###########################################################################
### NOTE: Depends on R/qtl 1.03.
qb.genoprob = function(cross, map.function = map.functions, step = 2,
                        tolerance = 1e-6, stepwidth = "variable", ...)
{
  ## This uses calc.genoprob directly.
  ## Call sequence maintained for legacy user code.
  map.functions = unlist(as.list(formals(calc.genoprob)$map.function)[-1])
  map.function = match.arg(tolower(map.function[1]), map.function)

  ## First make sure QTL are not too close.
  if(any(sapply(pull.map(cross), function(x)
                ifelse(length(x) > 1, max(diff(x)) < tolerance, FALSE))))
    cross = jittermap(cross, tolerance)
  
  ## Call R/qtl routine calc.genoprob for calculations.
  cross = calc.genoprob(cross, step, map.function = map.function,
                         stepwidth = stepwidth,
                         ...)

  ## Add tolerance as attribute.
  attr(cross$geno[[1]]$prob, "tolerance") = tolerance
  
  return(cross)
}

