###########################################################################
# File: coda.R
# Version: qtlbimmixed 1.0
# Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
#         Samprit Banerjee, Nengjun Yi
# First Revised: 07.17.2012
# Last Revised:  07.17.2012
# License: GNU General Public License
# R Functions: qb.coda
# Description: 
###########################################################################

###########################################################################

qb.coda = function(qbObject,
                    element = c("iterdiag","mainloci","pairloci","covariates","gbye"),
                    variables = variable.list[[element]], ...)
{
  qb.exists(qbObject)
  
   require("coda")
   variable.list = list(iterdiag = c("nqtl","mean","envvar","var"),
                         mainloci = c("chrom","add","dom"),
                         pairloci = c("chrom","aa","ad","da","dd"),
                         covariates = "cov1",
                         gbye = c("n.gbye","chrom","add","dom"))
   element = match.arg(element)
   tmp = qb.get(qbObject, element, ...)
   variables = names(tmp)[match(variables, names(tmp), nomatch = 0)]
   if(length(variables))
      mcmc(tmp[, variables])
}



