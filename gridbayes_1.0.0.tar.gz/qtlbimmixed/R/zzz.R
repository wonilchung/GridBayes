###########################################################################
# File: zzz.R
# Version: qtlbimmixed 1.0
# Author: Wonil Chung, Brian S. Yandell, Tapan Mehta, 
#         Samprit Banerjee, Nengjun Yi
# First Revised: 07.17.2012
# Last Revised:  07.17.2012
# License: GNU General Public License
# R Functions: .onLoad
# Description: .onLoad is run when the package is loaded with library(qtlbim)
###########################################################################


###########################################################################
.onLoad = function(lib,pkg)
  {
  # We no longer need "library.dynam("qtlbim",pkg,lib) because this
  # is taken care of by the NAMESPACE directive useDynLib(qtlbim).

  # The R documentation suggests that "require(qtl)" should be
  # replaced by an "import(qtl)" directive in the NAMESPACE file.
  # However package::qtl does not define a name space.
  require("qtl")
  
  }


# end of zzz.R

