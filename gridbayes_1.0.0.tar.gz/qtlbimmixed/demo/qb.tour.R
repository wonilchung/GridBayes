library(qtlbimmixed)

qb.demo()
